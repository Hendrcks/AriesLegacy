# 01-AriesAuto: Complete QGIS Geo AI Plugin Plan

## 1. Vision

**AriesAuto** is a professional QGIS plugin that makes satellite-based spatial-index analysis simple, guided and reproducible. It will enable a user to select imagery, choose an objective or type a plain-language request, and receive correctly calculated, styled, classified and documented results.

**Display name:** AriesAuto  
**Repository/plugin folder name:** `01-AriesAuto`  
**Tagline:** *Geo AI automation for smarter spatial-index analysis in QGIS.*

The plugin will complement AriesGeo. AriesGeo can remain the wider geospatial toolbox, while AriesAuto specialises in the automated satellite-index workflow.

## 2. Problem It Solves

Many students and GIS professionals know which index they need, but still spend time finding correct bands, writing raster-calculator expressions, correcting scale factors, styling maps, setting thresholds and calculating class areas. New users can also select an unsuitable index or mix bands from different sensors.

AriesAuto will reduce these steps into a guided workflow while keeping every formula, selected band, processing setting and output visible to the user.

## 3. Goals

- Calculate widely used geospatial indices accurately from supported imagery.
- Detect sensor and bands automatically wherever possible.
- Apply sensible visual styles and editable classification thresholds.
- Support single-date analysis, multi-index analysis and change analysis.
- Produce area statistics, map layouts and concise method/interpretation reports.
- Provide a controlled Geo AI assistant for workflow recommendations.
- Keep workflows reproducible, transparent and usable offline for core analysis.
- Meet QGIS Plugin Repository quality requirements.

## 4. Target Users

- Geography, planning, surveying and GIS students.
- Remote-sensing analysts and researchers.
- Environmental, mining, agriculture and disaster-risk practitioners.
- Local-government and NGO GIS teams.
- Beginners who need guided analysis and advanced users who need faster repeatable processing.

## 5. Version 1 Scope

Version 1 should focus on **satellite indices and index-based change analysis**. This gives the plugin a clear identity, keeps it reliable and makes development achievable.

### Included in Version 1

- Sentinel-2 Level-2A support.
- Landsat 8/9 Collection 2 Level-2 support.
- Optional basic Landsat 5/7 support after validation.
- Band detection and sensor-profile selection.
- Core index calculations and batch calculation.
- Automatic styling and editable thresholds.
- Area statistics in hectares, square metres and square kilometres.
- Two-date index change analysis.
- Export of outputs, map layouts, tables and short reports.
- Rule-based workflow recommendations.

### Not in Version 1

- Fully automatic land-cover classification.
- Complex machine-learning training workflows.
- Live cloud processing or Google Earth Engine integration.
- A chatbot that runs unrestricted commands.
- Full hydrological modelling, terrain modelling and multi-criteria suitability analysis.

These can become later modules once the core is stable.

## 6. Feature Modules

### 6.1 Quick Index Analysis

The user selects an input raster or band stack, selects an index, confirms the sensor profile and clicks **Run**. AriesAuto will:

1. Validate required bands and projection.
2. Apply scale factors where required.
3. Calculate the index.
4. Add the output to QGIS.
5. Apply a suitable colour ramp and default value range.
6. Save processing metadata with the layer.

### 6.2 Multi-Index Analysis

Users can select multiple indices for one image. The plugin processes them sequentially, uses meaningful output names and reports completed/failed tools without losing prior outputs.

### 6.3 Change Detection

For two comparable dates, AriesAuto will:

- Check CRS, extent, resolution and pixel alignment.
- Resample only after user confirmation when needed.
- Calculate the same index for each date.
- Produce absolute change, percentage change where valid, and gain/no-change/loss classes.
- Calculate areas of change classes.
- Export a before/after summary.

### 6.4 Classification and Statistics

- Continuous raster display with recommended colour ramps.
- User-editable threshold classes.
- Reclassified categorical raster output.
- Pixel count and area by class.
- Optional summary by polygon boundaries, such as districts, communities, farms or concessions.
- CSV and Excel-compatible table export.

### 6.5 Map and Report Export

The export wizard will allow users to create:

- GeoTIFF index raster.
- Styled QML layer style.
- PNG/PDF map layout.
- CSV statistics table.
- A concise Markdown, HTML or PDF analysis report.

The report must document the index formula, sensor, band mapping, acquisition dates, scale handling, classification thresholds, units, study-area name and limitations.

## 7. Index Library

Every index will be stored in a structured library, not hard-coded repeatedly. Each item includes its name, purpose, formula, required bands by sensor, recommended style, valid interpretation notes, thresholds where appropriate and scientific reference.

### Priority Index Groups

| Group | Version 1 indices | Main uses |
|---|---|---|
| Vegetation | NDVI, EVI, SAVI, MSAVI, GNDVI, NDMI | Vegetation vigour, moisture and drought support |
| Water/flood | NDWI, MNDWI, AWEI | Water extent, wetland and flood screening |
| Built-up | NDBI, UI, IBI, BUI | Urban/built-up screening |
| Bare soil/mining | BSI, NBR, NBR2, iron-oxide and clay indices | Bare land, disturbance and mining support |
| Fire/change | NBR, dNBR, RdNBR, NDVI change, NDWI change | Burn severity and environmental change |
| Temperature | LST (Landsat only initially) | Surface-temperature analysis |

### Example Index Definition

```json
{
  "id": "ndvi",
  "name": "Normalized Difference Vegetation Index",
  "short_name": "NDVI",
  "formula": "(NIR - RED) / (NIR + RED)",
  "bands": {
    "sentinel_2_l2a": {"NIR": "B08", "RED": "B04"},
    "landsat_8_9_c2_l2": {"NIR": "SR_B5", "RED": "SR_B4"}
  },
  "recommended_style": "RdYlGn",
  "notes": "Higher values generally indicate denser and healthier vegetation."
}
```

All formulas will be independently checked against authoritative technical and scientific references before release.

## 8. Supported Data and Input Rules

### Sentinel-2

- Primary source: Sentinel-2 Level-2A surface reflectance.
- Required bands should be identifiable from standard `B02`, `B03`, `B04`, `B08`, `B8A`, `B11` and `B12` names.
- The plugin must warn users where bands have different native resolutions (10 m, 20 m or 60 m) and state the selected resampling method.

### Landsat 8/9

- Primary source: Collection 2 Level-2 products.
- Surface-reflectance indices use `SR_B*` bands and the official scale/offset values.
- LST processing must use the proper thermal-product workflow and clearly identify assumptions, emissivity method and output units.

### General Checks

- Input raster exists and has valid bands.
- Required bands are not duplicated or missing.
- Inputs share an appropriate CRS, extent and grid for multi-band or two-date operations.
- NoData is handled safely.
- Outputs retain meaningful CRS and data type.
- User may manually map bands if auto-detection is uncertain.

## 9. Geo AI Design

The AI element must be helpful, controlled and transparent—not a black box.

### Phase A: Offline Smart Recommendations

Use a rules engine based on objective, available sensor and selected data. Examples:

- “Vegetation health” → NDVI, EVI, SAVI.
- “Flood/water mapping” → MNDWI and NDWI, with a warning to validate thresholds.
- “Urban growth” → NDBI plus NDVI/NDWI comparison.
- “Mining disturbance” → BSI, NBR, vegetation change and optional iron-oxide/clay indicators.

### Phase B: Optional External AI Assistant

The user can describe their task in plain English, for example: “Assess vegetation loss around Obuasi from 2015 to 2025.” The assistant returns a proposed workflow, such as NDVI for both dates, grid alignment, NDVI difference, loss/gain classification and hectare statistics.

### AI Safety Rules

- AI proposes; the user reviews and confirms before processing starts.
- The index library and validation engine remain the source of truth for bands/formulas.
- AI must not execute arbitrary Python, shell commands or unvalidated expressions.
- Clearly display assumptions, required data and limitations.
- API keys are optional and stored only in QGIS secure settings where available.
- No imagery or project data is uploaded externally without clear user consent.

## 10. User Interface Plan

Use a modern, uncluttered dockable QGIS panel with a simple wizard-like flow.

### Main Navigation

1. **Quick Analysis** — choose imagery and calculate one index.
2. **Multi-Index** — calculate multiple indices in a batch.
3. **Change Detection** — compare two dates.
4. **Geo AI Assistant** — receive a guided recommended workflow.
5. **Results & Export** — styles, classes, statistics, layouts and reports.
6. **Settings** — sensor profiles, output folder, defaults and optional AI configuration.

### Essential User-Experience Details

- Plain-language labels with tooltips.
- Advanced settings collapsed by default.
- Progress bar, processing log and cancel button for long tasks.
- Clear error messages that explain how to correct an input issue.
- Preview of formula, band mapping and expected output before execution.
- Persistent project history for reproducibility.
- Dark/light QGIS theme compatibility and accessible contrast.

## 11. Technical Architecture

### Technology Stack

- **Language:** Python 3.
- **Platform:** QGIS 3.x and PyQGIS.
- **Interface:** PyQt and Qt Designer `.ui` files.
- **Raster processing:** QGIS Processing, GDAL and Raster Calculator APIs.
- **Numerical operations:** NumPy only when necessary; favour QGIS/GDAL algorithms for portability.
- **Styles:** QML files and programmatically created raster renderers.
- **Testing:** `pytest`, QGIS test environment and controlled sample data.
- **Documentation/release:** GitHub, Markdown, semantic versioning and GitHub Actions.

### Proposed Repository Structure

```text
01-AriesAuto/
├── __init__.py
├── ariesauto.py
├── metadata.txt
├── resources.qrc
├── icons/
├── ui/
│   └── ariesauto_dockwidget.ui
├── core/
│   ├── band_detector.py
│   ├── sensor_profiles.py
│   ├── index_library.py
│   ├── index_calculator.py
│   ├── raster_validator.py
│   ├── raster_preprocessor.py
│   ├── classifier.py
│   ├── change_detection.py
│   ├── area_statistics.py
│   ├── style_manager.py
│   ├── report_generator.py
│   └── workflow_history.py
├── processing/
│   ├── provider.py
│   └── algorithms/
├── data/
│   ├── index_library.json
│   ├── sensor_profiles.json
│   └── styles/
├── tests/
├── docs/
├── scripts/
├── README.md
├── CHANGELOG.md
├── CONTRIBUTING.md
├── LICENSE
└── requirements-dev.txt
```

### Key Components

| Component | Responsibility |
|---|---|
| Band detector | Reads names/metadata and proposes sensor and band mappings |
| Validator | Checks CRS, bands, resolution, extent, NoData and scaling |
| Index calculator | Creates safe, validated raster expressions |
| Style manager | Applies and saves recommended QGIS raster styles |
| Change detector | Aligns inputs and calculates difference/change classes |
| Statistics engine | Calculates class areas and zonal summaries |
| Report generator | Creates transparent method and results documentation |
| AI workflow adviser | Converts user intent into reviewed, validated workflow steps |

## 12. Processing Workflow

```mermaid
flowchart TD
  A[Select imagery] --> B[Detect sensor and bands]
  B --> C[Validate inputs and scale]
  C --> D[Choose index or objective]
  D --> E[Calculate raster]
  E --> F[Style and classify]
  F --> G[Area statistics]
  G --> H[Export maps and report]
```

For a two-date workflow, the plugin adds alignment and comparability checks before calculating the change raster.

## 13. Accuracy, Validation and Scientific Integrity

AriesAuto must not imply that an index alone is a final scientific conclusion. The plugin will:

- Show formulas and sources in the interface and report.
- Warn that threshold values are context-, season- and sensor-dependent.
- Encourage field validation, high-resolution imagery and local knowledge.
- Flag cloud, haze, shadow and mixed-pixel risks where inputs make this possible.
- Avoid presenting index maps as automatically classified land cover.
- Use test rasters with expected numerical outputs for every index.
- Compare selected outputs against independently calculated reference results.

## 14. Testing Plan

### Unit Tests

- Band mapping for every supported sensor.
- Formula construction and zero-division protection.
- Scale/offset handling.
- File naming and output creation.
- Area conversions.
- Threshold classification.

### Integration Tests

- Each index on Sentinel-2 and Landsat 8/9 test scenes.
- Two-date change workflows with differing extents/resolutions.
- QGIS Processing Toolbox execution.
- CSV/QML/report exports.

### User Acceptance Tests

Test with real Ghana study areas such as Obuasi, Keta Lagoon and Cape Coast. Ask users to complete common tasks without developer help and record confusing steps, failures, processing time and output accuracy.

### Compatibility Tests

- Latest QGIS LTR on Windows (priority).
- Current QGIS stable release.
- Linux/macOS verification where feasible.
- Clean QGIS profile installation test.

## 15. Security and Privacy

- Core calculation works offline and does not require an account.
- Optional AI API key is never embedded in source code or uploaded to GitHub.
- API keys are kept out of project files and logs.
- AI requests should send the minimum necessary text metadata; never upload imagery by default.
- Document exactly what external service is used when AI is enabled.
- Add error handling that does not expose keys or full local paths in user-facing messages.

## 16. Documentation Plan

The repository should include:

- Installation guide for QGIS Plugin Repository and ZIP/GitHub installation.
- Quick-start tutorial using Sentinel-2.
- Index catalogue with formulas, purpose, band requirements and cautions.
- Change-detection tutorial.
- LST guide with assumptions and limitations.
- Troubleshooting guide.
- FAQ.
- Citation guidance and reference list.
- Short demonstration video/screenshots for GitHub and QGIS plugin page.

## 17. Branding and Product Identity

- **Name in QGIS:** AriesAuto.
- **Repository name:** `01-AriesAuto`.
- **Owner/brand:** AriesPlus Geospatial Solutions.
- **Visual direction:** premium geospatial identity—deep navy/charcoal base, satellite blue/teal, and a restrained gold accent consistent with AriesPlus branding.
- **Icon concept:** a stylised satellite/grid or map tile with an “A” mark and subtle automation spark/flow path. It must remain recognisable at 32×32 pixels.
- **Tone:** clear, practical, trustworthy and beginner-friendly without being simplistic.

## 18. Licensing and Open Source

Use **GPL-2.0-or-later** unless a qualified review identifies a stronger compatibility reason. This aligns with QGIS plugin ecosystem expectations. Include a copyright notice, licence file, contributor guidance and third-party attribution for any reused icons, code or datasets.

## 19. Publishing Plan

### GitHub

- Create the repository under the AriesPlus/Hendrcks account.
- Add a polished README with features, screenshots, installation instructions and citation information.
- Use Issues for bug reports and feature requests.
- Use Releases for versioned ZIP packages.
- Add a changelog and release notes for every version.

### QGIS Plugin Repository

Prepare:

- Valid `metadata.txt`.
- Plugin icon and screenshots.
- Accurate category, description, tags and supported QGIS versions.
- Public repository, issue tracker and homepage links.
- Tested release ZIP containing the plugin folder and excluding development clutter.
- Clear licence information.

Before submission, install the release ZIP in a clean QGIS profile and complete a full quick-analysis test.

## 20. Development Roadmap

### Phase 0 — Product Definition (Week 1)

- Confirm Version 1 index list and supported sensors.
- Define naming, logo direction, licence and GitHub repository.
- Prepare interface wireframes and technical requirements.
- Build sensor and index reference tables.

### Phase 1 — Plugin Foundation (Weeks 2–3)

- Scaffold QGIS plugin project.
- Create dockable interface and Settings page.
- Implement output-folder management, logging and metadata.
- Set up GitHub, issue templates and testing framework.

### Phase 2 — Data Intelligence (Weeks 4–5)

- Implement sensor/band detection.
- Implement manual band mapping fallback.
- Add input validation, scale/offset handling and NoData rules.
- Create index-library loader and core formula engine.

### Phase 3 — Core Indices (Weeks 6–8)

- Deliver NDVI, EVI, SAVI, NDMI, NDWI, MNDWI, NDBI, BSI, NBR and LST.
- Add styles, output naming and result previews.
- Add batch processing and robust processing logs.

### Phase 4 — Classification and Statistics (Weeks 9–10)

- Add editable threshold classes.
- Add reclassification and area statistics.
- Add zonal summary option and CSV export.

### Phase 5 — Change Detection and Exports (Weeks 11–12)

- Add two-date checks, alignment and index-change outputs.
- Add change classes, statistics and before/after comparison.
- Add QML, map, table and report exports.

### Phase 6 — Smart Guidance and Quality (Weeks 13–14)

- Add offline rule-based recommendation system.
- Add optional AI workflow adviser behind user confirmation.
- Complete documentation, test suite and user testing.

### Phase 7 — Release (Week 15)

- Run compatibility and clean-install tests.
- Package Version 1.0.0.
- Publish on GitHub and submit to the QGIS Plugin Repository.
- Create launch flyer, short demo and LinkedIn announcement.

## 21. Future Modules

After Version 1 is stable, introduce modules deliberately:

1. **Terrain & Hydrology:** slope, aspect, hillshade, contours, TWI, flow direction, flow accumulation, watershed and drainage extraction.
2. **Suitability & Risk:** criteria standardisation, weighted overlay, AHP support, proximity analysis and suitability reporting.
3. **Land-Cover Support:** training-data helper, supervised-classification guidance and accuracy-assessment tools.
4. **Mining & Environment:** disturbance monitoring, reclamation tracking, water-quality proxy indices and hotspot summaries.
5. **Cloud Workflows:** optional Google Earth Engine connection only after careful authentication, privacy and reliability design.
6. **Advanced Reporting:** branded templates, full technical reports and portfolio-ready map packs.

## 22. Decisions Required Before Coding

- Confirm the final Version 1 indices.
- Choose the initial QGIS version baseline (recommended: current LTR).
- Confirm whether AriesAuto is a standalone plugin or visibly linked to AriesGeo in branding/navigation.
- Choose the initial supported imagery: Sentinel-2 and Landsat 8/9 are recommended.
- Choose whether optional AI starts in Version 1 or after the offline release.
- Confirm preferred logo and colour direction.
- Confirm the GitHub owner/repository location.

## 23. Success Measures for Version 1

- A new user can produce a valid NDVI map from supported imagery in under five minutes.
- At least ten core indices work correctly on supported Sentinel-2 and Landsat imagery.
- Every output has documented formula, bands and settings.
- A two-date NDVI/NDWI/NDBI change workflow completes without manual raster-calculator expressions.
- Exported statistics correctly report hectares.
- Plugin installs cleanly, does not crash QGIS and passes core tests.
- Documentation enables a user to install and operate the plugin independently.

## 24. Immediate First Build

The first development sprint should create the repository and a small working prototype with:

1. AriesAuto QGIS plugin shell and branded dock panel.
2. Sentinel-2/Landsat 8/9 band detector.
3. NDVI, NDWI, MNDWI and NDBI calculators.
4. Automatic styles.
5. GeoTIFF and QML export.
6. A short usage guide and test dataset checklist.

Once this prototype works reliably, we can expand it step by step into the full AriesAuto platform described above.
