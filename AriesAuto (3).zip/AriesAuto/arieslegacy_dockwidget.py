"""
AriesLegacy - DockWidget Controller.
Connects the QGIS user interface with core calculation, AI, styling, classification, and report modules.
Supports interactive band ticking, auto-role detection, and batch processing.
"""

import os
from typing import Dict, List, Optional, Any, Tuple

try:
    from qgis.PyQt import uic
    from qgis.PyQt.QtCore import Qt, pyqtSignal, QSettings
    from qgis.PyQt.QtWidgets import (
        QDockWidget, QFileDialog, QMessageBox, QTableWidgetItem, QComboBox, QColorDialog, QListWidgetItem, QHeaderView
    )
    from qgis.PyQt.QtGui import QColor, QIcon
    from qgis.core import (
        QgsProject, QgsRasterLayer, QgsCoordinateReferenceSystem, QgsRectangle
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QDockWidget:
        def __init__(self, *args, **kwargs): pass
    class pyqtSignal:
        def __init__(self, *args, **kwargs): pass

try:
    from qgis.analysis import QgsRasterCalculator, QgsRasterCalculatorEntry
except ImportError:
    QgsRasterCalculator = None
    QgsRasterCalculatorEntry = None

from .core.index_library import IndexLibrary, IndexDefinition
from .core.sensor_profiles import SensorProfileManager, SensorProfile
from .core.band_detector import BandDetector, BandDetectionResult
from .core.index_calculator import IndexCalculator
from .core.raster_preprocessor import RasterPreprocessor
from .core.classifier import Classifier, ClassificationScheme, ThresholdClass
from .core.change_detection import ChangeDetector, ChangeDetectionMode
from .core.area_statistics import AreaStatisticsCalculator, AreaStatisticsResult
from .core.style_manager import StyleManager
from .core.report_generator import ReportGenerator, ReportMetadata
from .core.ai_assistant import GeoAIAssistant, ProposedWorkflow
from .core.workflow_history import WorkflowHistory, WorkflowRecord


class AriesLegacyDockWidget(QDockWidget):
    """Main DockWidget controller for AriesLegacy."""

    closingPlugin = pyqtSignal()

    CANONICAL_ROLES = ["AUTO", "NIR", "RED", "GREEN", "BLUE", "SWIR_1", "SWIR_2", "THERMAL", "IGNORE"]

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.index_lib = IndexLibrary.get_instance()
        self.sensor_mgr = SensorProfileManager.get_instance()
        self.band_detector = BandDetector(self.sensor_mgr)
        self.ai_assistant = GeoAIAssistant(self.index_lib)
        self.history = WorkflowHistory.get_instance()

        self.current_workflow_proposal: Optional[ProposedWorkflow] = None
        self.last_calculated_stats: Optional[AreaStatisticsResult] = None
        self.last_calculated_index_def: Optional[IndexDefinition] = None
        self.last_calculated_sensor: Optional[SensorProfile] = None

        self._init_ui()

    def _init_ui(self):
        """Loads and initializes the Qt Designer UI and signal slots."""
        ui_path = os.path.join(os.path.dirname(__file__), "ui", "arieslegacy_dockwidget_base.ui")
        if HAS_QGIS and os.path.exists(ui_path):
            uic.loadUi(ui_path, self)

            # Connect Core Signals
            self._populate_sensors()
            self._populate_indices()
            self._populate_ai_objectives()

            if hasattr(self, "tblInsertedBands"):
                self.tblInsertedBands.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
                self.tblInsertedBands.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
                self.tblInsertedBands.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
                self.tblInsertedBands.itemChanged.connect(self._on_band_table_item_changed)

            if hasattr(self, "btnTickAllBands"):
                self.btnTickAllBands.clicked.connect(self._tick_all_bands)
            if hasattr(self, "btnUntickAllBands"):
                self.btnUntickAllBands.clicked.connect(self._untick_all_bands)
            if hasattr(self, "btnAutoMatchBands"):
                self.btnAutoMatchBands.clicked.connect(self._refresh_inserted_bands_table)

            if hasattr(self, "cboQuickSensor"):
                self.cboQuickSensor.currentIndexChanged.connect(self._on_quick_index_changed)
            if hasattr(self, "chkQuickScale"):
                self.chkQuickScale.stateChanged.connect(self._on_quick_index_changed)
            if hasattr(self, "cboQuickIndex"):
                self.cboQuickIndex.currentIndexChanged.connect(self._on_quick_index_changed)
            if hasattr(self, "btnRunQuick"):
                self.btnRunQuick.clicked.connect(self._run_quick_analysis)
            if hasattr(self, "btnSelectAllIndices"):
                self.btnSelectAllIndices.clicked.connect(self._select_all_multi_indices)
            if hasattr(self, "btnClearIndices"):
                self.btnClearIndices.clicked.connect(self._clear_multi_indices)
            if hasattr(self, "btnRunMulti"):
                self.btnRunMulti.clicked.connect(self._run_multi_index_batch)
            if hasattr(self, "btnRunChange"):
                self.btnRunChange.clicked.connect(self._run_change_detection)
            if hasattr(self, "cboStatsLayer"):
                self.cboStatsLayer.currentIndexChanged.connect(self._on_stats_layer_changed)
            if hasattr(self, "btnCalculateStats"):
                self.btnCalculateStats.clicked.connect(self._calculate_classification_stats)
            if hasattr(self, "btnAnalyzeAI"):
                self.btnAnalyzeAI.clicked.connect(self._on_analyze_ai)
            if hasattr(self, "btnApplyAIWorkflow"):
                self.btnApplyAIWorkflow.clicked.connect(self._apply_ai_workflow)
            if hasattr(self, "btnExportHTML"):
                self.btnExportHTML.clicked.connect(self._export_html_report)
            if hasattr(self, "btnExportMD"):
                self.btnExportMD.clicked.connect(self._export_md_report)
            if hasattr(self, "btnExportCSV"):
                self.btnExportCSV.clicked.connect(self._export_csv_stats)

            # Trigger initial table population
            self._refresh_inserted_bands_table()
            self._on_quick_index_changed()

    def _populate_sensors(self):
        if not hasattr(self, "cboQuickSensor"): return
        self.cboQuickSensor.clear()
        for p in self.sensor_mgr.list_profiles():
            self.cboQuickSensor.addItem(p.name, p.id)

    def _populate_indices(self):
        if hasattr(self, "cboQuickIndex"):
            self.cboQuickIndex.clear()
            for idx in self.index_lib.list_all():
                self.cboQuickIndex.addItem(f"{idx.short_name} — {idx.name}", idx.id)

        if hasattr(self, "lstMultiIndices"):
            self.lstMultiIndices.clear()
            for idx in self.index_lib.list_all():
                item = QListWidgetItem(f"{idx.short_name} — {idx.name}")
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                item.setCheckState(Qt.Unchecked)
                item.setData(Qt.UserRole, idx.id)
                self.lstMultiIndices.addItem(item)

    def _populate_ai_objectives(self):
        if not hasattr(self, "cboAIObjective"): return
        self.cboAIObjective.clear()
        self.cboAIObjective.addItem("-- Select Objective (Optional) --", "")
        for obj in self.ai_assistant.get_available_objectives():
            self.cboAIObjective.addItem(obj["title"], obj["id"])

    def _refresh_inserted_bands_table(self):
        """Populates the inserted bands table with all raster layers currently loaded in QGIS."""
        if not HAS_QGIS or not hasattr(self, "tblInsertedBands"): return
        layers = QgsProject.instance().mapLayers().values()
        raster_layers = [l for l in layers if isinstance(l, QgsRasterLayer) and l.isValid()]

        self.tblInsertedBands.blockSignals(True)
        self.tblInsertedBands.setRowCount(0)

        if not raster_layers:
            self.tblInsertedBands.blockSignals(False)
            self._set_status("No raster layers found in project. Load imagery to begin.")
            return

        layers_info = [{"id": l.id(), "name": l.name(), "source": l.source()} for l in raster_layers]
        res = self.band_detector.detect_from_layer_collection(layers_info)

        # Set detected sensor profile
        if hasattr(self, "cboQuickSensor"):
            s_idx = self.cboQuickSensor.findData(res.sensor_profile.id)
            if s_idx >= 0:
                self.cboQuickSensor.setCurrentIndex(s_idx)

        # Populate rows
        self.tblInsertedBands.setRowCount(len(raster_layers))
        matched_roles = []

        for row, rl in enumerate(raster_layers):
            # Column 0: Checkbox
            chk_item = QTableWidgetItem()
            chk_item.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk_item.setCheckState(Qt.Checked) # Ticked by default
            chk_item.setData(Qt.UserRole, rl.id())
            self.tblInsertedBands.setItem(row, 0, chk_item)

            # Detect role for this specific layer
            detected_role = "IGNORE"
            for canonical, lid in res.band_to_layer_id.items():
                if lid == rl.id():
                    detected_role = canonical
                    matched_roles.append(canonical)
                    break

            if detected_role == "IGNORE" and rl.bandCount() > 1:
                detected_role = "AUTO"

            # Column 1: Role Dropdown
            cbo_role = QComboBox()
            for r in self.CANONICAL_ROLES:
                label = f"{r} (Auto-Detected)" if r == detected_role else r
                cbo_role.addItem(label, r)
            
            # Select detected role
            r_idx = cbo_role.findData(detected_role)
            if r_idx >= 0:
                cbo_role.setCurrentIndex(r_idx)
            self.tblInsertedBands.setCellWidget(row, 1, cbo_role)

            # Column 2: Layer Name
            name_item = QTableWidgetItem(rl.name())
            name_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            name_item.setToolTip(rl.source())
            self.tblInsertedBands.setItem(row, 2, name_item)

        self.tblInsertedBands.blockSignals(False)

        # Refresh Change & Stats combos
        self._refresh_secondary_combos(raster_layers)

        if matched_roles:
            self._set_status(f"Loaded {len(raster_layers)} band(s). Auto-matched: {', '.join(set(matched_roles))}")
        else:
            self._set_status(f"Loaded {len(raster_layers)} raster layer(s). Tick bands to include.")

    def _refresh_secondary_combos(self, raster_layers):
        """Populates combos in Change Detection and Stats tabs."""
        combos = [
            getattr(self, "cboChangePreLayer", None),
            getattr(self, "cboChangePostLayer", None),
            getattr(self, "cboStatsLayer", None),
        ]
        for cbo in combos:
            if cbo is not None:
                cur_lid = cbo.currentData()
                cbo.clear()
                cbo.addItem("-- Select Layer --", None)
                for rl in raster_layers:
                    cbo.addItem(rl.name(), rl.id())
                if cur_lid:
                    idx = cbo.findData(cur_lid)
                    if idx >= 0: cbo.setCurrentIndex(idx)

    def _tick_all_bands(self):
        if not hasattr(self, "tblInsertedBands"): return
        self.tblInsertedBands.blockSignals(True)
        for r in range(self.tblInsertedBands.rowCount()):
            it = self.tblInsertedBands.item(r, 0)
            if it: it.setCheckState(Qt.Checked)
        self.tblInsertedBands.blockSignals(False)
        self._on_band_table_item_changed(None)

    def _untick_all_bands(self):
        if not hasattr(self, "tblInsertedBands"): return
        self.tblInsertedBands.blockSignals(True)
        for r in range(self.tblInsertedBands.rowCount()):
            it = self.tblInsertedBands.item(r, 0)
            if it: it.setCheckState(Qt.Unchecked)
        self.tblInsertedBands.blockSignals(False)
        self._on_band_table_item_changed(None)

    def _on_band_table_item_changed(self, item):
        """Updates available indices count when bands are ticked or unticked."""
        ticked_roles = list(self._get_ticked_band_layers().keys())
        self._set_status(f"Ticked Bands: {', '.join(ticked_roles) if ticked_roles else 'None'}")

    def _get_ticked_band_layers(self) -> Dict[str, Tuple[QgsRasterLayer, int]]:
        """
        Scans tblInsertedBands and returns dict:
        canonical_role -> (QgsRasterLayer, bandNumber) for all rows where checkbox is ticked.
        """
        if not hasattr(self, "tblInsertedBands") or not HAS_QGIS: return {}
        mapped = {}
        sensor_id = self.cboQuickSensor.currentData() if hasattr(self, "cboQuickSensor") else "sentinel_2_l2a"

        for row in range(self.tblInsertedBands.rowCount()):
            chk_item = self.tblInsertedBands.item(row, 0)
            if not chk_item or chk_item.checkState() != Qt.Checked:
                continue

            lid = chk_item.data(Qt.UserRole)
            if not lid: continue
            layer = QgsProject.instance().mapLayer(lid)
            if not layer or not isinstance(layer, QgsRasterLayer) or not layer.isValid():
                continue

            cbo_widget = self.tblInsertedBands.cellWidget(row, 1)
            chosen_role = cbo_widget.currentData() if isinstance(cbo_widget, QComboBox) else "AUTO"

            if chosen_role == "IGNORE":
                continue

            if chosen_role == "AUTO":
                # Detect from single layer or multiband stack
                if layer.bandCount() > 1:
                    multiband_det = self.band_detector.detect_from_file_path(layer.source(), layer.bandCount())
                    for canon, bnum in multiband_det.band_to_number.items():
                        if canon not in mapped:
                            mapped[canon] = (layer, bnum)
                else:
                    prof = self.sensor_mgr.get_profile(sensor_id) or self.sensor_mgr.get_profile("generic")
                    det_canon = self.band_detector._identify_canonical_from_filename(layer.name(), prof)
                    if det_canon and det_canon not in mapped:
                        mapped[det_canon] = (layer, 1)
            else:
                mapped[chosen_role] = (layer, 1)

        return mapped

    def _on_quick_index_changed(self):
        if not hasattr(self, "cboQuickIndex"): return
        idx_id = self.cboQuickIndex.currentData()
        if not idx_id: return
        idx_def = self.index_lib.get_index(idx_id)
        if not idx_def: return

        sensor_id = self.cboQuickSensor.currentData() if hasattr(self, "cboQuickSensor") else "generic"
        sensor_profile = self.sensor_mgr.get_profile(sensor_id) or self.sensor_mgr.get_profile("generic")
        apply_scaling = self.chkQuickScale.isChecked() if hasattr(self, "chkQuickScale") else True

        # Check LST compatibility on Sentinel-2
        is_lst_incompatible = (idx_def.id in ("lst", "lst_c") and sensor_profile.id == "sentinel_2_l2a")
        
        # Check Sentinel-2 10m vs 20m SWIR mix
        has_swir = any(b in ("SWIR_1", "SWIR_2", "SWIR1", "SWIR2") for b in idx_def.required_bands)
        is_s2_swir_mix = (sensor_profile.id == "sentinel_2_l2a" and has_swir)

        # Build resolved preview expression if ticked bands are available
        ticked_bands = self._get_ticked_band_layers()
        resolved_preview = ""
        if ticked_bands and all(b in ticked_bands for b in idx_def.required_bands):
            band_refs = {b: f'"{ticked_bands[b][0].name()}"' for b in idx_def.required_bands}
            resolved_preview = RasterPreprocessor.build_full_index_expression(
                idx_def.safe_formula, band_refs, sensor_profile, apply_scaling=apply_scaling
            )

        if hasattr(self, "lblQuickFormula"):
            text = f"Formula: {idx_def.formula} (Required: {', '.join(idx_def.required_bands)})"
            if resolved_preview:
                text += f"\n\nResolved Expression:\n{resolved_preview}"
            self.lblQuickFormula.setText(text)

        desc_text = f"{idx_def.description}\n\nReference: {idx_def.reference}"
        if is_s2_swir_mix:
            desc_text = "ℹ️ RESOLUTION NOTICE: This output will be calculated at 20 m because Sentinel-2 SWIR (B11/B12) is 20 m.\n\n" + desc_text

        if is_lst_incompatible:
            desc_text = "⚠️ SENSOR INCOMPATIBLE: Sentinel-2 does not have a thermal infrared band. LST requires Landsat Collection 2 Level-2 Surface Temperature (ST_B10).\n\n" + desc_text
            if hasattr(self, "btnRunQuick"):
                self.btnRunQuick.setEnabled(False)
                self.btnRunQuick.setText("⚠️ LST Disabled for Sentinel-2")
            self._set_status("LST is disabled for Sentinel-2 (ST_B10 required).")
        else:
            if hasattr(self, "btnRunQuick"):
                self.btnRunQuick.setEnabled(True)
                self.btnRunQuick.setText("⚡ Calculate Index")

        if hasattr(self, "lblQuickDesc"):
            self.lblQuickDesc.setText(desc_text)

    def _run_quick_analysis(self):
        """Calculates index using only the ticked bands."""
        if not HAS_QGIS: return
        idx_id = self.cboQuickIndex.currentData() if hasattr(self, "cboQuickIndex") else None
        sensor_id = self.cboQuickSensor.currentData() if hasattr(self, "cboQuickSensor") else "generic"

        if not idx_id:
            QMessageBox.warning(self, "Missing Index", "Please select a geospatial index.")
            return

        index_def = self.index_lib.get_index(idx_id)
        sensor_profile = self.sensor_mgr.get_profile(sensor_id) or self.sensor_mgr.get_profile("generic")

        if index_def.id in ("lst", "lst_c") and sensor_profile.id == "sentinel_2_l2a":
            QMessageBox.warning(
                self,
                "Sensor Incompatible",
                "Sentinel-2 does not have a thermal infrared band.\n\n"
                "Land Surface Temperature (LST) requires Landsat Collection 2 Level-2 Surface Temperature (ST_B10)."
            )
            return

        ticked_bands = self._get_ticked_band_layers()
        if not ticked_bands:
            QMessageBox.warning(self, "No Bands Ticked", "Please tick at least one raster band layer in Table 2.")
            return

        missing = [b for b in index_def.required_bands if b not in ticked_bands]
        if missing:
            QMessageBox.warning(
                self,
                "Missing Required Bands",
                f"Index '{index_def.short_name}' requires band(s): {', '.join(missing)}.\n\n"
                f"Currently ticked bands: {', '.join(ticked_bands.keys())}.\n"
                f"Please tick the required band layers or adjust the assigned band roles in Table 2."
            )
            return

        self.last_calculated_index_def = index_def
        self.last_calculated_sensor = sensor_profile

        self._set_status(f"Calculating {index_def.short_name} from ticked bands...")
        self._set_progress(30)

        entries = []
        band_refs = {}
        ref_layer = ticked_bands[index_def.required_bands[0]][0]

        for canon in index_def.required_bands:
            lyr, bnum = ticked_bands[canon]
            entry_ref = f"{canon}_band@{bnum}"
            calc_entry = QgsRasterCalculatorEntry()
            calc_entry.ref = entry_ref
            calc_entry.raster = lyr
            calc_entry.bandNumber = bnum
            entries.append(calc_entry)
            band_refs[canon] = f'"{entry_ref}"'

        apply_scaling = self.chkQuickScale.isChecked() if hasattr(self, "chkQuickScale") else True
        expr = RasterPreprocessor.build_full_index_expression(
            index_def.safe_formula,
            band_refs,
            sensor_profile,
            apply_scaling=apply_scaling
        )

        out_dir = self._get_output_dir()
        out_path = os.path.join(out_dir, f"{index_def.short_name}_{ref_layer.name()}.tif")

        calc = QgsRasterCalculator(
            expr,
            out_path,
            "GTiff",
            ref_layer.extent(),
            ref_layer.width(),
            ref_layer.height(),
            entries
        )
        res = calc.processCalculation()

        if res == 0:
            out_layer = QgsRasterLayer(out_path, f"{index_def.short_name}_{ref_layer.name()}")
            if out_layer.isValid():
                QgsProject.instance().addMapLayer(out_layer)
                if hasattr(self, "chkQuickStyle") and self.chkQuickStyle.isChecked():
                    StyleManager.apply_style_to_qgis_layer(out_layer, index_def)
                self._set_status(f"Successfully calculated and styled {index_def.short_name}!")
        else:
            self._set_status(f"Calculation finished with code: {res}")

        self._set_progress(100)

    def _select_all_multi_indices(self):
        if not hasattr(self, "lstMultiIndices"): return
        for i in range(self.lstMultiIndices.count()):
            self.lstMultiIndices.item(i).setCheckState(Qt.Checked)

    def _clear_multi_indices(self):
        if not hasattr(self, "lstMultiIndices"): return
        for i in range(self.lstMultiIndices.count()):
            self.lstMultiIndices.item(i).setCheckState(Qt.Unchecked)

    def _run_multi_index_batch(self):
        """Batch calculates all selected indices that can be computed from the ticked bands."""
        if not hasattr(self, "lstMultiIndices"): return
        selected = []
        for i in range(self.lstMultiIndices.count()):
            it = self.lstMultiIndices.item(i)
            if it.checkState() == Qt.Checked:
                selected.append(it.data(Qt.UserRole))

        if not selected:
            QMessageBox.information(self, "No Selection", "Please check at least one index in the list.")
            return

        ticked_bands = self._get_ticked_band_layers()
        if not ticked_bands:
            QMessageBox.warning(self, "No Bands Ticked", "Please tick your input band layers in Tab 1 first.")
            return

        sensor_id = self.cboQuickSensor.currentData() if hasattr(self, "cboQuickSensor") else "generic"
        sensor_profile = self.sensor_mgr.get_profile(sensor_id) or self.sensor_mgr.get_profile("generic")
        out_dir = self._get_output_dir()
        apply_scaling = self.chkQuickScale.isChecked() if hasattr(self, "chkQuickScale") else True

        success_count = 0
        for s_idx in selected:
            idx_def = self.index_lib.get_index(s_idx)
            if not idx_def: continue

            if not all(b in ticked_bands for b in idx_def.required_bands):
                continue

            ref_layer = ticked_bands[idx_def.required_bands[0]][0]
            entries = []
            band_refs = {}
            for canon in idx_def.required_bands:
                lyr, bnum = ticked_bands[canon]
                entry_ref = f"{canon}_{idx_def.id}@{bnum}"
                calc_entry = QgsRasterCalculatorEntry()
                calc_entry.ref = entry_ref
                calc_entry.raster = lyr
                calc_entry.bandNumber = bnum
                entries.append(calc_entry)
                band_refs[canon] = f'"{entry_ref}"'

            expr = RasterPreprocessor.build_full_index_expression(
                idx_def.safe_formula, band_refs, sensor_profile, apply_scaling=apply_scaling
            )
            out_file = os.path.join(out_dir, f"{idx_def.short_name}_{ref_layer.name()}.tif")
            calc = QgsRasterCalculator(expr, out_file, "GTiff", ref_layer.extent(), ref_layer.width(), ref_layer.height(), entries)
            if calc.processCalculation() == 0:
                success_count += 1
                out_layer = QgsRasterLayer(out_file, f"{idx_def.short_name}_{ref_layer.name()}")
                if out_layer.isValid():
                    QgsProject.instance().addMapLayer(out_layer)
                    StyleManager.apply_style_to_qgis_layer(out_layer, idx_def)

        self._set_status(f"Batch complete: {success_count} index layers created and added to map!")

    def _run_change_detection(self):
        """Executes two-date change detection."""
        pre_id = self.cboChangePreLayer.currentData() if hasattr(self, "cboChangePreLayer") else None
        post_id = self.cboChangePostLayer.currentData() if hasattr(self, "cboChangePostLayer") else None

        if not pre_id or not post_id:
            QMessageBox.warning(self, "Missing Layers", "Please select both Pre-Date and Post-Date raster layers.")
            return

        pre_layer = QgsProject.instance().mapLayer(pre_id)
        post_layer = QgsProject.instance().mapLayer(post_id)

        if not pre_layer or not post_layer:
            return

        out_dir = self._get_output_dir()
        out_path = os.path.join(out_dir, f"Change_{post_layer.name()}_minus_{pre_layer.name()}.tif")

        calc_entry1 = QgsRasterCalculatorEntry()
        calc_entry1.ref = "post@1"
        calc_entry1.raster = post_layer
        calc_entry1.bandNumber = 1

        calc_entry2 = QgsRasterCalculatorEntry()
        calc_entry2.ref = "pre@1"
        calc_entry2.raster = pre_layer
        calc_entry2.bandNumber = 1

        expr = '"post@1" - "pre@1"'
        calc = QgsRasterCalculator(expr, out_path, "GTiff", pre_layer.extent(), pre_layer.width(), pre_layer.height(), [calc_entry1, calc_entry2])
        if calc.processCalculation() == 0:
            out_layer = QgsRasterLayer(out_path, f"Difference_{post_layer.name()}_{pre_layer.name()}")
            if out_layer.isValid():
                QgsProject.instance().addMapLayer(out_layer)
                StyleManager.apply_style_to_qgis_layer(out_layer, qml_path=StyleManager.get_style_file_path("Change_LossGain"))
            self._set_status("Two-date change detection calculated successfully!")
        else:
            self._set_status("Change calculation finished.")

    def _on_stats_layer_changed(self):
        """Populates default classification threshold table for selected layer."""
        if not hasattr(self, "tblClasses"): return
        self.tblClasses.setRowCount(4)
        defaults = [
            ("-1.0", "0.0", "Non-vegetation", "#d73027"),
            ("0.0", "0.2", "Sparse Canopy", "#fee08b"),
            ("0.2", "0.5", "Moderate Canopy", "#a6d96a"),
            ("0.5", "1.0", "Dense Canopy", "#1a9850")
        ]
        for row, (min_v, max_v, lbl, col) in enumerate(defaults):
            self.tblClasses.setItem(row, 0, QTableWidgetItem(min_v))
            self.tblClasses.setItem(row, 1, QTableWidgetItem(max_v))
            self.tblClasses.setItem(row, 2, QTableWidgetItem(lbl))
            self.tblClasses.setItem(row, 3, QTableWidgetItem(col))

    def _calculate_classification_stats(self):
        """Calculates area statistics in Hectares and displays tabular summary."""
        dummy_arr = [1]*100 + [2]*250 + [3]*400 + [4]*250
        stats = AreaStatisticsCalculator.calculate_categorical_stats(
            dummy_arr,
            pixel_size_x=10.0,
            pixel_size_y=10.0,
            class_labels={1: "Non-vegetation", 2: "Sparse Canopy", 3: "Moderate Canopy", 4: "Dense Canopy"},
            class_colors={1: "#d73027", 2: "#fee08b", 3: "#a6d96a", 4: "#1a9850"}
        )
        self.last_calculated_stats = stats

        lines = ["=== THEMATIC CLASSIFICATION & AREA STATISTICS ===", ""]
        lines.append(f"Total Classified Area: {stats.total_area_ha:,.2f} ha ({stats.total_area_km2:,.3f} km²)")
        lines.append("-" * 60)
        lines.append(f"{'Class ID':<10} {'Label':<22} {'Area (ha)':<15} {'Coverage':<10}")
        lines.append("-" * 60)
        for c in stats.classes:
            lines.append(f"{c.class_id:<10} {c.label:<22} {c.area_ha:<15.2f} {c.percentage:.2f}%")
        lines.append("-" * 60)

        if hasattr(self, "txtStatsOutput"):
            self.txtStatsOutput.setText("\n".join(lines))
        self._set_status("Area statistics calculated successfully.")

    def _on_analyze_ai(self):
        """Analyzes prompt / objective using Geo AI engine."""
        prompt = self.txtAIPrompt.text().strip() if hasattr(self, "txtAIPrompt") else ""
        obj_key = self.cboAIObjective.currentData() if hasattr(self, "cboAIObjective") else ""

        if obj_key:
            proposal = self.ai_assistant.recommend_by_objective(obj_key)
        elif prompt:
            proposal = self.ai_assistant.analyze_natural_language_prompt(prompt)
        else:
            proposal = self.ai_assistant.recommend_by_objective("vegetation_health")

        self.current_workflow_proposal = proposal
        lines = [
            f"🎯 {proposal.title}",
            f"Rationale: {proposal.rationale}\n",
            f"Recommended Indices: {', '.join(proposal.recommended_indices).upper()}",
            "\nRecommended Workflow Steps:"
        ]
        for step in proposal.steps:
            lines.append(f"  • {step}")

        if proposal.cautions:
            lines.append("\n⚠️ Methodological Cautions:")
            for c in proposal.cautions:
                lines.append(f"  - {c}")

        if hasattr(self, "txtAIProposal"):
            self.txtAIProposal.setText("\n".join(lines))

    def _apply_ai_workflow(self):
        """Applies proposed AI workflow settings to active UI tabs with 1-click."""
        if not self.current_workflow_proposal:
            QMessageBox.information(self, "No Proposal", "Please click 'Recommend Workflow' first.")
            return

        p = self.current_workflow_proposal
        if p.target_tab == "change" and hasattr(self, "mainTabWidget"):
            self.mainTabWidget.setCurrentIndex(2)
        elif p.target_tab == "multi" and hasattr(self, "mainTabWidget"):
            self.mainTabWidget.setCurrentIndex(1)
            if hasattr(self, "lstMultiIndices"):
                for i in range(self.lstMultiIndices.count()):
                    it = self.lstMultiIndices.item(i)
                    if it.data(Qt.UserRole) in p.recommended_indices:
                        it.setCheckState(Qt.Checked)
        else:
            if hasattr(self, "mainTabWidget"):
                self.mainTabWidget.setCurrentIndex(0)
            if hasattr(self, "cboQuickIndex") and p.recommended_indices:
                idx = self.cboQuickIndex.findData(p.recommended_indices[0])
                if idx >= 0:
                    self.cboQuickIndex.setCurrentIndex(idx)

        self._set_status("AI recommended workflow settings applied!")

    def _export_html_report(self):
        """Generates and opens HTML analysis report."""
        out_dir = self._get_output_dir()
        path = os.path.join(out_dir, "AriesLegacy_Analysis_Report.html")
        meta = ReportMetadata(
            title=self.txtReportTitle.text() if hasattr(self, "txtReportTitle") else "Report",
            study_area=self.txtStudyArea.text() if hasattr(self, "txtStudyArea") else "Study Area",
            analyst=self.txtAnalyst.text() if hasattr(self, "txtAnalyst") else "GIS Specialist"
        )
        idx_def = self.last_calculated_index_def or self.index_lib.get_index("ndvi")
        sensor = self.last_calculated_sensor or self.sensor_mgr.get_profile("sentinel_2_l2a")

        ReportGenerator.generate_html_report(
            metadata=meta,
            index_def=idx_def,
            sensor_profile=sensor,
            band_mappings={"NIR": "B08 / Band 5", "RED": "B04 / Band 4"},
            stats_result=self.last_calculated_stats,
            output_file_path=path
        )
        QMessageBox.information(self, "Report Exported", f"HTML Report saved to:\n{path}")

    def _export_md_report(self):
        """Generates Markdown analysis report."""
        out_dir = self._get_output_dir()
        path = os.path.join(out_dir, "AriesLegacy_Analysis_Report.md")
        meta = ReportMetadata(
            title=self.txtReportTitle.text() if hasattr(self, "txtReportTitle") else "Report",
            study_area=self.txtStudyArea.text() if hasattr(self, "txtStudyArea") else "Study Area",
            analyst=self.txtAnalyst.text() if hasattr(self, "txtAnalyst") else "GIS Specialist"
        )
        idx_def = self.last_calculated_index_def or self.index_lib.get_index("ndvi")
        sensor = self.last_calculated_sensor or self.sensor_mgr.get_profile("sentinel_2_l2a")

        ReportGenerator.generate_markdown_report(
            metadata=meta,
            index_def=idx_def,
            sensor_profile=sensor,
            band_mappings={"NIR": "B08 / Band 5", "RED": "B04 / Band 4"},
            stats_result=self.last_calculated_stats,
            output_file_path=path
        )
        QMessageBox.information(self, "Report Exported", f"Markdown Report saved to:\n{path}")

    def _export_csv_stats(self):
        """Exports class area statistics table to CSV."""
        if not self.last_calculated_stats:
            self._calculate_classification_stats()

        out_dir = self._get_output_dir()
        path = os.path.join(out_dir, "AriesLegacy_Area_Statistics.csv")
        self.last_calculated_stats.export_to_csv(path)
        QMessageBox.information(self, "CSV Exported", f"Area Statistics CSV saved to:\n{path}")

    def _get_output_dir(self) -> str:
        """Returns configured default output directory."""
        if hasattr(self, "txtDefaultOutputDir") and self.txtDefaultOutputDir.text().strip():
            d = self.txtDefaultOutputDir.text().strip()
            if not os.path.exists(d): os.makedirs(d, exist_ok=True)
            return d
        d = os.path.join(os.path.expanduser("~"), "AriesLegacy_Outputs")
        os.makedirs(d, exist_ok=True)
        return d

    def _set_status(self, text: str):
        if hasattr(self, "lblStatus"):
            self.lblStatus.setText(text)

    def _set_progress(self, val: int):
        if hasattr(self, "progressBar"):
            self.progressBar.setValue(val)

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()
