"""
AriesLegacy - QGIS Geo AI Plugin.
Plugin initialization and factory definition.
"""

def classFactory(iface):
    """Load AriesLegacy class from file arieslegacy.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .arieslegacy import AriesLegacy
    return AriesLegacy(iface)
