"""
AriesLegacy - Processing Provider.
Registers all AriesLegacy algorithms in the QGIS Processing Toolbox.
"""

import os

try:
    from qgis.core import QgsProcessingProvider
    from qgis.PyQt.QtGui import QIcon
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingProvider:
        pass

from .algorithms.index_calculation_algorithm import IndexCalculationAlgorithm
from .algorithms.batch_indices_algorithm import BatchIndicesAlgorithm
from .algorithms.change_detection_algorithm import ChangeDetectionAlgorithm
from .algorithms.classification_stats_algorithm import ClassificationStatsAlgorithm


class AriesLegacyProcessingProvider(QgsProcessingProvider):
    """QGIS Processing Provider for AriesLegacy."""

    def id(self):
        return "arieslegacy"

    def name(self):
        return "AriesLegacy (Geo AI)"

    def icon(self):
        if not HAS_QGIS:
            return None
        icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "icons", "icon.svg")
        if os.path.exists(icon_path):
            return QIcon(icon_path)
        return super().icon()

    def loadAlgorithms(self):
        self.addAlgorithm(IndexCalculationAlgorithm())
        self.addAlgorithm(BatchIndicesAlgorithm())
        self.addAlgorithm(ChangeDetectionAlgorithm())
        self.addAlgorithm(ClassificationStatsAlgorithm())


# Compatibility alias
AriesLegacyProcessingProvider = AriesLegacyProcessingProvider
