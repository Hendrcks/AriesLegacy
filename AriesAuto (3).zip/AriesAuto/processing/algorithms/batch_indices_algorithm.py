"""
AriesLegacy - Batch Multi-Index Calculation Processing Algorithm.
Supports ticking multiple band layers and batch processing all compatible indices.
"""

import os
from typing import Dict, Any, List

try:
    from qgis.core import (
        QgsProcessing,
        QgsProcessingAlgorithm,
        QgsProcessingParameterMultipleLayers,
        QgsProcessingParameterEnum,
        QgsProcessingParameterBoolean,
        QgsProcessingParameterFolderDestination,
        QgsProcessingException,
        QgsRasterLayer,
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm:
        pass

try:
    from qgis.analysis import QgsRasterCalculator, QgsRasterCalculatorEntry
except ImportError:
    QgsRasterCalculator = None
    QgsRasterCalculatorEntry = None

from ...core.index_library import IndexLibrary
from ...core.sensor_profiles import SensorProfileManager
from ...core.band_detector import BandDetector
from ...core.raster_preprocessor import RasterPreprocessor


class BatchIndicesAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYERS = "INPUT_LAYERS"
    SENSOR_ID = "SENSOR_ID"
    APPLY_SCALING = "APPLY_SCALING"
    OUTPUT_FOLDER = "OUTPUT_FOLDER"

    def __init__(self):
        super().__init__()
        self.index_lib = IndexLibrary.get_instance()
        self.sensor_mgr = SensorProfileManager.get_instance()
        self.band_detector = BandDetector(self.sensor_mgr)

    def createInstance(self):
        return BatchIndicesAlgorithm()

    def name(self):
        return "batch_calculate_indices"

    def displayName(self):
        return "Batch Calculate Multiple Indices"

    def group(self):
        return "Indices"

    def groupId(self):
        return "indices"

    def shortHelpString(self):
        return (
            "Calculates all compatible indices in batch.\n\n"
            "Simply **tick/select your loaded band layers** (e.g. Red, NIR, Green, SWIR). "
            "AriesLegacy will detect the bands and compute all possible indices into the chosen folder."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return

        # 1. Tick/Select Multiple Band Layers
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_LAYERS,
                "Tick / Select Input Band Rasters (e.g. Red, NIR, Green, SWIR)",
                layerType=QgsProcessing.TypeRaster
            )
        )

        sensors = self.sensor_mgr.list_profiles()
        sensor_names = [s.name for s in sensors]
        self.addParameter(
            QgsProcessingParameterEnum(
                self.SENSOR_ID,
                "Sensor Profile (Calibration & Scaling)",
                options=sensor_names,
                defaultValue=0
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.APPLY_SCALING,
                "Apply Radiometric Scale Factor",
                defaultValue=True
            )
        )

        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_FOLDER,
                "Output Directory for Calculated Indices"
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {self.OUTPUT_FOLDER: parameters.get(self.OUTPUT_FOLDER)}

        ticked_layers = self.parameterAsLayerList(parameters, self.INPUT_LAYERS, context)
        sensor_enum = self.parameterAsEnum(parameters, self.SENSOR_ID, context)
        apply_scaling = self.parameterAsBoolean(parameters, self.APPLY_SCALING, context)
        out_dir = self.parameterAsString(parameters, self.OUTPUT_FOLDER, context)

        if not ticked_layers:
            raise QgsProcessingException("No raster layers were ticked. Please tick input band layers.")

        if not os.path.exists(out_dir):
            os.makedirs(out_dir, exist_ok=True)

        sensor_profile = self.sensor_mgr.list_profiles()[sensor_enum]

        # Map ticked layers to canonical bands
        layers_info = []
        for lyr in ticked_layers:
            if lyr and lyr.isValid():
                layers_info.append({"id": lyr.id(), "name": lyr.name(), "source": lyr.source(), "layer": lyr})

        det_result = self.band_detector.detect_from_layer_collection(layers_info)
        
        mapped_bands = {}
        for l_info in layers_info:
            lid = l_info["id"]
            lyr = l_info["layer"]
            for canonical, det_lid in det_result.band_to_layer_id.items():
                if det_lid == lid:
                    mapped_bands[canonical] = (lyr, 1)

            if lyr.bandCount() > 1:
                multiband_det = self.band_detector.detect_from_file_path(lyr.source(), lyr.bandCount())
                for canonical, bnum in multiband_det.band_to_number.items():
                    if canonical not in mapped_bands:
                        mapped_bands[canonical] = (lyr, bnum)

        feedback.pushInfo(f"Detected Bands: {', '.join(mapped_bands.keys())}")

        if not mapped_bands:
            raise QgsProcessingException("Could not identify canonical bands in the ticked layers.")

        ref_layer = list(mapped_bands.values())[0][0]
        calculated_count = 0

        for index_def in self.index_lib.list_all():
            if not index_def.is_compatible_with_sensor(sensor_profile.id):
                continue
            if all(b in mapped_bands for b in index_def.required_bands):
                feedback.pushInfo(f"Calculating {index_def.short_name}...")
                entries = []
                band_refs = {}
                for b in index_def.required_bands:
                    lyr, bnum = mapped_bands[b]
                    entry_ref = f"{b}_{index_def.id}@{bnum}"
                    calc_entry = QgsRasterCalculatorEntry()
                    calc_entry.ref = entry_ref
                    calc_entry.raster = lyr
                    calc_entry.bandNumber = bnum
                    entries.append(calc_entry)
                    band_refs[b] = f'"{entry_ref}"'

                expr = RasterPreprocessor.build_full_index_expression(
                    index_def.safe_formula,
                    band_refs,
                    sensor_profile,
                    apply_scaling=apply_scaling
                )

                out_file = os.path.join(out_dir, f"{index_def.short_name}.tif")
                calc = QgsRasterCalculator(
                    expr,
                    out_file,
                    "GTiff",
                    ref_layer.extent(),
                    ref_layer.width(),
                    ref_layer.height(),
                    entries
                )
                res = calc.processCalculation(feedback)
                if res == 0:
                    calculated_count += 1
                    feedback.pushInfo(f"Saved: {out_file}")

        feedback.pushInfo(f"AriesLegacy: Completed! {calculated_count} index rasters generated in {out_dir}")
        return {self.OUTPUT_FOLDER: out_dir}
