"""
AriesLegacy - Single Index Calculation Processing Algorithm.
Supports ticking multiple band layers or selecting a composite stack.
"""

import os
from typing import Dict, Any, List, Optional

try:
    from qgis.core import (
        QgsProcessing,
        QgsProcessingAlgorithm,
        QgsProcessingParameterMultipleLayers,
        QgsProcessingParameterRasterLayer,
        QgsProcessingParameterEnum,
        QgsProcessingParameterBoolean,
        QgsProcessingParameterNumber,
        QgsProcessingParameterRasterDestination,
        QgsProcessingOutputRasterLayer,
        QgsProcessingException,
        QgsRasterLayer,
        QgsProject
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm:
        pass

try:
    from qgis.analysis import QgsRasterCalculator, QgsRasterCalculatorEntry
except ImportError:
    QgsRasterCalculator = None
    QgsRasterCalculatorEntry = None

from ...core.index_library import IndexLibrary
from ...core.sensor_profiles import SensorProfileManager
from ...core.band_detector import BandDetector
from ...core.raster_preprocessor import RasterPreprocessor


class IndexCalculationAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYERS = "INPUT_LAYERS"
    INDEX_ID = "INDEX_ID"
    SENSOR_ID = "SENSOR_ID"
    APPLY_SCALING = "APPLY_SCALING"
    OUTPUT = "OUTPUT"

    def __init__(self):
        super().__init__()
        self.index_lib = IndexLibrary.get_instance()
        self.sensor_mgr = SensorProfileManager.get_instance()
        self.band_detector = BandDetector(self.sensor_mgr)

    def createInstance(self):
        return IndexCalculationAlgorithm()

    def name(self):
        return "calculate_index"

    def displayName(self):
        return "Calculate Spatial Index"

    def group(self):
        return "Indices"

    def groupId(self):
        return "indices"

    def shortHelpString(self):
        return (
            "Calculates a selected geospatial index (e.g., NDVI, EVI, MNDWI, NDBI, BSI, NBR, LST).\n\n"
            "Simply **tick/select the input band rasters** (e.g. Red, NIR, Green, SWIR layers). "
            "AriesLegacy automatically recognizes the sensor and maps the required bands."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return

        # 1. Tick/Select Multiple Band Layers
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_LAYERS,
                "Tick / Select Input Band Rasters (e.g. Red, NIR, Green, SWIR)",
                layerType=QgsProcessing.TypeRaster
            )
        )

        # 2. Geospatial Index Selection
        indices = self.index_lib.list_all()
        index_names = [f"{idx.short_name} — {idx.name}" for idx in indices]
        self.addParameter(
            QgsProcessingParameterEnum(
                self.INDEX_ID,
                "Select Geospatial Index",
                options=index_names,
                defaultValue=0
            )
        )

        # 3. Sensor Profile
        sensors = self.sensor_mgr.list_profiles()
        sensor_names = [s.name for s in sensors]
        self.addParameter(
            QgsProcessingParameterEnum(
                self.SENSOR_ID,
                "Sensor Profile (Calibration & Scaling)",
                options=sensor_names,
                defaultValue=0
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.APPLY_SCALING,
                "Apply Radiometric Scale Factor (e.g. 0.0001 for S2 L2A)",
                defaultValue=True
            )
        )

        # Output
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                "Output Index Raster"
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {self.OUTPUT: parameters.get(self.OUTPUT)}

        ticked_layers = self.parameterAsLayerList(parameters, self.INPUT_LAYERS, context)
        idx_enum = self.parameterAsEnum(parameters, self.INDEX_ID, context)
        sensor_enum = self.parameterAsEnum(parameters, self.SENSOR_ID, context)
        apply_scaling = self.parameterAsBoolean(parameters, self.APPLY_SCALING, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if not ticked_layers:
            raise QgsProcessingException("No raster layers were ticked. Please tick at least the required band layers.")

        index_def = self.index_lib.list_all()[idx_enum]
        sensor_profile = self.sensor_mgr.list_profiles()[sensor_enum]

        feedback.pushInfo(f"AriesLegacy: Analyzing {len(ticked_layers)} ticked band layer(s)...")

        # Map ticked layers to canonical bands
        layers_info = []
        for lyr in ticked_layers:
            if lyr and lyr.isValid():
                layers_info.append({"id": lyr.id(), "name": lyr.name(), "source": lyr.source(), "layer": lyr})

        # Run automated band detector across ticked layers
        det_result = self.band_detector.detect_from_layer_collection(layers_info)
        
        # Build layer map: canonical -> (layer, bandNumber)
        mapped_bands = {}
        for l_info in layers_info:
            lid = l_info["id"]
            lyr = l_info["layer"]
            # Check if this layer is one of the detected canonical bands
            for canonical, det_lid in det_result.band_to_layer_id.items():
                if det_lid == lid:
                    mapped_bands[canonical] = (lyr, 1)

            # If layer is multiband composite
            if lyr.bandCount() > 1:
                multiband_det = self.band_detector.detect_from_file_path(lyr.source(), lyr.bandCount())
                for canonical, bnum in multiband_det.band_to_number.items():
                    if canonical not in mapped_bands:
                        mapped_bands[canonical] = (lyr, bnum)

        feedback.pushInfo(f"Detected Bands in ticked layers: {', '.join(mapped_bands.keys())}")

        if index_def.id in ("lst", "lst_c") and sensor_profile.id == "sentinel_2_l2a":
            raise QgsProcessingException(
                "Sentinel-2 does not have a thermal infrared band. "
                "Land Surface Temperature (LST) requires Landsat Collection 2 Level-2 Surface Temperature (ST_B10)."
            )

        # Sentinel-2 10m / 20m resolution notice
        if sensor_profile.id == "sentinel_2_l2a" and any(b in ("SWIR_1", "SWIR_2") for b in index_def.required_bands):
            feedback.pushInfo("Resolution Notice: Calculating output at 20 m because Sentinel-2 SWIR is 20 m.")

        # Validate that the requested index has all required bands
        missing = [b for b in index_def.required_bands if b not in mapped_bands]
        if missing:
            raise QgsProcessingException(
                f"Cannot calculate '{index_def.short_name}'. "
                f"Missing required band(s): {', '.join(missing)}.\n"
                f"Ticked bands only provided: {', '.join(mapped_bands.keys()) if mapped_bands else 'None'}."
            )

        entries = []
        band_refs = {}
        ref_layer = mapped_bands[index_def.required_bands[0]][0]

        for canonical in index_def.required_bands:
            lyr, bnum = mapped_bands[canonical]
            entry_ref = f"{canonical}_{index_def.id}@{bnum}"
            calc_entry = QgsRasterCalculatorEntry()
            calc_entry.ref = entry_ref
            calc_entry.raster = lyr
            calc_entry.bandNumber = bnum
            entries.append(calc_entry)
            band_refs[canonical] = f'"{entry_ref}"'

        expr = RasterPreprocessor.build_full_index_expression(
            index_def.safe_formula,
            band_refs,
            sensor_profile,
            apply_scaling=apply_scaling
        )

        feedback.pushInfo(f"Raster Calculator Expression: {expr}")

        calc = QgsRasterCalculator(
            expr,
            output_path,
            "GTiff",
            ref_layer.extent(),
            ref_layer.width(),
            ref_layer.height(),
            entries
        )

        res = calc.processCalculation(feedback)
        if res != 0:
            raise QgsProcessingException(f"QGIS Raster Calculator failed with error code: {res}")

        feedback.pushInfo(f"Successfully calculated {index_def.short_name} -> {output_path}")
        return {self.OUTPUT: output_path}
