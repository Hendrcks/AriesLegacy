"""
AriesLegacy Processing Algorithms.
"""
