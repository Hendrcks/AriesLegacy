"""
AriesLegacy - Two-Date Change Detection Processing Algorithm.
"""

try:
    from qgis.core import (
        QgsProcessingAlgorithm,
        QgsProcessingParameterRasterLayer,
        QgsProcessingParameterEnum,
        QgsProcessingParameterNumber,
        QgsProcessingParameterRasterDestination,
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm:
        pass


class ChangeDetectionAlgorithm(QgsProcessingAlgorithm):
    PRE_RASTER = "PRE_RASTER"
    POST_RASTER = "POST_RASTER"
    CHANGE_MODE = "CHANGE_MODE"
    LOSS_THRESHOLD = "LOSS_THRESHOLD"
    GAIN_THRESHOLD = "GAIN_THRESHOLD"
    OUTPUT = "OUTPUT"

    def createInstance(self):
        return ChangeDetectionAlgorithm()

    def name(self):
        return "change_detection"

    def displayName(self):
        return "Two-Date Index Change Detection"

    def group(self):
        return "Change Detection"

    def groupId(self):
        return "change"

    def shortHelpString(self):
        return "Compares two temporal index rasters (Before and After) to compute difference, % change, or Gain/Loss thematic classes."

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.PRE_RASTER,
                "Pre-Date (Before) Index Raster"
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.POST_RASTER,
                "Post-Date (After) Index Raster"
            )
        )

        modes = [
            "Absolute Difference (Post - Pre)",
            "Percentage Change (%)",
            "Gain / No-Change / Loss Classification",
            "dNBR (Pre_NBR - Post_NBR)"
        ]
        self.addParameter(
            QgsProcessingParameterEnum(
                self.CHANGE_MODE,
                "Change Detection Mode",
                options=modes,
                defaultValue=0
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.LOSS_THRESHOLD,
                "Significant Loss Threshold (e.g. -0.1)",
                type=QgsProcessingParameterNumber.Double,
                defaultValue=-0.1
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.GAIN_THRESHOLD,
                "Significant Gain Threshold (e.g. 0.1)",
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.1
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                "Output Change Raster"
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        feedback.pushInfo("AriesLegacy: Running two-date change detection...")
        return {self.OUTPUT: parameters.get(self.OUTPUT)}
