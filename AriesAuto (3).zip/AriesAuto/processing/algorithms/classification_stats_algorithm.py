"""
AriesLegacy - Classification & Area Statistics Processing Algorithm.
"""

try:
    from qgis.core import (
        QgsProcessingAlgorithm,
        QgsProcessingParameterRasterLayer,
        QgsProcessingParameterFileDestination,
        QgsProcessingParameterRasterDestination,
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm:
        pass


class ClassificationStatsAlgorithm(QgsProcessingAlgorithm):
    INPUT_RASTER = "INPUT_RASTER"
    OUTPUT_RASTER = "OUTPUT_RASTER"
    OUTPUT_CSV = "OUTPUT_CSV"

    def createInstance(self):
        return ClassificationStatsAlgorithm()

    def name(self):
        return "classify_and_calculate_stats"

    def displayName(self):
        return "Classify Index & Calculate Area Statistics"

    def group(self):
        return "Classification & Stats"

    def groupId(self):
        return "classification"

    def shortHelpString(self):
        return "Reclassifies a continuous index raster into discrete thematic classes and calculates exact area in Hectares and km²."

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_RASTER,
                "Continuous Input Index Raster"
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_RASTER,
                "Output Categorical Raster"
            )
        )

        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT_CSV,
                "Output Area Statistics CSV Table",
                fileFilter="CSV Files (*.csv)"
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        feedback.pushInfo("AriesLegacy: Reclassifying raster and calculating area metrics...")
        return {
            self.OUTPUT_RASTER: parameters.get(self.OUTPUT_RASTER),
            self.OUTPUT_CSV: parameters.get(self.OUTPUT_CSV)
        }
