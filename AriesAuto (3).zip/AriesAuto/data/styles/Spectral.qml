<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe>
    <rasterrenderer type="singlebandpseudocolor" opacity="1" alphaBand="-1" band="1" classificationMin="-0.5" classificationMax="0.8">
      <rastershader>
        <colorrampshader colorRampType="INTERPOLATED" clip="0" classificationMode="1">
          <colorramplabelprefix></colorramplabelprefix>
          <colorramplabelsuffix></colorramplabelsuffix>
          <item value="-0.5" label="-0.50 (Burned/Disturbed)" color="#9e0142" alpha="255"/>
          <item value="-0.2" label="-0.20" color="#d53e4f" alpha="255"/>
          <item value="0.0" label="0.00" color="#fee08b" alpha="255"/>
          <item value="0.3" label="0.30" color="#e6f598" alpha="255"/>
          <item value="0.5" label="0.50" color="#66c2a5" alpha="255"/>
          <item value="0.8" label="0.80 (Healthy Canopy)" color="#5e4fa2" alpha="255"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
