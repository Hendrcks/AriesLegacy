<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe>
    <rasterrenderer type="singlebandpseudocolor" opacity="1" alphaBand="-1" band="1" classificationMin="10" classificationMax="50">
      <rastershader>
        <colorrampshader colorRampType="INTERPOLATED" clip="0" classificationMode="1">
          <colorramplabelprefix></colorramplabelprefix>
          <colorramplabelsuffix> °C</colorramplabelsuffix>
          <item value="10" label="10.0 °C (Cool)" color="#000004" alpha="255"/>
          <item value="20" label="20.0 °C" color="#51127c" alpha="255"/>
          <item value="30" label="30.0 °C" color="#b73779" alpha="255"/>
          <item value="40" label="40.0 °C" color="#fc8961" alpha="255"/>
          <item value="50" label="50.0 °C (Hot)" color="#fcfdbf" alpha="255"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
