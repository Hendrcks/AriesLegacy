<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe>
    <rasterrenderer type="singlebandpseudocolor" opacity="1" alphaBand="-1" band="1" classificationMin="-0.2" classificationMax="0.8">
      <rastershader>
        <colorrampshader colorRampType="INTERPOLATED" clip="0" classificationMode="1">
          <colorramplabelprefix></colorramplabelprefix>
          <colorramplabelsuffix></colorramplabelsuffix>
          <item value="-0.2" label="-0.20" color="#d7191c" alpha="255"/>
          <item value="0.0" label="0.00" color="#fdae61" alpha="255"/>
          <item value="0.3" label="0.30" color="#ffffbf" alpha="255"/>
          <item value="0.5" label="0.50" color="#a6d96a" alpha="255"/>
          <item value="0.8" label="0.80" color="#1a9641" alpha="255"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <huesaturation colorizeGreen="128" colorizeOn="0" colorizeRed="255" colorizeBlue="128" saturation="0" grayscaleMode="0" colorizeStrength="100"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
