<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe>
    <rasterrenderer type="singlebandpseudocolor" opacity="1" alphaBand="-1" band="1" classificationMin="-0.5" classificationMax="0.5">
      <rastershader>
        <colorrampshader colorRampType="INTERPOLATED" clip="0" classificationMode="1">
          <colorramplabelprefix></colorramplabelprefix>
          <colorramplabelsuffix></colorramplabelsuffix>
          <item value="-0.5" label="-0.50 (Dry/Land)" color="#ffffd9" alpha="255"/>
          <item value="-0.1" label="-0.10" color="#c7e9b4" alpha="255"/>
          <item value="0.0" label="0.00 (Threshold)" color="#7fcdbb" alpha="255"/>
          <item value="0.2" label="0.20" color="#41b6c4" alpha="255"/>
          <item value="0.5" label="0.50 (Water)" color="#225ea8" alpha="255"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
