<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe>
    <rasterrenderer type="singlebandpseudocolor" opacity="1" alphaBand="-1" band="1" classificationMin="-0.4" classificationMax="0.5">
      <rastershader>
        <colorrampshader colorRampType="INTERPOLATED" clip="0" classificationMode="1">
          <colorramplabelprefix></colorramplabelprefix>
          <colorramplabelsuffix></colorramplabelsuffix>
          <item value="-0.4" label="-0.40 (Vegetation)" color="#ffffd4" alpha="255"/>
          <item value="-0.1" label="-0.10" color="#fed98e" alpha="255"/>
          <item value="0.0" label="0.00" color="#fe9929" alpha="255"/>
          <item value="0.2" label="0.20" color="#d95f0e" alpha="255"/>
          <item value="0.5" label="0.50 (Built-up / Bare)" color="#993404" alpha="255"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
