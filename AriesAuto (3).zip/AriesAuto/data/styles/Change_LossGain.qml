<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe>
    <rasterrenderer type="paletted" opacity="1" alphaBand="-1" band="1">
      <rasterProperties>
        <items>
          <item value="-1" label="Significant Loss / Degradation" color="#d73027" alpha="255"/>
          <item value="0" label="No Significant Change" color="#ffffbf" alpha="255"/>
          <item value="1" label="Significant Gain / Improvement" color="#1a9850" alpha="255"/>
        </items>
      </rasterProperties>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
