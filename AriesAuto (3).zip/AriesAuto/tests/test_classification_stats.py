"""
Unit tests for Classifier and AreaStatisticsCalculator.
"""

import unittest
from core.classifier import Classifier, ClassificationScheme, ThresholdClass
from core.area_statistics import AreaStatisticsCalculator


class TestClassificationStats(unittest.TestCase):

    def test_reclassification(self):
        scheme = ClassificationScheme("Test")
        scheme.classes = [
            ThresholdClass(1, -1.0, 0.0, "Non-Veg"),
            ThresholdClass(2, 0.0, 0.5, "Sparse"),
            ThresholdClass(3, 0.5, 1.0, "Dense"),
        ]
        arr = [[-0.5, 0.2], [0.7, 0.0]]
        classified = Classifier.classify_numpy_array(arr, scheme)
        # -0.5 -> 1, 0.2 -> 2, 0.7 -> 3, 0.0 -> 2
        self.assertEqual(classified, [[1, 2], [3, 2]])

    def test_area_statistics_hectares(self):
        # 10m x 10m pixels = 100 m² per pixel = 0.01 hectares per pixel
        # 100 pixels in class 1 = 10,000 m² = 1.0 hectare
        # 300 pixels in class 2 = 30,000 m² = 3.0 hectares
        arr = [1]*100 + [2]*300
        stats = AreaStatisticsCalculator.calculate_categorical_stats(
            arr,
            pixel_size_x=10.0,
            pixel_size_y=10.0,
            class_labels={1: "Class A", 2: "Class B"}
        )

        self.assertEqual(stats.total_valid_pixels, 400)
        self.assertAlmostEqual(stats.total_area_ha, 4.0, places=4)
        self.assertEqual(len(stats.classes), 2)
        self.assertAlmostEqual(stats.classes[0].area_ha, 1.0, places=4)
        self.assertAlmostEqual(stats.classes[0].percentage, 25.0, places=2)
        self.assertAlmostEqual(stats.classes[1].area_ha, 3.0, places=4)
        self.assertAlmostEqual(stats.classes[1].percentage, 75.0, places=2)


if __name__ == "__main__":
    unittest.main()
