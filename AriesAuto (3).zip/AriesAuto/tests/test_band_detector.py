"""
Unit tests for BandDetector and SensorProfiles.
"""

import unittest
from core.sensor_profiles import SensorProfileManager
from core.band_detector import BandDetector


class TestBandDetector(unittest.TestCase):

    def setUp(self):
        self.profile_mgr = SensorProfileManager.get_instance()
        self.detector = BandDetector(self.profile_mgr)

    def test_sentinel2_detection(self):
        filename = "S2A_MSIL2A_20240115T101321_N0510_R008_T30NXM_20240115T134512.SAFE"
        sensor = self.detector.detect_sensor_from_text(filename)
        self.assertEqual(sensor.id, "sentinel_2_l2a")
        self.assertEqual(sensor.scale_factor, 0.0001)

    def test_landsat_detection(self):
        filename = "LC08_L2SP_194055_20230214_02_T1_SR_B4.TIF"
        sensor = self.detector.detect_sensor_from_text(filename)
        self.assertEqual(sensor.id, "landsat_8_9_c2_l2")
        self.assertEqual(sensor.scale_factor, 0.0000275)

    def test_single_band_identification(self):
        s2_res = self.detector.detect_from_file_path("T30NXM_20240115_B04_10m.jp2", band_count=1)
        self.assertIn("RED", s2_res.band_to_number)
        
        s2_nir_res = self.detector.detect_from_file_path("T30NXM_20240115_B08_10m.jp2", band_count=1)
        self.assertIn("NIR", s2_nir_res.band_to_number)

    def test_multiband_s2_stack(self):
        res = self.detector.detect_from_file_path("S2A_L2A_12Bands_Stack.tif", band_count=12)
        self.assertIn("RED", res.band_to_number)
        self.assertIn("NIR", res.band_to_number)
        self.assertEqual(res.band_to_number["RED"], 4)
        self.assertEqual(res.band_to_number["NIR"], 8)


if __name__ == "__main__":
    unittest.main()
