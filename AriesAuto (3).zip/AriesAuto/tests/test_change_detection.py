"""
Unit tests for ChangeDetector.
"""

import unittest
from core.change_detection import ChangeDetector


class TestChangeDetection(unittest.TestCase):

    def test_absolute_difference(self):
        pre = [[0.6, 0.4], [0.2, 0.8]]
        post = [[0.3, 0.4], [0.5, 0.9]]
        diff = ChangeDetector.calculate_absolute_difference(pre, post)
        # Expected: [[-0.3, 0.0], [0.3, 0.1]]
        self.assertAlmostEqual(diff[0][0], -0.3, places=5)
        self.assertAlmostEqual(diff[0][1], 0.0, places=5)
        self.assertAlmostEqual(diff[1][0], 0.3, places=5)
        self.assertAlmostEqual(diff[1][1], 0.1, places=5)

    def test_gain_loss_classification(self):
        diff = [[-0.25, 0.02], [0.15, -0.05]]
        classes = ChangeDetector.classify_gain_loss(diff, loss_threshold=-0.1, gain_threshold=0.1)
        # 1: Loss (< -0.1), 2: No change (-0.1 to 0.1), 3: Gain (> 0.1)
        # Expected: [[1, 2], [3, 2]]
        self.assertEqual(classes, [[1, 2], [3, 2]])

    def test_dnbr_calculation(self):
        pre_nbr = [[0.7, 0.5]]
        post_nbr = [[0.1, 0.4]]
        dnbr = ChangeDetector.calculate_dnbr(pre_nbr, post_nbr)
        # dNBR = Pre - Post -> [[0.6, 0.1]]
        self.assertAlmostEqual(dnbr[0][0], 0.6, places=5)
        self.assertAlmostEqual(dnbr[0][1], 0.1, places=5)


if __name__ == "__main__":
    unittest.main()
