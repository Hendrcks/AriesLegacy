"""
Unit tests for IndexLibrary and IndexDefinition.
"""

import unittest
from core.index_library import IndexLibrary, IndexDefinition


class TestIndexLibrary(unittest.TestCase):

    def setUp(self):
        self.lib = IndexLibrary.get_instance()

    def test_library_not_empty(self):
        indices = self.lib.list_all()
        self.assertGreaterEqual(len(indices), 10, "Expected at least 10 core indices in library.")

    def test_core_indices_present(self):
        core_ids = ["ndvi", "evi", "savi", "ndmi", "ndwi", "mndwi", "ndbi", "bsi", "nbr", "lst"]
        for cid in core_ids:
            idx = self.lib.get_index(cid)
            self.assertIsNotNone(idx, f"Expected index '{cid}' to be present in library.")
            self.assertTrue(len(idx.required_bands) > 0, f"Index '{cid}' must have required bands.")
            self.assertTrue(len(idx.formula) > 0, f"Index '{cid}' must have a formula.")
            self.assertTrue(len(idx.reference) > 0, f"Index '{cid}' must have scientific reference.")

    def test_search_and_filter(self):
        veg_indices = self.lib.filter_by_group("Vegetation")
        self.assertGreater(len(veg_indices), 0)
        
        search_results = self.lib.search("water")
        self.assertTrue(any(idx.id in ["ndwi", "mndwi", "awei_nsh"] for idx in search_results))


if __name__ == "__main__":
    unittest.main()
