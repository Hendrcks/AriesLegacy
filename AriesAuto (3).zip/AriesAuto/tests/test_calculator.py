"""
Comprehensive Unit Tests for AriesLegacy Formula & Algorithm Specification.
Validates all formulas, mandatory benchmarks, Landsat/Sentinel scaling, safe divide, and MSAVI2 square-root protection.
"""

import unittest
import math
from core.index_library import IndexLibrary
from core.sensor_profiles import SensorProfileManager
from core.index_calculator import IndexCalculator
from core.raster_validator import RasterValidator


class TestFormulaSpecification(unittest.TestCase):

    def setUp(self):
        self.lib = IndexLibrary.get_instance()
        self.sensor_mgr = SensorProfileManager.get_instance()
        self.s2_sensor = self.sensor_mgr.get_profile("sentinel_2_l2a")
        self.landsat8_sensor = self.sensor_mgr.get_profile("landsat_8_9_c2_l2")
        self.generic_sensor = self.sensor_mgr.get_profile("generic")

    def test_section_8_mandatory_ndvi_benchmark(self):
        """
        Tests the mandatory NDVI test table from Section 8 of the specification:
        Healthy vegetation: NIR=0.60, RED=0.10 -> 0.7142857 (+-0.0001)
        Bare soil: NIR=0.30, RED=0.25 -> 0.0909091 (+-0.0001)
        Water: NIR=0.02, RED=0.04 -> -0.3333333 (+-0.0001)
        """
        ndvi_def = self.lib.get_index("ndvi")

        # 1. Healthy vegetation
        res_veg = IndexCalculator.calculate_pure_numpy(
            ndvi_def, {"NIR": 0.60, "RED": 0.10}, self.generic_sensor, apply_scaling=False
        )
        self.assertAlmostEqual(float(res_veg), 0.7142857, delta=0.0001)

        # 2. Bare soil
        res_soil = IndexCalculator.calculate_pure_numpy(
            ndvi_def, {"NIR": 0.30, "RED": 0.25}, self.generic_sensor, apply_scaling=False
        )
        self.assertAlmostEqual(float(res_soil), 0.0909091, delta=0.0001)

        # 3. Water
        res_water = IndexCalculator.calculate_pure_numpy(
            ndvi_def, {"NIR": 0.02, "RED": 0.04}, self.generic_sensor, apply_scaling=False
        )
        self.assertAlmostEqual(float(res_water), -0.3333333, delta=0.0001)

    def test_vegetation_indices_formulas(self):
        """Tests GNDVI, EVI, SAVI, MSAVI2, NDMI formulas."""
        # GNDVI: (NIR - GREEN) / (NIR + GREEN)
        gndvi_def = self.lib.get_index("gndvi")
        res_gndvi = IndexCalculator.calculate_pure_numpy(
            gndvi_def, {"NIR": 0.50, "GREEN": 0.10}, self.generic_sensor, apply_scaling=False
        )
        # (0.50 - 0.10)/(0.50 + 0.10) = 0.40 / 0.60 = 0.66667
        self.assertAlmostEqual(float(res_gndvi), 0.6666667, delta=0.0001)

        # EVI: 2.5 * (NIR - RED) / (NIR + 6*RED - 7.5*BLUE + 1)
        evi_def = self.lib.get_index("evi")
        res_evi = IndexCalculator.calculate_pure_numpy(
            evi_def, {"NIR": 0.50, "RED": 0.10, "BLUE": 0.05}, self.generic_sensor, apply_scaling=False
        )
        # Denom = 0.50 + 6*0.10 - 7.5*0.05 + 1.0 = 0.50 + 0.60 - 0.375 + 1.0 = 1.725
        # Num = 2.5 * 0.40 = 1.0 -> 1.0 / 1.725 = 0.579710
        self.assertAlmostEqual(float(res_evi), 0.579710, delta=0.0001)

        # SAVI (L=0.5): 1.5 * (NIR - RED) / (NIR + RED + 0.5)
        savi_def = self.lib.get_index("savi")
        res_savi = IndexCalculator.calculate_pure_numpy(
            savi_def, {"NIR": 0.50, "RED": 0.10}, self.generic_sensor, apply_scaling=False
        )
        # 1.5 * (0.40) / (0.50 + 0.10 + 0.5) = 0.60 / 1.10 = 0.545454
        self.assertAlmostEqual(float(res_savi), 0.5454545, delta=0.0001)

        # MSAVI2: (2*NIR + 1 - sqrt((2*NIR + 1)^2 - 8*(NIR - RED))) / 2
        msavi_def = self.lib.get_index("msavi")
        res_msavi = IndexCalculator.calculate_pure_numpy(
            msavi_def, {"NIR": 0.50, "RED": 0.10}, self.generic_sensor, apply_scaling=False
        )
        # 2*0.5 + 1 = 2.0. Term = 4.0 - 8*(0.4) = 4.0 - 3.2 = 0.8
        # (2.0 - sqrt(0.8)) / 2.0 = (2.0 - 0.894427) / 2.0 = 0.552786
        self.assertAlmostEqual(float(res_msavi), 0.552786, delta=0.0001)

        # NDMI: (NIR - SWIR1) / (NIR + SWIR1)
        ndmi_def = self.lib.get_index("ndmi")
        res_ndmi = IndexCalculator.calculate_pure_numpy(
            ndmi_def, {"NIR": 0.50, "SWIR_1": 0.20}, self.generic_sensor, apply_scaling=False
        )
        # (0.50 - 0.20)/(0.50 + 0.20) = 0.30 / 0.70 = 0.428571
        self.assertAlmostEqual(float(res_ndmi), 0.428571, delta=0.0001)

    def test_water_and_flood_formulas(self):
        """Tests NDWI, MNDWI, AWEI_nsh, AWEI_sh formulas."""
        # NDWI: (GREEN - NIR) / (GREEN + NIR)
        ndwi_def = self.lib.get_index("ndwi")
        res_ndwi = IndexCalculator.calculate_pure_numpy(
            ndwi_def, {"GREEN": 0.30, "NIR": 0.10}, self.generic_sensor, apply_scaling=False
        )
        # (0.3 - 0.1) / (0.3 + 0.1) = 0.2 / 0.4 = 0.5
        self.assertAlmostEqual(float(res_ndwi), 0.5, delta=0.0001)

        # MNDWI: (GREEN - SWIR1) / (GREEN + SWIR1)
        mndwi_def = self.lib.get_index("mndwi")
        res_mndwi = IndexCalculator.calculate_pure_numpy(
            mndwi_def, {"GREEN": 0.30, "SWIR_1": 0.05}, self.generic_sensor, apply_scaling=False
        )
        # (0.30 - 0.05) / (0.30 + 0.05) = 0.25 / 0.35 = 0.714286
        self.assertAlmostEqual(float(res_mndwi), 0.714286, delta=0.0001)

        # AWEI_nsh: 4*(GREEN - SWIR1) - (0.25*NIR + 2.75*SWIR2)
        awei_nsh_def = self.lib.get_index("awei_nsh")
        res_awei_nsh = IndexCalculator.calculate_pure_numpy(
            awei_nsh_def, {"GREEN": 0.30, "SWIR_1": 0.10, "NIR": 0.20, "SWIR_2": 0.05}, self.generic_sensor, apply_scaling=False
        )
        # 4*(0.20) - (0.25*0.20 + 2.75*0.05) = 0.80 - (0.05 + 0.1375) = 0.80 - 0.1875 = 0.6125
        self.assertAlmostEqual(float(res_awei_nsh), 0.6125, delta=0.0001)

        # AWEI_sh: BLUE + 2.5*GREEN - 1.5*(NIR + SWIR1) - 0.25*SWIR2
        awei_sh_def = self.lib.get_index("awei_sh")
        res_awei_sh = IndexCalculator.calculate_pure_numpy(
            awei_sh_def, {"BLUE": 0.10, "GREEN": 0.30, "NIR": 0.20, "SWIR_1": 0.10, "SWIR_2": 0.05}, self.generic_sensor, apply_scaling=False
        )
        # 0.10 + 2.5*0.30 - 1.5*(0.30) - 0.25*0.05 = 0.10 + 0.75 - 0.45 - 0.0125 = 0.3875
        self.assertAlmostEqual(float(res_awei_sh), 0.3875, delta=0.0001)

    def test_built_up_and_soil_and_fire_formulas(self):
        """Tests NDBI, UI, BSI, NBR, NBR2 formulas."""
        # NDBI: (SWIR1 - NIR) / (SWIR1 + NIR)
        ndbi_def = self.lib.get_index("ndbi")
        res_ndbi = IndexCalculator.calculate_pure_numpy(
            ndbi_def, {"SWIR_1": 0.40, "NIR": 0.20}, self.generic_sensor, apply_scaling=False
        )
        # 0.20 / 0.60 = 0.333333
        self.assertAlmostEqual(float(res_ndbi), 0.333333, delta=0.0001)

        # UI: (SWIR2 - NIR) / (SWIR2 + NIR)
        ui_def = self.lib.get_index("ui")
        res_ui = IndexCalculator.calculate_pure_numpy(
            ui_def, {"SWIR_2": 0.35, "NIR": 0.15}, self.generic_sensor, apply_scaling=False
        )
        # 0.20 / 0.50 = 0.40
        self.assertAlmostEqual(float(res_ui), 0.40, delta=0.0001)

        # BSI: ((SWIR1 + RED) - (NIR + BLUE)) / ((SWIR1 + RED) + (NIR + BLUE))
        bsi_def = self.lib.get_index("bsi")
        res_bsi = IndexCalculator.calculate_pure_numpy(
            bsi_def, {"SWIR_1": 0.30, "RED": 0.25, "NIR": 0.15, "BLUE": 0.10}, self.generic_sensor, apply_scaling=False
        )
        # (0.55 - 0.25) / (0.55 + 0.25) = 0.30 / 0.80 = 0.375
        self.assertAlmostEqual(float(res_bsi), 0.375, delta=0.0001)

        # NBR: (NIR - SWIR2) / (NIR + SWIR2)
        nbr_def = self.lib.get_index("nbr")
        res_nbr = IndexCalculator.calculate_pure_numpy(
            nbr_def, {"NIR": 0.50, "SWIR_2": 0.10}, self.generic_sensor, apply_scaling=False
        )
        # 0.40 / 0.60 = 0.666667
        self.assertAlmostEqual(float(res_nbr), 0.666667, delta=0.0001)

        # NBR2: (SWIR1 - SWIR2) / (SWIR1 + SWIR2)
        nbr2_def = self.lib.get_index("nbr2")
        res_nbr2 = IndexCalculator.calculate_pure_numpy(
            nbr2_def, {"SWIR_1": 0.30, "SWIR_2": 0.10}, self.generic_sensor, apply_scaling=False
        )
        # 0.20 / 0.40 = 0.50
        self.assertAlmostEqual(float(res_nbr2), 0.50, delta=0.0001)

    def test_mineral_ratios_and_thermal(self):
        """Tests Clay Minerals Ratio, Iron Oxide Ratio, and LST (Celsius)."""
        # Clay Minerals Ratio: SWIR1 / SWIR2
        clay_def = self.lib.get_index("clay_ratio")
        res_clay = IndexCalculator.calculate_pure_numpy(
            clay_def, {"SWIR_1": 0.36, "SWIR_2": 0.18}, self.generic_sensor, apply_scaling=False
        )
        # 0.36 / 0.18 = 2.0
        self.assertAlmostEqual(float(res_clay), 2.0, delta=0.0001)

        # Iron Oxide Ratio: RED / BLUE
        iron_def = self.lib.get_index("iron_oxide_ratio")
        res_iron = IndexCalculator.calculate_pure_numpy(
            iron_def, {"RED": 0.30, "BLUE": 0.10}, self.generic_sensor, apply_scaling=False
        )
        # 0.30 / 0.10 = 3.0
        self.assertAlmostEqual(float(res_iron), 3.0, delta=0.0001)

        # LST: (DN * 0.00341802 + 149.0) - 273.15
        lst_def = self.lib.get_index("lst_c")
        # Suppose raw DN on ST_B10 is 44000
        # LST_K = 44000 * 0.00341802 + 149.0 = 150.39288 + 149.0 = 299.39288 K
        # LST_C = 299.39288 - 273.15 = 26.24288 °C
        res_lst = IndexCalculator.calculate_pure_numpy(
            lst_def, {"THERMAL": 44000}, self.landsat8_sensor, apply_scaling=True
        )
        self.assertAlmostEqual(float(res_lst), 26.24288, delta=0.01)

    def test_landsat_c2_l2_surface_reflectance_scaling(self):
        """
        Tests Landsat Collection 2 Level-2 scaling:
        reflectance = (DN * 0.0000275) - 0.2
        """
        ndvi_def = self.lib.get_index("ndvi")
        # Suppose DN for NIR (SR_B5) is 29090 -> 29090 * 0.0000275 - 0.2 = 0.8 - 0.2 = 0.60
        # Suppose DN for RED (SR_B4) is 10909 -> 10909.09 * 0.0000275 - 0.2 = 0.3 - 0.2 = 0.10
        # NDVI = (0.60 - 0.10) / (0.60 + 0.10) = 0.50 / 0.70 = 0.7142857
        nir_dn = (0.60 + 0.2) / 0.0000275 # 29090.909
        red_dn = (0.10 + 0.2) / 0.0000275 # 10909.0909
        res = IndexCalculator.calculate_pure_numpy(
            ndvi_def, {"NIR": nir_dn, "RED": red_dn}, self.landsat8_sensor, apply_scaling=True
        )
        self.assertAlmostEqual(float(res), 0.7142857, delta=0.0001)

    def test_safe_divide_and_msavi_clamp(self):
        """Tests zero division returns -9999.0 and MSAVI2 negative discriminant clamp does not throw error."""
        ndvi_def = self.lib.get_index("ndvi")
        # Zero denominator
        res_zero = IndexCalculator.calculate_pure_numpy(
            ndvi_def, {"NIR": 0.0, "RED": 0.0}, self.generic_sensor, apply_scaling=False
        )
        self.assertEqual(float(res_zero), -9999.0)

        # MSAVI2 edge condition (large negative value that would make discriminant negative without clamp)
        msavi_def = self.lib.get_index("msavi")
        res_clamp = IndexCalculator.calculate_pure_numpy(
            msavi_def, {"NIR": 0.0, "RED": 10.0}, self.generic_sensor, apply_scaling=False
        )
        # Discriminant = 1 - 8*(0 - 10) = 1 + 80 = 81 (valid), but if NIR=0, RED=-10 -> 1 - 8*(10) = -79
        # With clamp max(-79, 0) = 0 -> (1 - 0) / 2 = 0.5
        res_clamp_neg = IndexCalculator.calculate_pure_numpy(
            msavi_def, {"NIR": 0.0, "RED": -10.0}, self.generic_sensor, apply_scaling=False
        )
        self.assertAlmostEqual(float(res_clamp_neg), 0.5, delta=0.0001)


if __name__ == "__main__":
    unittest.main()
