"""
Unit tests for ReportGenerator.
"""

import unittest
from core.index_library import IndexLibrary
from core.sensor_profiles import SensorProfileManager
from core.area_statistics import AreaStatisticsCalculator
from core.report_generator import ReportGenerator, ReportMetadata


class TestReportGenerator(unittest.TestCase):

    def setUp(self):
        self.lib = IndexLibrary.get_instance()
        self.sensor_mgr = SensorProfileManager.get_instance()

    def test_markdown_and_html_generation(self):
        ndvi_def = self.lib.get_index("ndvi")
        s2_sensor = self.sensor_mgr.get_profile("sentinel_2_l2a")
        meta = ReportMetadata(
            title="Test Obuasi NDVI Report",
            study_area="Obuasi, Ghana",
            analyst="Lead Remote Sensing Specialist"
        )
        arr = [1]*50 + [2]*50
        stats = AreaStatisticsCalculator.calculate_categorical_stats(
            arr, 10.0, 10.0, {1: "Sparse", 2: "Dense"}
        )

        md = ReportGenerator.generate_markdown_report(
            metadata=meta,
            index_def=ndvi_def,
            sensor_profile=s2_sensor,
            band_mappings={"NIR": "B08", "RED": "B04"},
            stats_result=stats
        )
        self.assertIn("Test Obuasi NDVI Report", md)
        self.assertIn("Normalized Difference Vegetation Index", md)
        self.assertIn("B08", md)

        html = ReportGenerator.generate_html_report(
            metadata=meta,
            index_def=ndvi_def,
            sensor_profile=s2_sensor,
            band_mappings={"NIR": "B08", "RED": "B04"},
            stats_result=stats
        )
        self.assertIn("<!DOCTYPE html>", html)
        self.assertIn("Test Obuasi NDVI Report", html)


if __name__ == "__main__":
    unittest.main()
