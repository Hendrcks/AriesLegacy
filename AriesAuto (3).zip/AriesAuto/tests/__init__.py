"""
AriesLegacy Test Suite.
"""
