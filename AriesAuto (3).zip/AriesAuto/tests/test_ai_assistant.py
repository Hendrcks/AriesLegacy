"""
Unit tests for GeoAIAssistant.
"""

import unittest
from core.ai_assistant import GeoAIAssistant


class TestAIAssistant(unittest.TestCase):

    def setUp(self):
        self.ai = GeoAIAssistant()

    def test_objective_recommendations(self):
        proposal = self.ai.recommend_by_objective("mining_disturbance")
        self.assertIsNotNone(proposal)
        self.assertIn("bsi", proposal.recommended_indices)
        self.assertIn("iron_oxide", proposal.recommended_indices)

        water_prop = self.ai.recommend_by_objective("flood_water")
        self.assertIn("mndwi", water_prop.recommended_indices)

    def test_natural_language_parsing(self):
        p1 = self.ai.analyze_natural_language_prompt("Assess wildfire and burn severity across the forest")
        self.assertIn("nbr", p1.recommended_indices)
        self.assertEqual(p1.target_tab, "change")

        p2 = self.ai.analyze_natural_language_prompt("Detect open water and flood boundaries")
        self.assertIn("mndwi", p2.recommended_indices)

        p3 = self.ai.analyze_natural_language_prompt("Map bare land and illegal mining pits in Obuasi")
        self.assertIn("bsi", p3.recommended_indices)


if __name__ == "__main__":
    unittest.main()
