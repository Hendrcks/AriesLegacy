"""
AriesLegacy - Main Plugin Lifecycle.
Handles QGIS GUI actions, menus, toolbar buttons, DockWidget lifecycle, and Processing provider registration.
"""

import os
from typing import Optional

try:
    from qgis.PyQt.QtCore import Qt, QCoreApplication
    from qgis.PyQt.QtGui import QIcon
    from qgis.PyQt.QtWidgets import QAction
    from qgis.core import QgsApplication
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QAction:
        def __init__(self, *args, **kwargs): pass

from .arieslegacy_dockwidget import AriesLegacyDockWidget
from .processing.provider import AriesLegacyProcessingProvider


class AriesLegacy:
    """Main AriesLegacy QGIS Plugin Controller."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.provider: Optional[AriesLegacyProcessingProvider] = None
        self.dockwidget: Optional[AriesLegacyDockWidget] = None
        self.action: Optional[QAction] = None
        self.menu_name = "&AriesLegacy"

    def initProcessing(self):
        """Initializes and registers the QGIS Processing provider."""
        if HAS_QGIS:
            self.provider = AriesLegacyProcessingProvider()
            QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        """Creates the GUI actions, toolbar icon, and dock widget."""
        self.initProcessing()

        # Icon path
        icon_path = os.path.join(self.plugin_dir, "icons", "icon.svg")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        # Action to open DockWidget
        self.action = QAction(icon, "AriesLegacy — Geo AI", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.action.setStatusTip("Open AriesLegacy Spatial-Index Geo AI Studio")

        # Add to Toolbar and Menu
        self.iface.addRasterToolBarIcon(self.action)
        self.iface.addPluginToRasterMenu(self.menu_name, self.action)

    def unload(self):
        """Cleans up GUI elements, actions, and processing providers upon plugin unload."""
        if self.action:
            self.iface.removePluginRasterMenu(self.menu_name, self.action)
            self.iface.removeRasterToolBarIcon(self.action)

        if self.dockwidget:
            self.iface.removeDockWidget(self.dockwidget)
            self.dockwidget.deleteLater()
            self.dockwidget = None

        if self.provider and HAS_QGIS:
            QgsApplication.processingRegistry().removeProvider(self.provider)

    def run(self):
        """Shows and raises the AriesLegacy DockWidget."""
        if self.dockwidget is None:
            self.dockwidget = AriesLegacyDockWidget(self.iface, self.iface.mainWindow())
            self.dockwidget.closingPlugin.connect(self.on_dock_closed)
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dockwidget)

        self.dockwidget.show()
        self.dockwidget.raise_()

    def on_dock_closed(self):
        """Callback when dockwidget is closed by the user."""
        pass
