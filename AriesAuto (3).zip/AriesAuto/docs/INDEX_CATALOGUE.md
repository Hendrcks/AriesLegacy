# AriesLegacy Geospatial Index Catalogue

This catalogue details the scientific indices supported in AriesLegacy v1.0.0.

---

## 1. Vegetation Indices

### NDVI — Normalized Difference Vegetation Index
- **Formula:** $\text{NDVI} = \frac{\text{NIR} - \text{RED}}{\text{NIR} + \text{RED}}$
- **Required Bands:** `NIR`, `RED`
- **Recommended Style:** `RdYlGn` (Red to Green)
- **Description:** Benchmark index for quantifying green vegetation vigor, photosynthetic activity, and biomass density.
- **Reference:** Rouse et al. (1974). Monitoring the vernal advancement of retrogradation of natural vegetation. NASA/GSFC Type III Final Report.

### GNDVI — Green Normalized Difference Vegetation Index
- **Formula:** $\text{GNDVI} = \frac{\text{NIR} - \text{GREEN}}{\text{NIR} + \text{GREEN}}$
- **Required Bands:** `NIR`, `GREEN`
- **Recommended Style:** `RdYlGn`
- **Description:** Sensitive to chlorophyll concentration variations and less prone to saturation in dense canopies.
- **Reference:** Gitelson & Merzlyak (1998). Remote sensing of chlorophyll concentration in higher plant leaves.

### EVI — Enhanced Vegetation Index
- **Formula:** $\text{EVI} = 2.5 \times \frac{\text{NIR} - \text{RED}}{\text{NIR} + 6.0\,\text{RED} - 7.5\,\text{BLUE} + 1.0}$
- **Required Bands:** `NIR`, `RED`, `BLUE`
- **Recommended Style:** `RdYlGn`
- **Description:** Optimised for high-biomass canopy monitoring with reduced atmospheric and canopy background influence.
- **Reference:** Huete et al. (2002). Radiometric and biophysical performance of MODIS vegetation indices.

### SAVI — Soil-Adjusted Vegetation Index ($L=0.5$)
- **Formula:** $\text{SAVI} = \frac{\text{NIR} - \text{RED}}{\text{NIR} + \text{RED} + 0.5} \times 1.5$
- **Required Bands:** `NIR`, `RED`
- **Description:** Minimises soil brightness influences using a soil-adjustment factor ($L=0.5$), ideal for arid and early-crop areas.
- **Reference:** Huete (1988). A soil-adjusted vegetation index (SAVI).

### NDMI — Normalized Difference Moisture Index
- **Formula:** $\text{NDMI} = \frac{\text{NIR} - \text{SWIR}_1}{\text{NIR} + \text{SWIR}_1}$
- **Required Bands:** `NIR`, `SWIR_1`
- **Recommended Style:** `Blues`
- **Description:** Sensitive to liquid water levels in plant canopies; used for drought and canopy water stress monitoring.
- **Reference:** Gao (1996). NDWI—A normalized difference water index for remote sensing of vegetation liquid water.

---

## 2. Water & Flood Indices

### MNDWI — Modified Normalized Difference Water Index
- **Formula:** $\text{MNDWI} = \frac{\text{GREEN} - \text{SWIR}_1}{\text{GREEN} + \text{SWIR}_1}$
- **Required Bands:** `GREEN`, `SWIR_1`
- **Recommended Style:** `Blues`
- **Description:** Replaces NIR with SWIR to eliminate built-up noise, making it the premier index for urban flood mapping.
- **Reference:** Xu (2006). Modification of normalised difference water index (NDWI).

### NDWI — Normalized Difference Water Index (McFeeters)
- **Formula:** $\text{NDWI} = \frac{\text{GREEN} - \text{NIR}}{\text{GREEN} + \text{NIR}}$
- **Required Bands:** `GREEN`, `NIR`
- **Recommended Style:** `Blues`
- **Description:** Delineates open surface water bodies by contrasting green reflectance with NIR absorption.
- **Reference:** McFeeters (1996). Delineation of open water features.

### AWEI — Automated Water Extraction Index
- **AWEI_nsh (Non-Shadow):** $4(\text{GREEN} - \text{SWIR}_1) - (0.25\,\text{NIR} + 2.75\,\text{SWIR}_2)$
- **AWEI_sh (Shadow):** $\text{BLUE} + 2.5\,\text{GREEN} - 1.5(\text{NIR} + \text{SWIR}_1) - 0.25\,\text{SWIR}_2$
- **Required Bands:** `BLUE`, `GREEN`, `NIR`, `SWIR_1`, `SWIR_2`
- **Reference:** Feyisa et al. (2014). Automated Water Extraction Index.

---

## 3. Built-Up & Urban Indices

### NDBI — Normalized Difference Built-Up Index
- **Formula:** $\text{NDBI} = \frac{\text{SWIR}_1 - \text{NIR}}{\text{SWIR}_1 + \text{NIR}}$
- **Required Bands:** `SWIR_1`, `NIR`
- **Recommended Style:** `YlOrBr`
- **Reference:** Zha et al. (2003). Mapping urban areas from TM imagery.

---

## 4. Bare Soil, Mining & Disturbance Indices

### BSI — Bare Soil Index
- **Formula:** $\text{BSI} = \frac{(\text{SWIR}_1 + \text{RED}) - (\text{NIR} + \text{BLUE})}{(\text{SWIR}_1 + \text{RED}) + (\text{NIR} + \text{BLUE})}$
- **Required Bands:** `SWIR_1`, `RED`, `NIR`, `BLUE`
- **Recommended Style:** `YlOrBr`
- **Reference:** Diek et al. (2017). The Bare Soil Index for remote sensing disturbance.

### Iron Oxide Ratio
- **Formula:** $\text{RED} / \text{BLUE}$
- **Required Bands:** `RED`, `BLUE`
- **Description:** Detects gossans, lateritic soils, and tailing deposits.

### Clay Minerals Ratio
- **Formula:** $\text{SWIR}_1 / \text{SWIR}_2$
- **Required Bands:** `SWIR_1`, `SWIR_2`
- **Description:** Identifies hydrothermal alteration zones and exposed clay mineralogy.

---

## 5. Fire Severity & Surface Temperature

### dNBR — Differenced Normalized Burn Ratio
- **Formula:** $\text{dNBR} = \text{NBR}_{\text{pre}} - \text{NBR}_{\text{post}}$
- **Required Bands:** `NBR_pre`, `NBR_post`
- **Reference:** Key & Benson (2006). Landscape Assessment: Ground measure of severity.

### LST — Land Surface Temperature (Celsius)
- **Formula:** $(\text{THERMAL} \times 0.00341802 + 149.0) - 273.15$
- **Required Bands:** `THERMAL` (Landsat ST_B10)
- **Reference:** USGS Landsat Collection 2 Science Product Guide.
