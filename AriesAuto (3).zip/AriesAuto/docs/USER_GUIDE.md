# AriesLegacy User Guide

## Table of Contents
1. [Overview & Interface Layout](#1-overview--interface-layout)
2. [Quick Index Analysis](#2-quick-index-analysis)
3. [Multi-Index Batching](#3-multi-index-batching)
4. [Two-Date Change Detection](#4-two-date-change-detection)
5. [Thematic Classification & Area Statistics](#5-thematic-classification--area-statistics)
6. [Geo AI Assistant Studio](#6-geo-ai-assistant-studio)
7. [Audit Reports & Data Export](#7-audit-reports--data-export)
8. [Settings & Sensor Calibration](#8-settings--sensor-calibration)

---

## 1. Overview & Interface Layout

AriesLegacy is integrated as a dockable panel in QGIS. You can open it via:
- The **✨ AriesLegacy** icon on the Raster Toolbar.
- The top menu **Raster** > **AriesLegacy** > **AriesLegacy — Geo AI**.

The panel is organized into 7 functional tabs:
1. **Quick Index**: Instant single index calculation with auto-detected bands and styles.
2. **Multi-Index**: Batch calculation of multiple indices for one image.
3. **Change Detection**: Comparison between two temporal dates.
4. **Stats & Classes**: Interactive threshold classification and area calculations (hectares / km²).
5. **✨ Geo AI**: Rule-based recommendations and natural language query workflow generator.
6. **Export & Report**: HTML and Markdown audit report generator with metadata and tables.
7. **Settings**: Output paths, default sensors, and optional API configurations.

---

## 2. Quick Index Analysis

1. Select your **Raster Layer** from the dropdown.
2. AriesLegacy automatically detects the sensor profile (e.g., `Sentinel-2 MSI Level-2A` or `Landsat 8/9 C2 L2`).
3. Select an index from the **Geospatial Index** dropdown (e.g. NDVI, EVI, MNDWI, NDBI, BSI).
4. Review the auto-mapped bands (`NIR`, `RED`, etc.). You can manually adjust band assignments if needed.
5. Ensure **Apply radiometric scale factor** is checked to scale raw integer DN values to BOA reflectance.
6. Click **⚡ Calculate Index**.
7. The styled index raster is calculated and loaded into your map canvas.

---

## 3. Multi-Index Batching

When you need multiple indices for comprehensive environmental monitoring:
1. Open the **Multi-Index** tab.
2. Select your input image.
3. Check the desired indices (e.g., NDVI for vegetation, NDWI for water, NDBI for built-up, and BSI for bare ground).
4. Click **🚀 Run Multi-Index Batch**.
5. All layers are processed and saved with descriptive filenames into the output directory.

---

## 4. Two-Date Change Detection

Compare two satellite scenes to assess environmental transformations:
1. Open the **Change Detection** tab.
2. Select your **Pre-Date (Baseline)** and **Post-Date (After)** index layers.
3. Choose your change mode:
   - **Absolute Difference**: $Post - Pre$.
   - **Percentage Change**: $\% = \frac{Post - Pre}{|Pre| + \epsilon} \times 100$.
   - **Gain / Loss Classification**: Groups change into Significant Loss, Stable/No Change, and Significant Gain based on customizable thresholds.
   - **dNBR Burn Severity**: $Pre\_NBR - Post\_NBR$ for wildfire damage assessment.
4. Click **🔄 Calculate Two-Date Change**.

---

## 5. Thematic Classification & Area Statistics

1. Select your target continuous index layer in the **Stats & Classes** tab.
2. Customize the threshold table intervals, labels, and colors.
3. Click **📊 Classify & Calculate Area (Hectares)**.
4. AriesLegacy outputs exact pixel counts, total area in **Hectares ($ha$)**, **$km^2$**, and percentage coverage for each class.
5. Export the summary table directly as CSV.

---

## 6. Geo AI Assistant Studio

Use the Geo AI Studio to streamline complex workflows:
- **Preset Objectives**: Choose from environmental objectives such as "Mining Disturbance & Excavation", "Wildfire Burn Severity (dNBR)", "Surface Water & Flood Inundation", or "Crop Health & Nitrogen".
- **Plain Language Input**: Type a query such as:
  > *"Assess vegetation loss and mining disturbance in Obuasi between 2018 and 2024"*
- Click **💡 Recommend Workflow** to view the AI-derived rationales, recommended indices, change detection parameters, and methodological cautions.
- Click **✅ Apply Recommended Settings** to populate all UI tabs with 1-click execution!

---

## 7. Audit Reports & Data Export

Maintain full scientific transparency:
1. Fill in Study Area name, Analyst name, and contextual notes.
2. Click **📄 HTML Report** or **📝 Markdown** to export an audit document including:
   - Sensor metadata and radiometric scaling factors.
   - Exact mathematical formulas and peer-reviewed scientific citations.
   - Band mapping tables.
   - Full classification area tables with percentage breakdowns.
   - Methodological cautions and limitations.
