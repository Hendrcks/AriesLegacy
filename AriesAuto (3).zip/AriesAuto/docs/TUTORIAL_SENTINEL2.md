# Tutorial: Sentinel-2 Vegetation & Mining Disturbance Workflow

In this tutorial, you will use **AriesLegacy** to perform a complete analysis of vegetation density and land disturbance using Sentinel-2 Level-2A imagery.

---

## Prerequisites
- QGIS 3.16 or later with AriesLegacy installed.
- Sentinel-2 Level-2A imagery (or a test scene over an area of interest such as Obuasi, Ghana).

---

## Step 1: Add Sentinel-2 Imagery to QGIS
1. In QGIS, open the Data Source Manager (`Ctrl + L` / `Cmd + L`).
2. Add your Sentinel-2 raster layers (either a composite `.tif` or separate bands `B02`, `B03`, `B04`, `B08`, `B11`, `B12`).

---

## Step 2: Calculate NDVI (Quick Index)
1. Click the **✨ AriesLegacy** icon on the Raster Toolbar to open the panel.
2. In the **Quick Index** tab:
   - **Raster Layer**: Select your Sentinel-2 layer.
   - **Sensor Profile**: AriesLegacy automatically detects `Sentinel-2 MSI (Level-2A)`.
   - **Geospatial Index**: Select `NDVI — Normalized Difference Vegetation Index`.
   - Verify that **Band 1 (`NIR`)** is mapped to `B08` and **Band 2 (`RED`)** is mapped to `B04`.
   - Keep **Apply radiometric scale factor (0.0001)** and **Apply recommended color ramp** checked.
3. Click **⚡ Calculate Index**.
4. The output `NDVI` raster is calculated and styled with the `RdYlGn` color ramp.

---

## Step 3: Classify Vegetation & Calculate Hectares
1. Switch to the **Stats & Classes** tab.
2. Under **Target Index Layer**, select the newly generated NDVI layer.
3. The default threshold classes will be populated:
   - `< 0.0`: Non-vegetation / Water / Bare Ground
   - `0.0 - 0.2`: Sparse Vegetation / Dry Ground
   - `0.2 - 0.5`: Moderate Vegetation
   - `0.5 - 1.0`: Dense Vigorous Canopy
4. Click **📊 Classify & Calculate Area (Hectares)**.
5. Review the area statistics in the output window.
6. Click **Export CSV** to save the statistics table.

---

## Step 4: Multi-Index Mining Disturbance Analysis
1. Open the **Multi-Index** tab.
2. Select your Sentinel-2 image.
3. Tick:
   - `NDVI` (Vegetation vigor)
   - `BSI` (Bare Soil Index)
   - `Clay Index` (Clay mineral alteration)
   - `Iron Oxide` (Ferrous iron / tailings)
4. Click **🚀 Run Multi-Index Batch**.
5. AriesLegacy will sequentially calculate and style all 4 indices.

---

## Step 5: Export Scientific Audit Report
1. Go to the **Export & Report** tab.
2. Enter:
   - **Report Title**: `Obuasi Environmental & Mining Disturbance Assessment`
   - **Study Area**: `Obuasi Mining District, Ashanti Region, Ghana`
   - **Analyst Name**: `Your Name / Organization`
3. Click **📄 HTML Report** to generate a styled, print-ready scientific report with formulas, band metadata, classification tables, and notes.
