# Changelog

All notable changes to the **AriesAuto** QGIS Plugin will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-09-07

### Added
- **Core Index Library**: 20+ calibrated spatial indices with mathematical formulations and references.
- **Sensor Profiles Engine**: Dynamic profiles for Sentinel-2 MSI L2A, Landsat 8/9 C2 L2, Landsat 5/7 TM/ETM+, and Generic Multispectral imagery.
- **Automated Band Detector**: Name, regex, and metadata parser for single-band layers and multi-band raster composites.
- **Radiometric Scaling & Preprocessing**: Automatic application of official surface reflectance scale factors (0.0001 for S2, 0.0000275 for Landsat) and offset constants.
- **Two-Date Change Detection Engine**: Absolute difference, relative percentage change, Gain/No-Change/Loss threshold classification, and dNBR burn severity.
- **Thematic Classifier & Area Statistics**: Customizable threshold intervals with surface area calculation in m², Hectares ($ha$), and km².
- **Geo AI Assistant Studio**: Offline rules-based recommendations and natural language query parser for 1-click workflow configuration.
- **QGIS Processing Provider**: Native integration into QGIS Processing Toolbox and Modeler (`calculate_index`, `batch_calculate_indices`, `change_detection`, `classify_and_calculate_stats`).
- **Comprehensive Exporters**: GeoTIFF, styled QML layer files, CSV tables, and print-ready HTML/Markdown audit reports.
- **Automated Test Suite**: Unit and integration test coverage for all calculation math, band detection, and reporting.
