"""
AriesLegacy - Classifier.
Handles threshold-based reclassification of continuous index rasters into thematic categorical rasters.
"""

from typing import Dict, List, Optional, Tuple, Any
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None


class ThresholdClass:
    """Represents a single threshold interval and its thematic label/color."""

    def __init__(self, class_id: int, min_val: float, max_val: float, label: str, color: str = "#808080"):
        self.class_id: int = class_id
        self.min_val: float = float(min_val)
        self.max_val: float = float(max_val)
        self.label: str = label
        self.color: str = color

    def to_dict(self) -> Dict[str, Any]:
        return {
            "class_id": self.class_id,
            "min_val": self.min_val,
            "max_val": self.max_val,
            "label": self.label,
            "color": self.color,
        }


class ClassificationScheme:
    """A collection of ordered threshold classes for an index."""

    def __init__(self, name: str, classes: Optional[List[ThresholdClass]] = None):
        self.name: str = name
        self.classes: List[ThresholdClass] = classes or []

    @classmethod
    def from_default_dict_list(cls, name: str, class_dicts: List[Dict[str, Any]]) -> "ClassificationScheme":
        scheme = cls(name)
        for idx, cd in enumerate(class_dicts, start=1):
            tc = ThresholdClass(
                class_id=idx,
                min_val=cd.get("min", -999.0),
                max_val=cd.get("max", 999.0),
                label=cd.get("label", f"Class {idx}"),
                color=cd.get("color", "#808080")
            )
            scheme.classes.append(tc)
        return scheme

    def get_qgis_reclass_table(self) -> List[float]:
        """Returns flat list [min1, max1, id1, min2, max2, id2, ...] for QGIS reclassify tool."""
        table = []
        for tc in self.classes:
            table.extend([tc.min_val, tc.max_val, float(tc.class_id)])
        return table


class Classifier:
    """Applies classification schemes to continuous raster arrays or layers."""

    @staticmethod
    def classify_numpy_array(
        array: Any,
        scheme: ClassificationScheme,
        nodata_in: float = -9999.0,
        nodata_out: int = 0
    ) -> Any:
        """
        Reclassifies a 2D float array or nested list into categorical values based on threshold bounds.
        """
        if HAS_NUMPY and isinstance(array, np.ndarray):
            out = np.full(array.shape, nodata_out, dtype=np.int32)
            valid_mask = (array != nodata_in) & (~np.isnan(array))

            num_classes = len(scheme.classes)
            for idx, tc in enumerate(scheme.classes):
                if idx == num_classes - 1:
                    mask = valid_mask & (array >= tc.min_val) & (array <= tc.max_val)
                else:
                    mask = valid_mask & (array >= tc.min_val) & (array < tc.max_val)
                out[mask] = tc.class_id

            return out
        else:
            # Pure Python list support
            def classify_val(v):
                if v == nodata_in:
                    return nodata_out
                num_classes = len(scheme.classes)
                for idx, tc in enumerate(scheme.classes):
                    if idx == num_classes - 1:
                        if tc.min_val <= v <= tc.max_val:
                            return tc.class_id
                    else:
                        if tc.min_val <= v < tc.max_val:
                            return tc.class_id
                return nodata_out

            if isinstance(array, list):
                if len(array) > 0 and isinstance(array[0], list):
                    return [[classify_val(v) for v in row] for row in array]
                return [classify_val(v) for v in array]
            return classify_val(array)
