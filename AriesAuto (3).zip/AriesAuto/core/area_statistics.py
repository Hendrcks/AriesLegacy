"""
AriesLegacy - Area Statistics Engine.
Calculates pixel area, percentage breakdown, continuous distribution statistics, and CSV table generation.
"""

import csv
from typing import Dict, List, Optional, Tuple, Any
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None


class ClassAreaStat:
    """Statistics for an individual thematic class."""

    def __init__(self, class_id: int, label: str, pixel_count: int, area_m2: float, percentage: float, color: str = "#808080"):
        self.class_id: int = class_id
        self.label: str = label
        self.pixel_count: int = pixel_count
        self.area_m2: float = area_m2
        self.area_ha: float = area_m2 / 10000.0
        self.area_km2: float = area_m2 / 1000000.0
        self.percentage: float = percentage
        self.color: str = color

    def to_dict(self) -> Dict[str, Any]:
        return {
            "class_id": self.class_id,
            "label": self.label,
            "pixel_count": self.pixel_count,
            "area_m2": round(self.area_m2, 2),
            "area_ha": round(self.area_ha, 4),
            "area_km2": round(self.area_km2, 4),
            "percentage": round(self.percentage, 2),
            "color": self.color,
        }


class AreaStatisticsResult:
    """Contains full statistics summary for an analysis run."""

    def __init__(self, title: str, pixel_size_x: float, pixel_size_y: float):
        self.title: str = title
        self.pixel_size_x: float = abs(pixel_size_x)
        self.pixel_size_y: float = abs(pixel_size_y)
        self.pixel_area_m2: float = self.pixel_size_x * self.pixel_size_y
        self.total_valid_pixels: int = 0
        self.total_area_ha: float = 0.0
        self.total_area_km2: float = 0.0
        self.classes: List[ClassAreaStat] = []
        self.continuous_stats: Dict[str, float] = {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "pixel_size_m": [self.pixel_size_x, self.pixel_size_y],
            "total_valid_pixels": self.total_valid_pixels,
            "total_area_ha": round(self.total_area_ha, 4),
            "total_area_km2": round(self.total_area_km2, 4),
            "classes": [c.to_dict() for c in self.classes],
            "continuous_stats": self.continuous_stats,
        }

    def export_to_csv(self, file_path: str) -> None:
        """Exports class area statistics table to CSV."""
        with open(file_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Class ID", "Class Label", "Pixel Count", "Area (m²)", "Area (Hectares)", "Area (km²)", "Percentage (%)"])
            for c in self.classes:
                writer.writerow([c.class_id, c.label, c.pixel_count, f"{c.area_m2:.2f}", f"{c.area_ha:.4f}", f"{c.area_km2:.4f}", f"{c.percentage:.2f}"])
            writer.writerow([])
            writer.writerow(["Total", "All Valid Classes", self.total_valid_pixels, f"{self.total_valid_pixels * self.pixel_area_m2:.2f}", f"{self.total_area_ha:.4f}", f"{self.total_area_km2:.4f}", "100.00"])


class AreaStatisticsCalculator:
    """Calculates raster areas and metrics."""

    @staticmethod
    def calculate_categorical_stats(
        classified_array: Any,
        pixel_size_x: float,
        pixel_size_y: float,
        class_labels: Optional[Dict[int, str]] = None,
        class_colors: Optional[Dict[int, str]] = None,
        nodata_val: int = 0,
        title: str = "Class Area Statistics"
    ) -> AreaStatisticsResult:
        """
        Computes exact area and percentages for integer categorical arrays or lists.
        """
        result = AreaStatisticsResult(title, pixel_size_x, pixel_size_y)
        labels = class_labels or {}
        colors = class_colors or {}

        if HAS_NUMPY and isinstance(classified_array, np.ndarray):
            valid_mask = (classified_array != nodata_val) & (~np.isnan(classified_array))
            valid_pixels = classified_array[valid_mask]
            total_valid = len(valid_pixels)
            result.total_valid_pixels = total_valid
            total_m2 = total_valid * result.pixel_area_m2
            result.total_area_ha = total_m2 / 10000.0
            result.total_area_km2 = total_m2 / 1000000.0

            if total_valid == 0:
                return result

            unique_classes, counts = np.unique(valid_pixels, return_counts=True)
            for cid, cnt in zip(unique_classes, counts):
                cid_int = int(cid)
                lbl = labels.get(cid_int, f"Class {cid_int}")
                col = colors.get(cid_int, "#808080")
                c_area_m2 = cnt * result.pixel_area_m2
                pct = (cnt / total_valid) * 100.0

                stat = ClassAreaStat(
                    class_id=cid_int,
                    label=lbl,
                    pixel_count=int(cnt),
                    area_m2=c_area_m2,
                    percentage=pct,
                    color=col
                )
                result.classes.append(stat)

        else:
            # Pure Python list/iterable fallback
            flat = [p for row in (classified_array if hasattr(classified_array[0], '__iter__') else [classified_array]) for p in row] if isinstance(classified_array, list) and len(classified_array) > 0 and isinstance(classified_array[0], list) else list(classified_array)
            valid_pixels = [int(p) for p in flat if p != nodata_val]
            total_valid = len(valid_pixels)
            result.total_valid_pixels = total_valid
            total_m2 = total_valid * result.pixel_area_m2
            result.total_area_ha = total_m2 / 10000.0
            result.total_area_km2 = total_m2 / 1000000.0

            if total_valid == 0:
                return result

            from collections import Counter
            counts = Counter(valid_pixels)
            for cid_int, cnt in counts.items():
                lbl = labels.get(cid_int, f"Class {cid_int}")
                col = colors.get(cid_int, "#808080")
                c_area_m2 = cnt * result.pixel_area_m2
                pct = (cnt / total_valid) * 100.0
                stat = ClassAreaStat(
                    class_id=cid_int,
                    label=lbl,
                    pixel_count=int(cnt),
                    area_m2=c_area_m2,
                    percentage=pct,
                    color=col
                )
                result.classes.append(stat)

        # Sort classes by class ID
        result.classes.sort(key=lambda x: x.class_id)
        return result

    @staticmethod
    def calculate_continuous_stats(
        continuous_array: Any,
        nodata_val: float = -9999.0
    ) -> Dict[str, float]:
        """
        Calculates descriptive statistics (min, max, mean, std, median) for continuous float array or list.
        """
        if HAS_NUMPY and isinstance(continuous_array, np.ndarray):
            valid_mask = (continuous_array != nodata_val) & (~np.isnan(continuous_array))
            valid_data = continuous_array[valid_mask]

            if len(valid_data) == 0:
                return {"valid_pixel_count": 0, "min": 0.0, "max": 0.0, "mean": 0.0, "std": 0.0, "median": 0.0}

            return {
                "valid_pixel_count": int(len(valid_data)),
                "min": float(np.min(valid_data)),
                "max": float(np.max(valid_data)),
                "mean": float(np.mean(valid_data)),
                "std": float(np.std(valid_data)),
                "median": float(np.median(valid_data)),
            }
        else:
            flat = [p for row in (continuous_array if hasattr(continuous_array[0], '__iter__') else [continuous_array]) for p in row] if isinstance(continuous_array, list) and len(continuous_array) > 0 and isinstance(continuous_array[0], list) else list(continuous_array)
            valid = [float(p) for p in flat if p != nodata_val]
            if not valid:
                return {"valid_pixel_count": 0, "min": 0.0, "max": 0.0, "mean": 0.0, "std": 0.0, "median": 0.0}
            mean_val = sum(valid) / len(valid)
            std_val = (sum((x - mean_val) ** 2 for x in valid) / len(valid)) ** 0.5
            s = sorted(valid)
            mid = len(s) // 2
            med_val = (s[mid] if len(s) % 2 != 0 else (s[mid-1] + s[mid]) / 2.0)
            return {
                "valid_pixel_count": len(valid),
                "min": min(valid),
                "max": max(valid),
                "mean": mean_val,
                "std": std_val,
                "median": med_val
            }
