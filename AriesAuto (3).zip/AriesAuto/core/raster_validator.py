"""
AriesLegacy - Raster Validator & Quality Assurance.
Validates input raster layers, CRS alignment, extent overlap, spatial resolution, and band integrity.
Implements the diagnostic quality-assurance checks from the AriesLegacy Formula Specification.
"""

from typing import Dict, List, Optional, Tuple, Any
from .sensor_profiles import SensorProfile
from .index_library import IndexDefinition


class ValidationIssue:
    """Represents a validation warning or error."""
    def __init__(self, is_error: bool, code: str, message: str, suggestion: str = ""):
        self.is_error: bool = is_error
        self.code: str = code
        self.message: str = message
        self.suggestion: str = suggestion

    def __str__(self) -> str:
        prefix = "[ERROR]" if self.is_error else "[WARNING]"
        return f"{prefix} {self.message} ({self.suggestion})" if self.suggestion else f"{prefix} {self.message}"


class ValidationReport:
    """Encapsulates all validation outcomes for a planned raster operation."""

    def __init__(self):
        self.issues: List[ValidationIssue] = []

    def add_error(self, code: str, message: str, suggestion: str = "") -> None:
        self.issues.append(ValidationIssue(is_error=True, code=code, message=message, suggestion=suggestion))

    def add_warning(self, code: str, message: str, suggestion: str = "") -> None:
        self.issues.append(ValidationIssue(is_error=False, code=code, message=message, suggestion=suggestion))

    @property
    def is_valid(self) -> bool:
        """Returns True if there are no blocking errors."""
        return not any(i.is_error for i in self.issues)

    @property
    def errors(self) -> List[ValidationIssue]:
        return [i for i in self.issues if i.is_error]

    @property
    def warnings(self) -> List[ValidationIssue]:
        return [i for i in self.issues if not i.is_error]

    def summary(self) -> str:
        if self.is_valid:
            if not self.issues:
                return "Validation passed: All input checks successful."
            return f"Validation passed with {len(self.warnings)} warning(s)."
        return f"Validation failed with {len(self.errors)} error(s) and {len(self.warnings)} warning(s)."


class RasterValidator:
    """Validates single and multi-temporal raster inputs for processing."""

    @staticmethod
    def validate_band_mapping(
        required_bands: List[str],
        mapped_bands: Dict[str, Any],
        index_def: Optional[IndexDefinition] = None,
        sensor_profile: Optional[SensorProfile] = None
    ) -> ValidationReport:
        """
        Validates that all required canonical bands are mapped and verifies sensor compatibility.
        """
        report = ValidationReport()

        # 1. Check for missing required bands
        for b in required_bands:
            if b not in mapped_bands or mapped_bands[b] is None:
                report.add_error(
                    code="MISSING_BAND",
                    message=f"Required band '{b}' is not mapped.",
                    suggestion=f"Please tick or assign a layer/band for '{b}' in the band selection panel."
                )

        # 2. Check sensor-specific constraints
        if index_def and sensor_profile:
            # LST compatibility check
            if index_def.id in ("lst", "lst_c") and sensor_profile.id == "sentinel_2_l2a":
                report.add_error(
                    code="SENSOR_NO_THERMAL",
                    message="Sentinel-2 does not have a thermal infrared band.",
                    suggestion="LST requires Landsat Collection 2 Level-2 Surface Temperature (ST_B10). Switch sensor profile or disable LST."
                )

            # Sentinel-2 10m vs 20m resolution notice for SWIR indices
            if sensor_profile.id == "sentinel_2_l2a":
                swir_bands_needed = [b for b in required_bands if b in ("SWIR_1", "SWIR_2", "SWIR1", "SWIR2")]
                vis_bands_needed = [b for b in required_bands if b in ("BLUE", "GREEN", "RED", "NIR")]
                if swir_bands_needed and vis_bands_needed:
                    report.add_warning(
                        code="S2_RESOLUTION_MIX",
                        message="This index combines 10 m bands (RGB/NIR) with 20 m bands (SWIR).",
                        suggestion="The output will be computed at the 20 m analysis grid to preserve continuous physical reflectance."
                    )

        return report

    @staticmethod
    def validate_ndvi_diagnostics(
        sensor_profile: SensorProfile,
        mapped_band_names: Dict[str, str],
        apply_scaling: bool = True
    ) -> List[ValidationIssue]:
        """
        Runs quality-assurance diagnostic checks for NDVI calculations to prevent common failure modes.
        """
        issues = []

        # 1. Landsat Collection 2 raw integers check
        if sensor_profile.id in ("landsat_8_9_c2_l2", "landsat_5_7_c2_l2") and not apply_scaling:
            issues.append(ValidationIssue(
                is_error=False,
                code="LANDSAT_UNSCALED",
                message="Landsat Collection 2 Surface Reflectance requires scale (0.0000275) and offset (-0.2).",
                suggestion="Ensure 'Apply radiometric scale factor' is checked to avoid incorrect negative NDVI values."
            ))

        # 2. Check for potentially swapped bands
        nir_name = mapped_band_names.get("NIR", "").upper()
        red_name = mapped_band_names.get("RED", "").upper()

        if sensor_profile.id == "landsat_8_9_c2_l2":
            if "SR_B4" in nir_name or "B4" in nir_name:
                issues.append(ValidationIssue(
                    is_error=False,
                    code="POSSIBLE_SWAPPED_BANDS",
                    message="Landsat Band 4 is assigned to NIR, but Band 4 is Red in Landsat 8/9.",
                    suggestion="Verify that NIR is SR_B5 and RED is SR_B4."
                ))
            if "SR_B5" in red_name or "B5" in red_name:
                issues.append(ValidationIssue(
                    is_error=False,
                    code="POSSIBLE_SWAPPED_BANDS",
                    message="Landsat Band 5 is assigned to RED, but Band 5 is NIR in Landsat 8/9.",
                    suggestion="Verify that NIR is SR_B5 and RED is SR_B4."
                ))

        elif sensor_profile.id == "sentinel_2_l2a":
            if "B04" in nir_name or "B4" in nir_name:
                issues.append(ValidationIssue(
                    is_error=False,
                    code="POSSIBLE_SWAPPED_BANDS",
                    message="Sentinel-2 Band 04 is assigned to NIR, but B04 is Red in Sentinel-2.",
                    suggestion="Verify that NIR is B08 and RED is B04."
                ))
            if "B08" in red_name or "B8" in red_name:
                issues.append(ValidationIssue(
                    is_error=False,
                    code="POSSIBLE_SWAPPED_BANDS",
                    message="Sentinel-2 Band 08 is assigned to RED, but B08 is NIR in Sentinel-2.",
                    suggestion="Verify that NIR is B08 and RED is B04."
                ))

        return issues

    @staticmethod
    def validate_two_date_comparability(
        crs1_authid: str,
        crs2_authid: str,
        extent1: Tuple[float, float, float, float], # (xmin, ymin, xmax, ymax)
        extent2: Tuple[float, float, float, float],
        res1: Tuple[float, float],                  # (xres, yres)
        res2: Tuple[float, float],
    ) -> ValidationReport:
        """
        Checks comparability between two temporal scenes (CRS, extent overlap, resolution).
        """
        report = ValidationReport()

        # 1. CRS comparison
        if crs1_authid and crs2_authid and crs1_authid != crs2_authid:
            report.add_warning(
                code="CRS_MISMATCH",
                message=f"CRS mismatch: Pre-date is '{crs1_authid}', Post-date is '{crs2_authid}'.",
                suggestion="QGIS/AriesLegacy will reproject inputs to match Pre-date CRS before comparison."
            )

        # 2. Extent overlap check
        xmin1, ymin1, xmax1, ymax1 = extent1
        xmin2, ymin2, xmax2, ymax2 = extent2

        # Calculate intersection
        inter_xmin = max(xmin1, xmin2)
        inter_ymin = max(ymin1, ymin2)
        inter_xmax = min(xmax1, xmax2)
        inter_ymax = min(ymax1, ymax2)

        if inter_xmin >= inter_xmax or inter_ymin >= inter_ymax:
            report.add_error(
                code="NO_EXTENT_OVERLAP",
                message="The two raster scenes do not overlap spatially.",
                suggestion="Ensure both scenes cover the same geographical study area."
            )
        else:
            # Check percentage overlap
            area1 = (xmax1 - xmin1) * (ymax1 - ymin1)
            inter_area = (inter_xmax - inter_xmin) * (inter_ymax - inter_ymin)
            if area1 > 0 and (inter_area / area1) < 0.2:
                report.add_warning(
                    code="LOW_EXTENT_OVERLAP",
                    message=f"Spatial overlap between scenes is low ({inter_area / area1 * 100:.1f}%).",
                    suggestion="The change calculation will be clipped to the common intersecting bounding box."
                )

        # 3. Spatial resolution comparison
        rx1, ry1 = abs(res1[0]), abs(res1[1])
        rx2, ry2 = abs(res2[0]), abs(res2[1])

        if rx1 > 0 and rx2 > 0:
            diff_ratio = abs(rx1 - rx2) / max(rx1, rx2)
            if diff_ratio > 0.05:
                report.add_warning(
                    code="RESOLUTION_MISMATCH",
                    message=f"Resolution difference: Scene 1 has {rx1:.1f}m cell size, Scene 2 has {rx2:.1f}m cell size.",
                    suggestion=f"Inputs will be resampled to {min(rx1, rx2):.1f}m grid using bilinear interpolation."
                )

        return report
