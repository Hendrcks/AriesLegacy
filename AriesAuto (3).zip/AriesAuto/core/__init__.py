"""
AriesLegacy Core Modules.
"""
