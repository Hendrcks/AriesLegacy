"""
AriesLegacy - Style Manager.
Manages QGIS raster rendering styles, color ramps, single-band pseudocolor, paletted classification, and QML export.
"""

import os
from typing import Dict, List, Optional, Tuple, Any

from .index_library import IndexDefinition
from .classifier import ClassificationScheme


class StyleManager:
    """Handles raster styling, color ramps, and QML exports."""

    @staticmethod
    def get_style_file_path(style_name: str) -> Optional[str]:
        """Locates pre-defined QML file in data/styles/."""
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        candidate = os.path.join(base_dir, "data", "styles", f"{style_name}.qml")
        if os.path.exists(candidate):
            return candidate
        return None

    @staticmethod
    def generate_paletted_qml(
        classes: List[Dict[str, Any]], # [{"class_id": 1, "label": "...", "color": "#hex"}]
        output_qml_path: str
    ) -> str:
        """
        Generates a standard QGIS 3.x Paletted QML layer style XML.
        """
        items_xml = []
        for c in classes:
            cid = c.get("class_id", 0)
            lbl = c.get("label", f"Class {cid}")
            col = c.get("color", "#808080")
            items_xml.append(f'          <item value="{cid}" label="{lbl}" color="{col}" alpha="255"/>')

        items_str = "\n".join(items_xml)

        qml_content = f"""<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe>
    <rasterrenderer type="paletted" opacity="1" alphaBand="-1" band="1">
      <rasterProperties>
        <items>
{items_str}
        </items>
      </rasterProperties>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>"""
        with open(output_qml_path, "w", encoding="utf-8") as f:
            f.write(qml_content)

        return output_qml_path

    @staticmethod
    def generate_pseudocolor_qml(
        ramp_items: List[Tuple[float, str, str]], # (value, label, hex_color)
        output_qml_path: str,
        min_val: float = -1.0,
        max_val: float = 1.0,
        unit_suffix: str = ""
    ) -> str:
        """
        Generates a SingleBandPseudoColor QML file.
        """
        items_xml = []
        for val, lbl, col in ramp_items:
            items_xml.append(f'          <item value="{val}" label="{lbl}" color="{col}" alpha="255"/>')

        items_str = "\n".join(items_xml)

        qml_content = f"""<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe>
    <rasterrenderer type="singlebandpseudocolor" opacity="1" alphaBand="-1" band="1" classificationMin="{min_val}" classificationMax="{max_val}">
      <rastershader>
        <colorrampshader colorRampType="INTERPOLATED" clip="0" classificationMode="1">
          <colorramplabelprefix></colorramplabelprefix>
          <colorramplabelsuffix>{unit_suffix}</colorramplabelsuffix>
{items_str}
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>"""
        with open(output_qml_path, "w", encoding="utf-8") as f:
            f.write(qml_content)

        return output_qml_path

    @staticmethod
    def apply_style_to_qgis_layer(layer: Any, index_def: Optional[IndexDefinition] = None, qml_path: Optional[str] = None) -> bool:
        """
        Applies style to a PyQGIS QgsRasterLayer if QGIS is running.
        """
        if layer is None or not hasattr(layer, "isValid") or not layer.isValid():
            return False

        # If explicit QML path provided
        if qml_path and os.path.exists(qml_path):
            res = layer.loadNamedStyle(qml_path)
            if hasattr(layer, "triggerRepaint"):
                layer.triggerRepaint()
            return True

        # Otherwise match default recommended style from index definition
        if index_def:
            style_file = StyleManager.get_style_file_path(index_def.recommended_style)
            if style_file and os.path.exists(style_file):
                layer.loadNamedStyle(style_file)
                if hasattr(layer, "triggerRepaint"):
                    layer.triggerRepaint()
                return True

        return False
