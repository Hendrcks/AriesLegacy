"""
AriesLegacy - Geo AI Assistant.
Provides offline rule-based workflow recommendations and natural language query understanding.
"""

import json
import re
from typing import Dict, List, Optional, Any
from .index_library import IndexLibrary, IndexDefinition


class ProposedWorkflow:
    """Encapsulates an AI-proposed workflow ready for user review and 1-click application."""

    def __init__(self, title: str, objective: str, rationale: str):
        self.title: str = title
        self.objective: str = objective
        self.rationale: str = rationale
        self.target_tab: str = "quick" # "quick", "multi", "change", "stats"
        self.recommended_indices: List[str] = [] # List of index IDs e.g. ["ndvi", "savi"]
        self.change_mode: Optional[str] = None
        self.gain_loss_thresholds: Tuple[float, float] = (-0.1, 0.1)
        self.recommended_style: str = "RdYlGn"
        self.steps: List[str] = []
        self.cautions: List[str] = []

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "objective": self.objective,
            "rationale": self.rationale,
            "target_tab": self.target_tab,
            "recommended_indices": self.recommended_indices,
            "change_mode": self.change_mode,
            "gain_loss_thresholds": self.gain_loss_thresholds,
            "recommended_style": self.recommended_style,
            "steps": self.steps,
            "cautions": self.cautions,
        }


class GeoAIAssistant:
    """Rule-based and LLM-ready Geo AI Workflow Engine."""

    # Pre-defined domain rules for offline mode
    OBJECTIVE_CATALOG = {
        "vegetation_health": {
            "title": "Vegetation Health & Crop Vigor Analysis",
            "indices": ["ndvi", "evi", "savi", "gndvi"],
            "target_tab": "multi",
            "rationale": "Combines NDVI for general canopy vigor with EVI (high biomass sensitivity) and SAVI (soil brightness reduction in sparse areas).",
            "steps": [
                "1. Select calibrated optical imagery (Sentinel-2 L2A or Landsat 8/9 C2).",
                "2. Calculate NDVI and EVI simultaneously.",
                "3. Apply RdYlGn continuous symbology to highlight healthy green canopy.",
                "4. Classify index into density categories (Dense, Moderate, Sparse, Non-vegetated).",
                "5. Calculate exact hectare statistics for each class."
            ],
            "cautions": [
                "Early growing season scenes may have significant soil exposure; use SAVI if vegetation cover is < 30%.",
                "Atmospheric haze or cloud fringe can artificially lower NDVI values."
            ]
        },
        "flood_water": {
            "title": "Surface Water & Flood Extent Delineation",
            "indices": ["mndwi", "ndwi", "awei_nsh"],
            "target_tab": "multi",
            "rationale": "MNDWI replaces NIR with SWIR to eliminate false positives from urban built-up areas, while NDWI provides clear open water contrast.",
            "steps": [
                "1. Load pre- and post-flood imagery.",
                "2. Calculate MNDWI index rasters.",
                "3. Apply threshold (typically MNDWI > 0.0 to 0.2) to delineate inundated pixels.",
                "4. Run two-date change detection to calculate newly flooded land area in hectares."
            ],
            "cautions": [
                "Building and mountain terrain shadows can sometimes mimic water signals; verify with AWEI_sh if topography is steep.",
                "Turbid or sediment-rich floodwater may require adjusting water threshold closer to 0.0."
            ]
        },
        "urban_growth": {
            "title": "Urban Expansion & Built-Up Footprint Analysis",
            "indices": ["ndbi", "ui", "ndvi"],
            "target_tab": "multi",
            "rationale": "NDBI highlights impervious surfaces and masonry, while comparing against NDVI separates bare fields from built infrastructure.",
            "steps": [
                "1. Calculate NDBI and NDVI.",
                "2. Apply urban mask where NDBI > NDVI.",
                "3. Perform two-date change detection to detect urban expansion zones.",
                "4. Export settlement area expansion statistics."
            ],
            "cautions": [
                "Dry bare soil and fallow fields have similar spectral properties to concrete; combine with BSI or seasonal imagery."
            ]
        },
        "mining_disturbance": {
            "title": "Mining Excavation, Tailings & Land Disturbance",
            "indices": ["bsi", "nbr", "iron_oxide", "clay_index"],
            "target_tab": "multi",
            "rationale": "BSI isolates bare ground and excavation pits; Iron Oxide and Clay indices identify mineral enrichment and tailing deposits; NBR tracks canopy loss.",
            "steps": [
                "1. Select baseline (pre-mining) and current satellite scenes.",
                "2. Compute Bare Soil Index (BSI) and Iron Oxide ratio.",
                "3. Classify severe disturbance areas (BSI > 0.25).",
                "4. Compute hectare area of active pits, concessions, and vegetative degradation."
            ],
            "cautions": [
                "Seasonal agricultural harvesting may temporarily look like bare disturbance; compare multiple dates or rainy season baseline."
            ]
        },
        "burn_severity": {
            "title": "Wildfire Extent & Burn Severity Mapping (dNBR)",
            "indices": ["nbr", "dnbr", "nbr2"],
            "target_tab": "change",
            "change_mode": "dnbr_burn_severity",
            "rationale": "NBR exploits the sharp drop in NIR and surge in SWIR post-fire. dNBR categorizes severity from unburned to high severity.",
            "steps": [
                "1. Select pre-fire and post-fire imagery scenes with minimal cloud cover.",
                "2. Calculate Pre-fire NBR and Post-fire NBR.",
                "3. Compute dNBR = Pre_NBR - Post_NBR.",
                "4. Classify into USGS standard severity classes (Low, Moderate, High Severity).",
                "5. Calculate burn area totals in hectares and km²."
            ],
            "cautions": [
                "Ensure pre- and post-fire scenes are closely matched in phenology to prevent drought mimicking burn severity."
            ]
        },
        "drought_canopy": {
            "title": "Canopy Moisture Deficit & Drought Assessment",
            "indices": ["ndmi", "savi"],
            "target_tab": "multi",
            "rationale": "NDMI tracks liquid water absorption in spongy mesophyll tissues, providing early warning for agricultural drought.",
            "steps": [
                "1. Compute NDMI across the monitoring region.",
                "2. Apply blue moisture color ramp.",
                "3. Classify into Canopy Water Deficit classes (Severe, Moderate, Healthy).",
                "4. Summarize vulnerable agricultural zones."
            ],
            "cautions": [
                "Canopy structure variations between forest and grass crops affect baseline moisture values."
            ]
        },
        "land_surface_temp": {
            "title": "Land Surface Temperature & Urban Heat Island",
            "indices": ["lst", "ndvi", "ndbi"],
            "target_tab": "quick",
            "rationale": "Extracts calibrated surface kinetic temperature in Celsius from Landsat thermal infrared band ST_B10.",
            "steps": [
                "1. Select Landsat 8/9 Collection 2 Surface Temperature product.",
                "2. Compute LST in Celsius using official USGS scale factor (0.00341802) and offset (149.0 - 273.15).",
                "3. Apply Magma / Thermal color ramp.",
                "4. Correlate hot spots with NDBI built-up areas."
            ],
            "cautions": [
                "LST requires cloud-free thermal atmospheric transmission. Only available on thermal-equipped sensors (Landsat 5/7/8/9)."
            ]
        }
    }

    def __init__(self, index_lib: Optional[IndexLibrary] = None):
        self.index_lib = index_lib or IndexLibrary.get_instance()

    def get_available_objectives(self) -> List[Dict[str, str]]:
        """Returns list of pre-configured objectives for dropdowns."""
        return [
            {"id": k, "title": v["title"]}
            for k, v in self.OBJECTIVE_CATALOG.items()
        ]

    def recommend_by_objective(self, objective_key: str) -> Optional[ProposedWorkflow]:
        """Returns a structured workflow proposal for a given objective key."""
        obj = self.OBJECTIVE_CATALOG.get(objective_key)
        if not obj:
            return None

        proposal = ProposedWorkflow(
            title=obj["title"],
            objective=objective_key,
            rationale=obj["rationale"]
        )
        proposal.target_tab = obj.get("target_tab", "quick")
        proposal.recommended_indices = obj.get("indices", [])
        proposal.change_mode = obj.get("change_mode", None)
        proposal.steps = obj.get("steps", [])
        proposal.cautions = obj.get("cautions", [])

        # Set default recommended style from first index
        if proposal.recommended_indices:
            first_idx = self.index_lib.get_index(proposal.recommended_indices[0])
            if first_idx:
                proposal.recommended_style = first_idx.recommended_style

        return proposal

    def analyze_natural_language_prompt(self, user_prompt: str) -> ProposedWorkflow:
        """
        Interprets natural language queries using smart semantic keyword pattern matching.
        E.g.: 'I want to assess vegetation loss and canopy degradation over time'
        """
        p = user_prompt.lower()

        # 1. Fire / Burn severity
        if any(w in p for w in ["burn", "fire", "wildfire", "dnbr", "severity", "burned"]):
            proposal = self.recommend_by_objective("burn_severity")
            proposal.title = f"AI Recommendation: Burn Severity Analysis"
            return proposal

        # 2. Mining / Excavation / Bare soil
        if any(w in p for w in ["mine", "mining", "pit", "galamsey", "tailing", "bare soil", "excavat", "iron oxide", "disturbance"]):
            proposal = self.recommend_by_objective("mining_disturbance")
            proposal.title = f"AI Recommendation: Mining & Land Disturbance Workflow"
            return proposal

        # 3. Water / Flood / Wetland
        if any(w in p for w in ["water", "flood", "lake", "river", "wetland", "reservoir", "inundat", "ndwi", "mndwi"]):
            proposal = self.recommend_by_objective("flood_water")
            proposal.title = f"AI Recommendation: Surface Water & Flood Delineation"
            return proposal

        # 4. Urban / Settlement / Built-up
        if any(w in p for w in ["urban", "city", "building", "settlement", "built-up", "built up", "impervious", "sprawl", "ndbi"]):
            proposal = self.recommend_by_objective("urban_growth")
            proposal.title = f"AI Recommendation: Urban Footprint & Built-Up Analysis"
            return proposal

        # 5. Temperature / Heat / Thermal
        if any(w in p for w in ["temperature", "thermal", "heat", "lst", "urban heat", "celsius"]):
            proposal = self.recommend_by_objective("land_surface_temp")
            proposal.title = f"AI Recommendation: Land Surface Temperature (LST)"
            return proposal

        # 6. Drought / Moisture
        if any(w in p for w in ["drought", "moisture", "water stress", "dry", "ndmi", "arid"]):
            proposal = self.recommend_by_objective("drought_canopy")
            proposal.title = f"AI Recommendation: Canopy Moisture & Drought Monitoring"
            return proposal

        # 7. Multi-temporal change mentioned
        if any(w in p for w in ["change", "loss", "gain", "difference", "compare", "two dates", "over time", "trend"]):
            proposal = self.recommend_by_objective("vegetation_health")
            proposal.target_tab = "change"
            proposal.change_mode = "gain_loss_threshold"
            proposal.title = f"AI Recommendation: Two-Date Change Detection"
            proposal.rationale = "Configured for multi-temporal comparative analysis with Gain/Loss classification."
            return proposal

        # Default fallback to Vegetation Health
        proposal = self.recommend_by_objective("vegetation_health")
        proposal.title = "AI Recommendation: Standard Vegetation Analysis"
        return proposal
