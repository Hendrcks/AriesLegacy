"""
AriesLegacy - Workflow History Manager.
Tracks executed analyses for auditability, reproducibility, and logging.
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Any


class WorkflowRecord:
    """Represents a single executed analysis record."""

    def __init__(
        self,
        operation_type: str,
        index_names: List[str],
        sensor_id: str,
        input_sources: Dict[str, str],
        output_files: List[str],
        parameters: Dict[str, Any],
        status: str = "SUCCESS",
        duration_sec: float = 0.0,
    ):
        self.timestamp: str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.operation_type: str = operation_type # "QUICK_INDEX", "MULTI_INDEX", "CHANGE_DETECTION", "CLASSIFICATION"
        self.index_names: List[str] = index_names
        self.sensor_id: str = sensor_id
        self.input_sources: Dict[str, str] = input_sources
        self.output_files: List[str] = output_files
        self.parameters: Dict[str, Any] = parameters
        self.status: str = status
        self.duration_sec: float = duration_sec

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "operation_type": self.operation_type,
            "index_names": self.index_names,
            "sensor_id": self.sensor_id,
            "input_sources": self.input_sources,
            "output_files": self.output_files,
            "parameters": self.parameters,
            "status": self.status,
            "duration_sec": round(self.duration_sec, 2),
        }


class WorkflowHistory:
    """Manages session and persistent history."""

    _instance: Optional["WorkflowHistory"] = None

    def __init__(self):
        self.records: List[WorkflowRecord] = []

    @classmethod
    def get_instance(cls) -> "WorkflowHistory":
        if cls._instance is None:
            cls._instance = WorkflowHistory()
        return cls._instance

    def add_record(self, record: WorkflowRecord) -> None:
        self.records.append(record)

    def get_records(self) -> List[WorkflowRecord]:
        return list(self.records)

    def clear(self) -> None:
        self.records.clear()

    def export_to_json(self, file_path: str) -> None:
        data = [r.to_dict() for r in self.records]
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
