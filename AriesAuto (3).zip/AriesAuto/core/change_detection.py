"""
AriesLegacy - Change Detection Engine.
Calculates multi-temporal differences, percentage changes, thresholded gain/loss categories, and dNBR burn severity.
"""

from typing import Dict, List, Optional, Tuple, Any
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None


class ChangeDetectionMode:
    ABSOLUTE_DIFFERENCE = "absolute_difference"      # Post - Pre
    PERCENTAGE_CHANGE = "percentage_change"          # ((Post - Pre) / (|Pre| + eps)) * 100
    GAIN_LOSS_THRESHOLD = "gain_loss_threshold"      # Categorical: -1 (Loss), 0 (No Change), 1 (Gain)
    DNBR_BURN_SEVERITY = "dnbr_burn_severity"        # Pre_NBR - Post_NBR classified


class ChangeDetectionResult:
    """Encapsulates change detection analysis outputs and metadata."""

    def __init__(self, mode: str, output_path: str, pre_date_label: str = "", post_date_label: str = ""):
        self.mode: str = mode
        self.output_path: str = output_path
        self.pre_date_label: str = pre_date_label
        self.post_date_label: str = post_date_label
        self.statistics: Dict[str, Any] = {}
        self.gain_loss_thresholds: Tuple[float, float] = (-0.1, 0.1)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mode": self.mode,
            "output_path": self.output_path,
            "pre_date_label": self.pre_date_label,
            "post_date_label": self.post_date_label,
            "statistics": self.statistics,
            "gain_loss_thresholds": self.gain_loss_thresholds,
        }


class ChangeDetector:
    """Performs two-date index comparison calculations."""

    @staticmethod
    def calculate_absolute_difference(pre_arr: Any, post_arr: Any, nodata: float = -9999.0) -> Any:
        """
        Calculates Post - Pre.
        """
        if HAS_NUMPY and isinstance(pre_arr, np.ndarray) and isinstance(post_arr, np.ndarray):
            valid_mask = (pre_arr != nodata) & (post_arr != nodata) & (~np.isnan(pre_arr)) & (~np.isnan(post_arr))
            out = np.full(pre_arr.shape, nodata, dtype=np.float32)
            out[valid_mask] = post_arr[valid_mask] - pre_arr[valid_mask]
            return out
        else:
            if isinstance(pre_arr, list) and isinstance(post_arr, list):
                if len(pre_arr) > 0 and isinstance(pre_arr[0], list):
                    return [[(p2 - p1 if p1 != nodata and p2 != nodata else nodata) for p1, p2 in zip(r1, r2)] for r1, r2 in zip(pre_arr, post_arr)]
                return [(p2 - p1 if p1 != nodata and p2 != nodata else nodata) for p1, p2 in zip(pre_arr, post_arr)]
            return post_arr - pre_arr

    @staticmethod
    def calculate_percentage_change(pre_arr: Any, post_arr: Any, eps: float = 1e-6, nodata: float = -9999.0) -> Any:
        """
        Calculates ((Post - Pre) / (|Pre| + eps)) * 100.
        """
        if HAS_NUMPY and isinstance(pre_arr, np.ndarray) and isinstance(post_arr, np.ndarray):
            valid_mask = (pre_arr != nodata) & (post_arr != nodata) & (~np.isnan(pre_arr)) & (~np.isnan(post_arr))
            out = np.full(pre_arr.shape, nodata, dtype=np.float32)
            denom = np.abs(pre_arr[valid_mask]) + eps
            out[valid_mask] = ((post_arr[valid_mask] - pre_arr[valid_mask]) / denom) * 100.0
            return out
        else:
            def pct(p1, p2):
                if p1 == nodata or p2 == nodata: return nodata
                return ((p2 - p1) / (abs(p1) + eps)) * 100.0
            if isinstance(pre_arr, list) and isinstance(post_arr, list):
                if len(pre_arr) > 0 and isinstance(pre_arr[0], list):
                    return [[pct(p1, p2) for p1, p2 in zip(r1, r2)] for r1, r2 in zip(pre_arr, post_arr)]
                return [pct(p1, p2) for p1, p2 in zip(pre_arr, post_arr)]
            return pct(pre_arr, post_arr)

    @staticmethod
    def classify_gain_loss(
        diff_arr: Any,
        loss_threshold: float = -0.1,
        gain_threshold: float = 0.1,
        nodata_in: float = -9999.0,
        nodata_out: int = 0
    ) -> Any:
        """
        Reclassifies difference array into:
        1 : Significant Loss (diff <= loss_threshold)
        2 : No Significant Change (loss_threshold < diff < gain_threshold)
        3 : Significant Gain (diff >= gain_threshold)
        """
        if HAS_NUMPY and isinstance(diff_arr, np.ndarray):
            valid_mask = (diff_arr != nodata_in) & (~np.isnan(diff_arr))
            out = np.full(diff_arr.shape, nodata_out, dtype=np.int16)
            out[valid_mask & (diff_arr <= loss_threshold)] = 1  # Loss
            out[valid_mask & (diff_arr > loss_threshold) & (diff_arr < gain_threshold)] = 2  # No change
            out[valid_mask & (diff_arr >= gain_threshold)] = 3  # Gain
            return out
        else:
            def c_val(v):
                if v == nodata_in: return nodata_out
                if v <= loss_threshold: return 1
                if v >= gain_threshold: return 3
                return 2
            if isinstance(diff_arr, list):
                if len(diff_arr) > 0 and isinstance(diff_arr[0], list):
                    return [[c_val(v) for v in row] for row in diff_arr]
                return [c_val(v) for v in diff_arr]
            return c_val(diff_arr)

    @staticmethod
    def calculate_dnbr(pre_nbr: Any, post_nbr: Any, nodata: float = -9999.0) -> Any:
        """
        Calculates Differenced NBR (dNBR = Pre_NBR - Post_NBR).
        """
        if HAS_NUMPY and isinstance(pre_nbr, np.ndarray) and isinstance(post_nbr, np.ndarray):
            valid_mask = (pre_nbr != nodata) & (post_nbr != nodata) & (~np.isnan(pre_nbr)) & (~np.isnan(post_nbr))
            out = np.full(pre_nbr.shape, nodata, dtype=np.float32)
            out[valid_mask] = pre_nbr[valid_mask] - post_nbr[valid_mask]
            return out
        else:
            if isinstance(pre_nbr, list) and isinstance(post_nbr, list):
                if len(pre_nbr) > 0 and isinstance(pre_nbr[0], list):
                    return [[(p1 - p2 if p1 != nodata and p2 != nodata else nodata) for p1, p2 in zip(r1, r2)] for r1, r2 in zip(pre_nbr, post_nbr)]
                return [(p1 - p2 if p1 != nodata and p2 != nodata else nodata) for p1, p2 in zip(pre_nbr, post_nbr)]
            return pre_nbr - post_nbr
