"""
AriesLegacy - Index Library Manager.
Loads, manages, and filters geospatial indices database.
"""

import json
import os
from typing import Dict, List, Optional, Any


class IndexDefinition:
    """Represents a single geospatial index calculation definition."""

    def __init__(self, data: Dict[str, Any]):
        self.id: str = data.get("id", "")
        self.aliases: List[str] = data.get("aliases", [])
        self.short_name: str = data.get("short_name", "")
        self.name: str = data.get("name", "")
        self.group: str = data.get("group", "General")
        self.formula: str = data.get("formula", "")
        self.safe_formula: str = data.get("safe_formula", self.formula)
        self.required_bands: List[str] = data.get("required_bands", [])
        self.requires_reflectance_scaling: bool = data.get("requires_reflectance_scaling", data.get("requires_reflectance", True))
        self.value_range: List[float] = data.get("value_range", [-1.0, 1.0])
        self.recommended_style: str = data.get("recommended_style", "RdYlGn")
        self.default_classes: List[Dict[str, Any]] = data.get("default_classes", [])
        self.description: str = data.get("description", "")
        self.reference: str = data.get("reference", "")
        self.is_two_date: bool = data.get("is_two_date", False)
        self.supported_sensors: Optional[List[str]] = data.get("sensors", None)

    def is_compatible_with_sensor(self, sensor_id: str, available_canonical_bands: Optional[List[str]] = None) -> bool:
        """Check if this index can be computed with the given sensor and available bands."""
        if self.supported_sensors is not None and sensor_id not in self.supported_sensors:
            return False
        if available_canonical_bands is not None:
            for b in self.required_bands:
                if b not in available_canonical_bands:
                    return False
        return True

    def format_formula_with_band_names(self, band_name_map: Dict[str, str]) -> str:
        """
        Replaces canonical band symbols (e.g. NIR, RED) with actual layer/band expressions.
        """
        expr = self.safe_formula
        # Replace longer identifiers first to avoid partial overlap
        sorted_keys = sorted(band_name_map.keys(), key=len, reverse=True)
        for canonical in sorted_keys:
            actual_band_expr = band_name_map[canonical]
            # Replace identifier with exact match boundary
            expr = expr.replace(canonical, f"({actual_band_expr})")
        return expr

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "aliases": self.aliases,
            "short_name": self.short_name,
            "name": self.name,
            "group": self.group,
            "formula": self.formula,
            "safe_formula": self.safe_formula,
            "required_bands": self.required_bands,
            "requires_reflectance_scaling": self.requires_reflectance_scaling,
            "value_range": self.value_range,
            "recommended_style": self.recommended_style,
            "default_classes": self.default_classes,
            "description": self.description,
            "reference": self.reference,
            "is_two_date": self.is_two_date,
            "sensors": self.supported_sensors,
        }


class IndexLibrary:
    """Manages the catalogue of spatial indices."""

    _instance: Optional["IndexLibrary"] = None

    def __init__(self, json_path: Optional[str] = None):
        self.indices: Dict[str, IndexDefinition] = {}
        self.alias_map: Dict[str, str] = {}
        if json_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            json_path = os.path.join(base_dir, "data", "index_library.json")
        self.json_path = json_path
        self.load_library()

    @classmethod
    def get_instance(cls, json_path: Optional[str] = None) -> "IndexLibrary":
        if cls._instance is None:
            cls._instance = IndexLibrary(json_path)
        return cls._instance

    def load_library(self) -> None:
        """Loads index catalogue from JSON file."""
        self.indices.clear()
        self.alias_map.clear()
        if os.path.exists(self.json_path):
            try:
                with open(self.json_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for item in data.get("indices", []):
                        idx = IndexDefinition(item)
                        self.indices[idx.id.lower()] = idx
                        self.alias_map[idx.id.lower()] = idx.id.lower()
                        for a in idx.aliases:
                            self.alias_map[a.lower()] = idx.id.lower()
            except Exception as e:
                print(f"[AriesLegacy] Error loading index library: {e}")

    def get_index(self, index_id: str) -> Optional[IndexDefinition]:
        if not index_id:
            return None
        target_id = self.alias_map.get(index_id.lower(), index_id.lower())
        return self.indices.get(target_id)

    def list_all(self) -> List[IndexDefinition]:
        return list(self.indices.values())

    def list_groups(self) -> List[str]:
        groups = set(idx.group for idx in self.indices.values())
        return sorted(list(groups))

    def filter_by_group(self, group_name: str) -> List[IndexDefinition]:
        return [idx for idx in self.indices.values() if idx.group.lower() == group_name.lower()]

    def search(self, query: str) -> List[IndexDefinition]:
        q = query.strip().lower()
        results = []
        for idx in self.indices.values():
            if (q in idx.id.lower() or 
                q in idx.short_name.lower() or 
                q in idx.name.lower() or 
                q in idx.group.lower() or 
                q in idx.description.lower()):
                results.append(idx)
        return results

    def get_indices_for_sensor(self, sensor_id: str, available_canonical_bands: Optional[List[str]] = None) -> List[IndexDefinition]:
        return [
            idx for idx in self.indices.values() 
            if idx.is_compatible_with_sensor(sensor_id, available_canonical_bands)
        ]
