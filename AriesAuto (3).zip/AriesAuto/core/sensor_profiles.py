"""
AriesLegacy - Sensor Profiles Manager.
Handles sensor metadata, band definitions, scaling factors, offsets, and detection rules.
"""

import json
import os
from typing import Dict, List, Optional, Any


class SensorProfile:
    """Represents a single sensor configuration profile."""

    def __init__(self, data: Dict[str, Any]):
        self.id: str = data.get("id", "")
        self.name: str = data.get("name", "")
        self.agency: str = data.get("agency", "")
        self.description: str = data.get("description", "")
        self.scale_factor: float = float(data.get("scale_factor", 1.0))
        self.offset: float = float(data.get("offset", 0.0))
        self.thermal_scale_factor: Optional[float] = data.get("thermal_scale_factor")
        self.thermal_offset: Optional[float] = data.get("thermal_offset")
        self.nodata_value: Any = data.get("nodata_value", 0)
        self.bands: Dict[str, Dict[str, Any]] = data.get("bands", {})
        self.detection_patterns: List[str] = data.get("detection_patterns", [])

    def get_band_info(self, canonical_name: str) -> Optional[Dict[str, Any]]:
        """Get band details for canonical band name like NIR, RED, BLUE, etc."""
        return self.bands.get(canonical_name.upper())

    def get_canonical_name_for_alias(self, alias_or_name: str) -> Optional[str]:
        """Resolve a specific band name or alias back to canonical name (e.g., B08 -> NIR)."""
        clean_alias = alias_or_name.strip().upper()
        for canonical, info in self.bands.items():
            if info.get("name", "").upper() == clean_alias:
                return canonical
            aliases = [a.upper() for a in info.get("aliases", [])]
            if clean_alias in aliases:
                return canonical
        return None

    def list_canonical_bands(self) -> List[str]:
        """List all canonical band names in this profile."""
        return list(self.bands.keys())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "agency": self.agency,
            "description": self.description,
            "scale_factor": self.scale_factor,
            "offset": self.offset,
            "thermal_scale_factor": self.thermal_scale_factor,
            "thermal_offset": self.thermal_offset,
            "nodata_value": self.nodata_value,
            "bands": self.bands,
            "detection_patterns": self.detection_patterns,
        }


class SensorProfileManager:
    """Manages loading, retrieving, and registering sensor profiles."""

    _instance: Optional["SensorProfileManager"] = None

    def __init__(self, json_path: Optional[str] = None):
        self.profiles: Dict[str, SensorProfile] = {}
        if json_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            json_path = os.path.join(base_dir, "data", "sensor_profiles.json")
        self.json_path = json_path
        self.load_profiles()

    @classmethod
    def get_instance(cls, json_path: Optional[str] = None) -> "SensorProfileManager":
        if cls._instance is None:
            cls._instance = SensorProfileManager(json_path)
        return cls._instance

    def load_profiles(self) -> None:
        """Loads profiles from JSON file."""
        if os.path.exists(self.json_path):
            try:
                with open(self.json_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    sensors = data.get("sensors", {})
                    for sid, sdata in sensors.items():
                        self.profiles[sid] = SensorProfile(sdata)
            except Exception as e:
                print(f"[AriesLegacy] Error loading sensor profiles: {e}")
        
        # Ensure default generic profile exists
        if "generic" not in self.profiles:
            self.profiles["generic"] = SensorProfile({
                "id": "generic",
                "name": "Generic Optical Multispectral",
                "scale_factor": 1.0,
                "offset": 0.0,
                "bands": {
                    "BLUE": {"name": "Blue", "aliases": ["b2", "blue"]},
                    "GREEN": {"name": "Green", "aliases": ["b3", "green"]},
                    "RED": {"name": "Red", "aliases": ["b4", "red"]},
                    "NIR": {"name": "NIR", "aliases": ["b8", "b5", "nir"]},
                    "SWIR_1": {"name": "SWIR1", "aliases": ["b11", "b6", "swir1"]},
                    "SWIR_2": {"name": "SWIR2", "aliases": ["b12", "b7", "swir2"]}
                },
                "detection_patterns": []
            })

    def get_profile(self, sensor_id: str) -> Optional[SensorProfile]:
        return self.profiles.get(sensor_id)

    def list_profiles(self) -> List[SensorProfile]:
        return list(self.profiles.values())

    def match_sensor_by_name_or_metadata(self, text: str) -> Optional[SensorProfile]:
        """Detect sensor profile from a raster file path, layer name, or metadata string."""
        upper_text = text.upper()
        for profile in self.profiles.values():
            for pattern in profile.detection_patterns:
                if pattern.upper() in upper_text:
                    return profile
        return None
