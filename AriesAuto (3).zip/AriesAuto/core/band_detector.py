"""
AriesLegacy - Band Detector.
Inspects raster layers, filenames, band names, and metadata to identify sensors and map bands automatically.
"""

import os
import re
from typing import Dict, List, Optional, Tuple, Any

from .sensor_profiles import SensorProfile, SensorProfileManager


class BandDetectionResult:
    """Encapsulates detected sensor and canonical band mappings."""

    def __init__(self, sensor_profile: SensorProfile, confidence: str = "Low"):
        self.sensor_profile: SensorProfile = sensor_profile
        self.confidence: str = confidence  # "High", "Medium", "Low", "Manual"
        self.band_to_number: Dict[str, int] = {}       # Canonical -> band index (1-based)
        self.band_to_layer_id: Dict[str, str] = {}    # Canonical -> layer ID (for multi-layer setups)
        self.band_to_path: Dict[str, str] = {}        # Canonical -> file path
        self.warnings: List[str] = []
        self.detected_resolutions: Dict[str, float] = {}

    def is_complete_for_index(self, required_canonical_bands: List[str]) -> bool:
        for b in required_canonical_bands:
            if b not in self.band_to_number and b not in self.band_to_layer_id and b not in self.band_to_path:
                return False
        return True

    def get_missing_bands(self, required_canonical_bands: List[str]) -> List[str]:
        missing = []
        for b in required_canonical_bands:
            if b not in self.band_to_number and b not in self.band_to_layer_id and b not in self.band_to_path:
                missing.append(b)
        return missing

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sensor_id": self.sensor_profile.id,
            "sensor_name": self.sensor_profile.name,
            "confidence": self.confidence,
            "band_to_number": self.band_to_number,
            "band_to_path": self.band_to_path,
            "warnings": self.warnings,
            "detected_resolutions": self.detected_resolutions,
        }


class BandDetector:
    """Automated detector for imagery sensors and band configurations."""

    def __init__(self, profile_manager: Optional[SensorProfileManager] = None):
        self.profile_mgr = profile_manager or SensorProfileManager.get_instance()

    def detect_sensor_from_text(self, text: str) -> SensorProfile:
        """Determines sensor profile based on file path, layer name, or metadata string."""
        matched = self.profile_mgr.match_sensor_by_name_or_metadata(text)
        if matched:
            return matched
        return self.profile_mgr.get_profile("generic") or SensorProfile({"id": "generic", "name": "Generic"})

    def detect_from_file_path(self, file_path: str, band_count: int = 1, band_names: Optional[List[str]] = None) -> BandDetectionResult:
        """
        Detects sensor and canonical band mappings for a given raster file path and band list.
        """
        filename = os.path.basename(file_path)
        profile = self.detect_sensor_from_text(file_path)
        confidence = "Low"
        if profile.id != "generic":
            confidence = "High"

        result = BandDetectionResult(profile, confidence)
        names = band_names or []

        # If multiband stack
        if band_count > 1:
            self._map_multiband_stack(result, band_count, names, filename)
        else:
            # Single band file
            canonical = self._identify_canonical_from_filename(filename, profile)
            if canonical:
                result.band_to_number[canonical] = 1
                result.band_to_path[canonical] = file_path
                result.confidence = "High"

        return result

    def detect_from_layer_collection(self, layers_info: List[Dict[str, Any]]) -> BandDetectionResult:
        """
        Detects bands across a collection of single-band layers (e.g., individual Sentinel-2 / Landsat files).
        layers_info: list of dicts with {"id": layer_id, "name": layer_name, "source": file_path}
        """
        all_text = " ".join([l.get("source", "") + " " + l.get("name", "") for l in layers_info])
        profile = self.detect_sensor_from_text(all_text)
        confidence = "Medium" if profile.id != "generic" else "Low"
        result = BandDetectionResult(profile, confidence)

        for l in layers_info:
            source = l.get("source", "")
            name = l.get("name", "")
            lid = l.get("id", "")
            fname = os.path.basename(source) if source else name

            canonical = self._identify_canonical_from_filename(fname, profile)
            if not canonical:
                canonical = self._identify_canonical_from_filename(name, profile)

            if canonical and canonical not in result.band_to_layer_id:
                result.band_to_layer_id[canonical] = lid
                result.band_to_path[canonical] = source
                result.band_to_number[canonical] = 1

        if len(result.band_to_layer_id) >= 3:
            result.confidence = "High"

        return result

    def _map_multiband_stack(self, result: BandDetectionResult, band_count: int, band_names: List[str], filename: str) -> None:
        """Heuristically maps bands for multiband composite rasters."""
        profile = result.sensor_profile
        
        # 1. Try matching with explicit band names if provided
        for idx, bname in enumerate(band_names, start=1):
            canonical = profile.get_canonical_name_for_alias(bname)
            if canonical:
                result.band_to_number[canonical] = idx

        # 2. If nothing matched from band names, use sensor standard stack conventions
        if not result.band_to_number:
            if profile.id == "sentinel_2_l2a":
                # Standard S2 10m/20m 12-band stack: B1(60m), B2(Blue), B3(Green), B4(Red), B5, B6, B7, B8(NIR), B8A, B9, B11(SWIR1), B12(SWIR2)
                if band_count >= 12:
                    result.band_to_number["COASTAL"] = 1
                    result.band_to_number["BLUE"] = 2
                    result.band_to_number["GREEN"] = 3
                    result.band_to_number["RED"] = 4
                    result.band_to_number["RED_EDGE_1"] = 5
                    result.band_to_number["RED_EDGE_2"] = 6
                    result.band_to_number["RED_EDGE_3"] = 7
                    result.band_to_number["NIR"] = 8
                    result.band_to_number["NIR_NARROW"] = 9
                    result.band_to_number["SWIR_1"] = 11
                    result.band_to_number["SWIR_2"] = 12
                elif band_count == 4:
                    # Common B, G, R, NIR stack (10m bands)
                    result.band_to_number["BLUE"] = 1
                    result.band_to_number["GREEN"] = 2
                    result.band_to_number["RED"] = 3
                    result.band_to_number["NIR"] = 4

            elif profile.id in ("landsat_8_9_c2_l2", "landsat_5_7_c2_l2"):
                if profile.id == "landsat_8_9_c2_l2" and band_count >= 7:
                    result.band_to_number["COASTAL"] = 1
                    result.band_to_number["BLUE"] = 2
                    result.band_to_number["GREEN"] = 3
                    result.band_to_number["RED"] = 4
                    result.band_to_number["NIR"] = 5
                    result.band_to_number["SWIR_1"] = 6
                    result.band_to_number["SWIR_2"] = 7
                    if band_count >= 8:
                        result.band_to_number["THERMAL"] = 8
                elif profile.id == "landsat_5_7_c2_l2" and band_count >= 6:
                    result.band_to_number["BLUE"] = 1
                    result.band_to_number["GREEN"] = 2
                    result.band_to_number["RED"] = 3
                    result.band_to_number["NIR"] = 4
                    result.band_to_number["SWIR_1"] = 5
                    result.band_to_number["THERMAL"] = 6
                    result.band_to_number["SWIR_2"] = 7

            else:
                # Generic RGB/NIR heuristic
                if band_count >= 4:
                    result.band_to_number["BLUE"] = 1
                    result.band_to_number["GREEN"] = 2
                    result.band_to_number["RED"] = 3
                    result.band_to_number["NIR"] = 4
                elif band_count == 3:
                    result.band_to_number["RED"] = 1
                    result.band_to_number["GREEN"] = 2
                    result.band_to_number["BLUE"] = 3

    def _identify_canonical_from_filename(self, filename: str, profile: SensorProfile) -> Optional[str]:
        """Matches a single band filename to a canonical band name."""
        base, _ = os.path.splitext(filename)
        upper = base.upper()

        # Check profiles (the passed profile first, then other profiles if generic)
        profiles_to_check = [profile]
        if profile.id == "generic":
            profiles_to_check.extend(self.profile_mgr.list_profiles())

        for p in profiles_to_check:
            for canonical, info in p.bands.items():
                bname = info.get("name", "").upper()
                aliases = [a.upper() for a in info.get("aliases", [])]

                tokens = [bname] + aliases
                for token in tokens:
                    if not token: continue
                    # Match patterns like "_B04", "_B4", "B04_", "B4_", "-B04", "B04-", ".B04", " B04 "
                    pattern = rf"(?:^|[_\-\.\s]){re.escape(token)}(?:[_\-\.\s]|$)"
                    if re.search(pattern, upper):
                        return canonical

        # Generic keyword fallback
        if "RED" in upper and "RED_EDGE" not in upper:
            return "RED"
        if "NIR" in upper or "NEAR_INFRARED" in upper or "B08" in upper or "B8" in upper:
            return "NIR"
        if "GREEN" in upper or "B03" in upper or "B3" in upper:
            return "GREEN"
        if "BLUE" in upper or "B02" in upper or "B2" in upper:
            return "BLUE"
        if "SWIR1" in upper or "SWIR_1" in upper or "B11" in upper or "B6" in upper:
            return "SWIR_1"
        if "SWIR2" in upper or "SWIR_2" in upper or "B12" in upper or "B7" in upper:
            return "SWIR_2"
        if "THERMAL" in upper or "TEMP" in upper or "ST_B10" in upper or "B10" in upper:
            return "THERMAL"

        return None
