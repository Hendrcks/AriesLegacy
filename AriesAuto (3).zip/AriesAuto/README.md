# 🛰️ AriesLegacy — Geo AI Automation for QGIS

[![QGIS Version](https://img.shields.io/badge/QGIS-3.16+-brightgreen.svg)](https://qgis.org)
[![License](https://img.shields.io/badge/License-GPLv2+-blue.svg)](LICENSE)
[![Release](https://img.shields.io/badge/Version-1.0.0-orange.svg)](CHANGELOG.md)
[![Tests](https://img.shields.io/badge/Tests-Passing-success.svg)](tests/)

**AriesLegacy** is a professional QGIS plugin that makes satellite-based spatial-index analysis simple, guided, reproducible, and transparent. It enables users to select optical satellite imagery, choose an objective or type a plain-language natural request, and receive correctly calculated, styled, classified, and documented results in seconds.

---

## 🌟 Key Features

- **20+ Calibrated Scientific Indices**: Vegetation (NDVI, GNDVI, EVI, SAVI, MSAVI, NDMI), Water & Flood (NDWI, MNDWI, AWEI_nsh, AWEI_sh), Built-up (NDBI, UI), Bare Soil & Mining (BSI, NBR, Iron Oxide Ratio, Clay Minerals Ratio), Fire & Change (NBR, dNBR, NBR2), and Land Surface Temperature (LST).
- **Intelligent Band & Sensor Auto-Detection**: Automatically identifies Sentinel-2 Level-2A and Landsat 8/9 Collection 2 products and maps standard canonical bands with manual fallback.
- **Radiometric Scaling & Offset Automation**: Automatically converts raw digital numbers (DN) to BOA Surface Reflectance ($0.0 - 1.0$) and Celsius temperatures ($^\circ\text{C}$).
- **Two-Date Change Detection**: Computes absolute differences, percentage changes, thresholded Gain/No-Change/Loss categories, and USGS dNBR burn severity.
- **Thematic Threshold Classification & Area Statistics**: Reclassifies continuous index rasters into customizable discrete categories and calculates exact surface areas in **Hectares ($ha$)**, **Square Kilometres ($km^2$)**, and **Square Metres ($m^2$)**.
- **Geo AI Assistant Studio**:
  - *Tier 1 (Offline Smart Rules)*: Pre-configured remote sensing workflows for environmental objectives (Mining disturbance, flood delineation, crop health, urban sprawl, wildfire impact).
  - *Tier 2 (Natural Language Understanding)*: Translates plain English user queries into reviewed, 1-click execution workflows with zero unvalidated code execution.
- **Full QGIS Processing Toolbox Provider**: All AriesLegacy algorithms are registered in the QGIS Processing Toolbox and QGIS Graphical Modeler.
- **Automated Map & Report Exports**: Generates styled QML layer definition files, CSV statistic tables, and print-ready HTML/Markdown audit reports with complete mathematical formulas and scientific citations.

---

## 🏛️ System Architecture

```mermaid
flowchart TD
  A[Select Satellite Imagery] --> B[Auto-Detect Sensor & Bands]
  B --> C[Validate Extent, CRS & Scaling]
  C --> D[Choose Index or Geo AI Objective]
  D --> E[Safe Raster Calculation]
  E --> F[Apply Recommended Symbology]
  F --> G[Threshold Classification & Hectare Area Stats]
  G --> H[Export GeoTIFF, QML, CSV & HTML/MD Report]
```

---

## 📦 Installation

### Option 1: Install from ZIP in QGIS
1. Download the latest release ZIP `AriesLegacy.zip` from [Releases](https://github.com/AriesPlus/AriesLegacy/releases).
2. Open QGIS.
3. In the menu, go to **Plugins** > **Manage and Install Plugins...**
4. Select **Install from ZIP** on the left menu.
5. Browse to `AriesLegacy.zip` and click **Install Plugin**.
6. Activate `AriesLegacy` in the **Installed** tab.

### Option 2: Manual Directory Installation
Clone or copy the `AriesLegacy` folder into your QGIS plugins directory:
- **Windows**: `C:\Users\<User>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\AriesLegacy`
- **macOS**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/AriesLegacy`
- **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/AriesLegacy`

---

## 🚀 Quick Start Guide (Sentinel-2 NDVI in 3 Steps)

1. **Load Sentinel-2 Imagery**: Add your Sentinel-2 L2A multiband composite or individual band rasters to your QGIS project canvas.
2. **Open AriesLegacy**: Click the **✨ AriesLegacy** icon on the raster toolbar to open the dock panel.
3. **Run Quick Analysis**:
   - In the **Quick Index** tab, select your raster layer or tick individual band layers.
   - AriesLegacy will detect `Sentinel-2 MSI (Level-2A)` and automatically assign `B08 (NIR)` and `B04 (RED)`.
   - Select `NDVI — Normalized Difference Vegetation Index`.
   - Click **⚡ Calculate Index**.
   - The styled, calibrated NDVI layer is immediately added to your QGIS map canvas!

---

## 📚 Complete Index Library

| Category | Index | Canonical Formula | Main Application |
| :--- | :--- | :--- | :--- |
| **Vegetation** | **NDVI** | $(NIR - RED) / (NIR + RED)$ | General vegetation vigor & canopy density |
| **Vegetation** | **EVI** | $2.5 \times (NIR - RED) / (NIR + 6 RED - 7.5 BLUE + 1)$ | High-biomass canopy & dense forest monitoring |
| **Vegetation** | **SAVI** | $((NIR - RED) / (NIR + RED + 0.5)) \times 1.5$ | Sparse arid vegetation & soil background reduction |
| **Vegetation** | **MSAVI2** | $(2 NIR + 1 - \sqrt{(2 NIR + 1)^2 - 8(NIR - RED)}) / 2$ | Self-adjusting soil background correction |
| **Vegetation** | **GNDVI** | $(NIR - GREEN) / (NIR + GREEN)$ | Chlorophyll concentration & crop nitrogen status |
| **Vegetation** | **NDMI** | $(NIR - SWIR_1) / (NIR + SWIR_1)$ | Canopy water content & drought stress |
| **Water / Flood**| **MNDWI**| $(GREEN - SWIR_1) / (GREEN + SWIR_1)$ | Surface water delineation & urban flood mapping |
| **Water / Flood**| **NDWI** | $(GREEN - NIR) / (GREEN + NIR)$ | Open surface water bodies |
| **Water / Flood**| **AWEI_nsh** | $4(GREEN - SWIR_1) - (0.25 NIR + 2.75 SWIR_2)$ | Stable shadow-resistant water extraction |
| **Water / Flood**| **AWEI_sh** | $BLUE + 2.5 GREEN - 1.5(NIR + SWIR_1) - 0.25 SWIR_2$ | Urban shadow & mountain water extraction |
| **Built-up** | **NDBI** | $(SWIR_1 - NIR) / (SWIR_1 + NIR)$ | Urban settlement & impervious surface footprints |
| **Built-up** | **UI** | $(SWIR_2 - NIR) / (SWIR_2 + NIR)$ | Urban infrastructure mapping |
| **Mining / Soil**| **BSI** | $((SWIR_1 + RED) - (NIR + BLUE)) / ((SWIR_1 + RED) + (NIR + BLUE))$ | Bare ground, excavation pits & mine disturbance |
| **Mining / Soil**| **Iron Oxide** | $RED / BLUE$ | Iron mineral enrichment & mine tailings |
| **Mining / Soil**| **Clay Ratio** | $SWIR_1 / SWIR_2$ | Clay mineral alteration & exposed soils |
| **Fire / Change**| **NBR** | $(NIR - SWIR_2) / (NIR + SWIR_2)$ | Burn severity baseline & canopy fire impact |
| **Fire / Change**| **NBR2** | $(SWIR_1 - SWIR_2) / (SWIR_1 + SWIR_2)$ | Non-photosynthetic vegetation residue & burns |
| **Fire / Change**| **dNBR** | $NBR_{pre} - NBR_{post}$ | Post-fire burn severity categorization (USGS) |
| **Temperature** | **LST** | $(THERMAL \times 0.00341802 + 149.0) - 273.15$ | Land surface temperature in Celsius ($^\circ\text{C}$) |

---

## 🧪 Testing

Run the automated test suite locally:
```bash
python -m unittest discover -s tests -p "test_*.py"
```

---

## 📄 License & Attribution

Licensed under the **GNU General Public License v2.0 or later (GPL-2.0-or-later)**.  
Developed by **AriesPlus Geospatial Solutions**.
