# AriesAuto Formula & Algorithm Specification

## Purpose

This is the implementation specification for the **AriesAuto** QGIS plugin index engine. It defines the approved formulas, sensor-band mappings, scaling rules, validations and output rules for every index shown in the current interface.

**Important:** formulas must be calculated from **surface reflectance in real reflectance units**, not raw display values or unscaled digital numbers. This is the main reason an NDVI output can be wrong.

## 1. Non-negotiable calculation rules

1. Use floating-point arrays/raster bands; never integer division.
2. Mask NoData, fill pixels, cloud, cloud shadow and saturated pixels before calculation where QA data is available.
3. Apply scale and offset **before** indices containing additive constants (especially EVI, SAVI and MSAVI). For normalized-difference indices, the offset in Landsat Collection 2 means scaling must still be applied first.
4. For every ratio, return NoData where the denominator is zero or invalid.
5. Do not combine imagery from different dates until the rasters use a matching CRS, extent, pixel grid and resolution.
6. Save all outputs as Float32 GeoTIFF, except final categorical classes which may be Byte/Int16.
7. Store the exact bands, formula, scale/offset, mask rule, timestamp and plugin version in the layer metadata and report.

## 2. Canonical spectral variables

| Variable | Meaning | Sentinel-2 L2A | Landsat 8/9 Collection 2 Level-2 |
|---|---|---|---|
| BLUE | Blue reflectance | B02 | SR_B2 |
| GREEN | Green reflectance | B03 | SR_B3 |
| RED | Red reflectance | B04 | SR_B4 |
| RE1 | Red-edge 1 | B05 | — |
| NIR | Near infrared | B08 | SR_B5 |
| SWIR1 | Shortwave infrared 1 | B11 | SR_B6 |
| SWIR2 | Shortwave infrared 2 | B12 | SR_B7 |
| THERMAL | Surface-temperature product | Not available from Sentinel-2 | ST_B10 |

**Resolution rule for Sentinel-2:** B02, B03, B04 and B08 are 10 m; B11/B12 are 20 m. When one formula combines 10 m and 20 m bands, resample once to the user-selected analysis grid. Default: use the coarsest required resolution (20 m) and bilinear resampling for continuous reflectance. Do not silently claim a 10 m SWIR-derived result.

## 3. Scaling and preprocessing

### 3.1 Sentinel-2 Level-2A

Use surface-reflectance values. Sentinel-2 SAFE JP2 values are commonly stored as reflectance scaled by 10,000:

```text
reflectance = DN / 10000.0
```

If the input is already a reflectance product in the 0–1 range, do not divide again. The plugin must inspect metadata when possible and otherwise ask the user to confirm the data scale.

### 3.2 Landsat 8/9 Collection 2 Level-2 Surface Reflectance

For each `SR_B*` band:

```text
reflectance = (DN × 0.0000275) − 0.2
```

Do not use a true-colour browse image, `QA_*` band or uncorrected Level-1 DN as a surface-reflectance band.

### 3.3 Landsat 8/9 Collection 2 Level-2 Surface Temperature

```text
LST_K = (DN × 0.00341802) + 149.0
LST_C = LST_K − 273.15
```

Use **ST_B10**, which is already a USGS surface-temperature product. Do not run a separate radiance/brightness-temperature/emissivity workflow on ST_B10. Sentinel-2 has no thermal band; AriesAuto must disable LST for Sentinel-2-only inputs.

## 4. Safe formula helper

All normalized ratios use a protected divide:

```python
def safe_divide(numerator, denominator, nodata=np.nan):
    return where(isfinite(numerator) & isfinite(denominator) & (denominator != 0),
                 numerator / denominator,
                 nodata)
```

All square-root expressions must be clamped against very small negative floating-point round-off:

```python
sqrt(max(discriminant, 0))
```

## 5. Approved index formulas

### A. Vegetation and moisture

| ID | Name | Formula | Expected output |
|---|---|---|---|
| NDVI | Normalized Difference Vegetation Index | `(NIR − RED) / (NIR + RED)` | approximately −1 to +1 |
| GNDVI | Green Normalized Difference Vegetation Index | `(NIR − GREEN) / (NIR + GREEN)` | approximately −1 to +1 |
| EVI | Enhanced Vegetation Index | `2.5 × (NIR − RED) / (NIR + 6×RED − 7.5×BLUE + 1)` | commonly about −1 to +1 |
| SAVI | Soil-Adjusted Vegetation Index, L = 0.5 | `1.5 × (NIR − RED) / (NIR + RED + 0.5)` | approximately −1 to +1 |
| MSAVI2 | Modified Soil-Adjusted Vegetation Index | `(2×NIR + 1 − sqrt((2×NIR + 1)² − 8×(NIR − RED))) / 2` | approximately −1 to +1 |
| NDMI | Normalized Difference Moisture Index | `(NIR − SWIR1) / (NIR + SWIR1)` | approximately −1 to +1 |

### B. Water and flood support

| ID | Name | Formula | Expected output |
|---|---|---|---|
| NDWI | Normalized Difference Water Index (McFeeters) | `(GREEN − NIR) / (GREEN + NIR)` | approximately −1 to +1 |
| MNDWI | Modified NDWI (Xu) | `(GREEN − SWIR1) / (GREEN + SWIR1)` | approximately −1 to +1 |
| AWEI_nsh | Automated Water Extraction Index – non-shadow | `4×(GREEN − SWIR1) − (0.25×NIR + 2.75×SWIR2)` | continuous; not limited to −1 to +1 |
| AWEI_sh | Automated Water Extraction Index – shadow | `BLUE + 2.5×GREEN − 1.5×(NIR + SWIR1) − 0.25×SWIR2` | continuous; not limited to −1 to +1 |

### C. Built-up and bare surface

| ID | Name | Formula | Expected output |
|---|---|---|---|
| NDBI | Normalized Difference Built-up Index | `(SWIR1 − NIR) / (SWIR1 + NIR)` | approximately −1 to +1 |
| UI | Urban Index | `(SWIR2 − NIR) / (SWIR2 + NIR)` | approximately −1 to +1 |
| BSI | Bare Soil Index | `((SWIR1 + RED) − (NIR + BLUE)) / ((SWIR1 + RED) + (NIR + BLUE))` | approximately −1 to +1 |

**Interpretation warning:** NDBI, UI and BSI can be high for bare land, dry soil, exposed mining surfaces and some built-up materials. They are indicators, not automatic built-up classification.

### D. Fire, burn and change

| ID | Name | Formula | Expected output |
|---|---|---|---|
| NBR | Normalized Burn Ratio | `(NIR − SWIR2) / (NIR + SWIR2)` | approximately −1 to +1 |
| NBR2 | Normalized Burn Ratio 2 | `(SWIR1 − SWIR2) / (SWIR1 + SWIR2)` | approximately −1 to +1 |
| dNBR | Differenced Normalized Burn Ratio | `NBR_pre-fire − NBR_post-fire` | continuous; positive values generally indicate greater burn impact |

For dNBR, the plugin must force the user to mark which input is **pre-event** and which is **post-event**. Do not calculate post minus pre under the name dNBR.

### E. Mineral / geological proxy ratios

| ID | Name | Formula | Expected output |
|---|---|---|---|
| CLAY_RATIO | Clay Minerals Ratio | `SWIR1 / SWIR2` | continuous ratio |
| IRON_OXIDE_RATIO | Iron Oxide Ratio | `RED / BLUE` | continuous ratio |

**Naming correction:** do not label `RED / BLUE` as “Ferrous Iron / Iron Oxide” because ferrous-iron mapping uses different, sensor- and study-specific approaches. In Version 1, use the precise label **Iron Oxide Ratio**. Both mineral ratios are exploratory spectral proxies and require local geological/field validation.

### F. Land Surface Temperature

| ID | Name | Formula | Expected output |
|---|---|---|---|
| LST_C | Land Surface Temperature (Celsius) | `((ST_B10 × 0.00341802) + 149.0) − 273.15` | degrees Celsius |

## 6. Exact formulas after variable mapping

The algorithm must map the canonical variables first, then build exactly these expressions:

```text
NDVI = safe_divide(NIR - RED, NIR + RED)
GNDVI = safe_divide(NIR - GREEN, NIR + GREEN)
EVI = safe_divide(2.5 * (NIR - RED), NIR + 6*RED - 7.5*BLUE + 1.0)
SAVI = safe_divide(1.5 * (NIR - RED), NIR + RED + 0.5)
MSAVI2 = (2*NIR + 1 - sqrt(max((2*NIR + 1)^2 - 8*(NIR - RED), 0))) / 2
NDMI = safe_divide(NIR - SWIR1, NIR + SWIR1)
NDWI = safe_divide(GREEN - NIR, GREEN + NIR)
MNDWI = safe_divide(GREEN - SWIR1, GREEN + SWIR1)
AWEI_nsh = 4*(GREEN - SWIR1) - (0.25*NIR + 2.75*SWIR2)
AWEI_sh = BLUE + 2.5*GREEN - 1.5*(NIR + SWIR1) - 0.25*SWIR2
NDBI = safe_divide(SWIR1 - NIR, SWIR1 + NIR)
UI = safe_divide(SWIR2 - NIR, SWIR2 + NIR)
BSI = safe_divide((SWIR1 + RED) - (NIR + BLUE), (SWIR1 + RED) + (NIR + BLUE))
NBR = safe_divide(NIR - SWIR2, NIR + SWIR2)
NBR2 = safe_divide(SWIR1 - SWIR2, SWIR1 + SWIR2)
dNBR = NBR_pre - NBR_post
CLAY_RATIO = safe_divide(SWIR1, SWIR2)
IRON_OXIDE_RATIO = safe_divide(RED, BLUE)
LST_C = (ST_B10 * 0.00341802 + 149.0) - 273.15
```

## 7. Algorithm workflow

```mermaid
flowchart TD
    A[User selects raster] --> B[Detect product and sensor]
    B --> C[Map canonical bands]
    C --> D[Apply scale, offset and QA mask]
    D --> E[Validate formula requirements]
    E --> F[Calculate Float32 index]
    F --> G[Check range and NoData]
    G --> H[Style, classify and export]
```

### Required processing sequence

1. Identify input product (Sentinel-2 L2A, Landsat 8/9 C2 L2, or manual).
2. Detect and show proposed band mapping.
3. Require the user to correct/confirm mapping where confidence is not high.
4. Convert raw integer bands to real reflectance.
5. Apply optional QA cloud/shadow/saturation masks.
6. Reproject/resample bands to a common grid only where required.
7. Build expression from the approved formula table.
8. Execute using Float32/Float64 arithmetic.
9. Reject or mask invalid denominator pixels.
10. Run output-quality checks and display formula, mapped bands and preprocessing in the results panel.

## 8. NDVI diagnostic: why results go wrong

The NDVI algorithm must report a warning when any of these conditions are detected:

| Problem | Incorrect behaviour | Required correction |
|---|---|---|
| Landsat raw C2 L2 integers used directly | Uses `(SR_B5 − SR_B4)/(SR_B5 + SR_B4)` before scale/offset | First convert each band with `DN×0.0000275−0.2` |
| Wrong Landsat bands | Uses B4 as NIR or B5 as red | Landsat 8/9: NIR = SR_B5; RED = SR_B4 |
| Wrong Sentinel-2 bands | Uses B04 as NIR or B08 as red | Sentinel-2: NIR = B08; RED = B04 |
| Colour composite selected | Computes on RGB display layer instead of physical bands | Require individual reflectance bands or a band stack with verified order |
| Integer output | Values become only -1, 0 or 1 | Force Float32 output |
| NoData not masked | Black edges/fill pixels produce extreme values | Propagate NoData and QA masks |
| Formula uses string labels rather than resolved bands | Expression references unavailable names | Resolve every canonical variable to an actual raster band first |

### Mandatory NDVI test

Create a tiny test raster with valid **scaled reflectance** values:

| Pixel | NIR | RED | Expected NDVI |
|---|---:|---:|---:|
| Healthy vegetation | 0.60 | 0.10 | 0.7142857 |
| Bare soil | 0.30 | 0.25 | 0.0909091 |
| Water | 0.02 | 0.04 | -0.3333333 |

The tool must match these values within ±0.0001.

## 9. Machine-readable index configuration

Use this structure in `data/index_library.json`; formula strings use canonical variable names only.

```json
{
  "ndvi": {
    "name": "Normalized Difference Vegetation Index",
    "group": "vegetation",
    "required_variables": ["NIR", "RED"],
    "formula": "safe_divide(NIR - RED, NIR + RED)",
    "output_type": "float32",
    "expected_range": [-1.0, 1.0],
    "default_style": "ndvi_rdylgn",
    "requires_reflectance_scaling": true
  },
  "lst_c": {
    "name": "Land Surface Temperature (Celsius)",
    "group": "temperature",
    "required_variables": ["THERMAL"],
    "formula": "(THERMAL * 0.00341802 + 149.0) - 273.15",
    "output_type": "float32",
    "unit": "degC",
    "allowed_sensors": ["landsat_8_9_c2_l2"],
    "requires_reflectance_scaling": false
  }
}
```

Use a valid style ID without spaces in code, for example `ndvi_rdylgn`.

## 10. Guardrails for the user interface

- Display the resolved expression, e.g., `(scaled(SR_B5) − scaled(SR_B4)) / …`, before Run.
- Display a green **Validated** status only after product, bands, scale and required resolution have been checked.
- When an index needs SWIR and Sentinel-2 B08 is 10 m, show: “This output will be calculated at 20 m because SWIR is 20 m.”
- Disable LST for Sentinel-2 inputs and explain why.
- Do not provide fixed “water”, “built-up” or “vegetation” thresholds as universal facts. Offer editable starter thresholds and label them as local validation required.
- For ratios outside the expected range, show a diagnostic rather than silently stretch values.

## 11. Quality-assurance checks

| Check | Pass condition | Action on failure |
|---|---|---|
| Band completeness | Every required variable maps to one valid raster band | Block calculation |
| Scaling | Product scaling rule is known or confirmed | Block calculation |
| Grid compatibility | Same CRS/grid or approved resampling plan | Block/change workflow prompt |
| Valid denominator | Denominator not zero for processed pixels | Return NoData for invalid pixels |
| Output type | Float32 or Float64 continuous output | Block integer output |
| LST availability | Landsat C2 L2 ST_B10 exists | Disable LST |
| Change direction | Pre and post order confirmed for dNBR | Block calculation |

## 12. References for implementation

- [USGS: Landsat Collection 2 Level-2 scale factors](https://www.usgs.gov/faqs/how-do-i-use-a-scale-factor-landsat-level-2-science-products) — authoritative reflectance and surface-temperature scaling.
- [USGS: Landsat Collection 2 surface temperature](https://www.usgs.gov/landsat-missions/landsat-collection-2-surface-temperature) — ST_B10 conversion.
- [Copernicus Sentinel-2 mission information](https://dataspace.copernicus.eu/data-collections/copernicus-sentinel-missions/sentinel-2) — Sentinel-2 spectral/resolution context.
- Rouse et al. (1974), NDVI.
- Huete (1988), SAVI; Huete et al. (2002), EVI.
- Qi et al. (1994), MSAVI.
- Gao (1996), NDMI.
- McFeeters (1996), NDWI; Xu (2006), MNDWI.
- Feyisa et al. (2014), AWEI.
- Zha, Gao & Ni (2003), NDBI.
- Key & Benson (2006), NBR/dNBR.

## 13. Implementation decision

The displayed index menu can keep its current names, with one correction:

```text
Replace: Iron Oxide — Ferrous Iron / Iron Oxide Index
With:    Iron Oxide Ratio — Red / Blue Spectral Ratio
```

This prevents the plugin from making an unsupported mineralogical claim. Add ferrous-iron algorithms later only after selecting a specific validated method and documenting its sensor requirements.
