# Contributing to AriesLegacy

We welcome contributions, bug reports, and formula enhancements to **AriesLegacy**!

## Development Workflow

1. Fork the repository on GitHub.
2. Clone your fork locally:
   ```bash
   git clone https://github.com/Hendrcks/AriesLegacy.git
   cd AriesLegacy
   ```
2. **Set up Virtual Environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Or venv\Scripts\activate on Windows
   pip install -r requirements-dev.txt
   ```
3. **Run Test Suite**:
   ```bash
   python -m unittest discover -s tests -p "test_*.py"
   ```
4. **Link to QGIS Plugins Directory**:
   Create a symlink or copy the `AriesAuto` directory into your QGIS plugins folder.

## Adding a New Index

1. Open `data/index_library.json`.
2. Add the index schema object with:
   - `id`, `short_name`, `name`, `group`
   - `formula`, `safe_formula` (with zero-division epsilon)
   - `required_bands` (using canonical identifiers: `NIR`, `RED`, `GREEN`, `BLUE`, `SWIR_1`, `SWIR_2`, etc.)
   - `recommended_style`, `default_classes`, `description`, `reference`
3. Add a test in `tests/test_calculator.py` verifying numerical accuracy.

## Code Standards
- Python 3.8+ compatibility.
- Follow PEP 8 style guidelines.
- Ensure all public functions have docstrings and type annotations.
