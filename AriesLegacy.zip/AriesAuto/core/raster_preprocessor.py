"""
AriesLegacy - Raster Preprocessor.
Handles scale factor and offset conversions, band scaling expressions, and AOI clipping.
"""

import re
from typing import Dict, Optional, Tuple, Any
from .sensor_profiles import SensorProfile


class RasterPreprocessor:
    """Provides methods to format band expressions with sensor scaling and offsets."""

    @staticmethod
    def build_scaled_band_expression(
        band_ref_name: str,
        sensor_profile: SensorProfile,
        canonical_band: str,
        apply_scaling: bool = True
    ) -> str:
        """
        Builds a safe raster calculator expression for a specific band, applying scale and offset.
        For example: ("layer@1" * 0.0001) or ("layer@1" * 0.0000275 - 0.2)
        """
        # Thermal band on Landsat (e.g. Landsat 8/9 ST_B10: LST_K = DN * 0.00341802 + 149.0)
        if canonical_band == "THERMAL" and sensor_profile.thermal_scale_factor is not None:
            if apply_scaling:
                sf = sensor_profile.thermal_scale_factor
                off = sensor_profile.thermal_offset or 0.0
                if off < 0:
                    return f"({band_ref_name} * {sf:.8g} - {abs(off):.8g})"
                elif off > 0:
                    return f"({band_ref_name} * {sf:.8g} + {off:.8g})"
                return f"({band_ref_name} * {sf:.8g})"
            return band_ref_name

        if apply_scaling and (sensor_profile.scale_factor != 1.0 or sensor_profile.offset != 0.0):
            sf = sensor_profile.scale_factor
            off = sensor_profile.offset
            if off < 0:
                return f"({band_ref_name} * {sf:.8g} - {abs(off):.8g})"
            elif off > 0:
                return f"({band_ref_name} * {sf:.8g} + {off:.8g})"
            return f"({band_ref_name} * {sf:.8g})"

        return band_ref_name

    @staticmethod
    def build_full_index_expression(
        raw_safe_formula: str,
        band_references: Dict[str, str],  # Canonical band (e.g. 'NIR') -> layer band ref (e.g. '"my_layer@8"')
        sensor_profile: SensorProfile,
        apply_scaling: bool = True
    ) -> str:
        """
        Replaces canonical bands in formula with scaled band expressions using exact token boundaries.
        """
        scaled_map = {}
        for canonical, band_ref in band_references.items():
            scaled_expr = RasterPreprocessor.build_scaled_band_expression(
                band_ref, sensor_profile, canonical, apply_scaling=apply_scaling
            )
            scaled_map[canonical] = scaled_expr

        # Replace in formula using regex word boundaries, longest canonical identifiers first
        formula = raw_safe_formula
        sorted_keys = sorted(scaled_map.keys(), key=len, reverse=True)
        for canonical in sorted_keys:
            # Match only whole word / identifier occurrences of the canonical band name
            pattern = rf"\b{re.escape(canonical)}\b"
            formula = re.sub(pattern, scaled_map[canonical], formula)

        return formula
