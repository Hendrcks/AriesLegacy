"""
AriesLegacy - Index Calculator.
Executes spatial index calculations using GDAL/NumPy block processing with QGIS fallback.
Complies strictly with the AriesAuto Formula & Algorithm Specification.
"""

import os
import math
from typing import Dict, List, Optional, Tuple, Any

from .index_library import IndexDefinition
from .sensor_profiles import SensorProfile
from .raster_preprocessor import RasterPreprocessor


def safe_divide_scalar(numerator: float, denominator: float, nodata: float = -9999.0) -> float:
    """Safely divides two scalar floats."""
    if not math.isfinite(numerator) or not math.isfinite(denominator) or denominator == 0.0:
        return nodata
    return numerator / denominator


def safe_divide_numpy(numerator: Any, denominator: Any, nodata: float = -9999.0) -> Any:
    """Safely divides two NumPy arrays returning nodata where denominator is zero or non-finite."""
    import numpy as np
    valid = np.isfinite(numerator) & np.isfinite(denominator) & (denominator != 0.0)
    out = np.full_like(numerator, fill_value=nodata, dtype=np.float32)
    np.divide(numerator, denominator, out=out, where=valid)
    return out


class IndexCalculationResult:
    """Stores results and metadata of an index calculation."""

    def __init__(self, index_def: IndexDefinition, output_path: str, success: bool = True, message: str = ""):
        self.index_def: IndexDefinition = index_def
        self.output_path: str = output_path
        self.success: bool = success
        self.message: str = message
        self.applied_formula: str = ""
        self.statistics: Dict[str, float] = {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index_id": self.index_def.id,
            "short_name": self.index_def.short_name,
            "output_path": self.output_path,
            "success": self.success,
            "message": self.message,
            "applied_formula": self.applied_formula,
            "statistics": self.statistics,
        }


class IndexCalculator:
    """Calculates spatial indices for single rasters, band collections, and raster layers."""

    @staticmethod
    def calculate_pure_numpy(
        index_def: IndexDefinition,
        band_arrays: Dict[str, Any],  # Canonical band -> 2D numpy array or scalar
        sensor_profile: SensorProfile,
        apply_scaling: bool = True,
        nodata_val: float = -9999.0
    ) -> Any:
        """
        Pure NumPy / Python calculation engine (used for direct array processing and test suite).
        Always executes in floating-point precision (Float32 / Float64).
        """
        try:
            import numpy as np
            has_np = True
        except ImportError:
            has_np = False
            np = None

        # Standardize aliases (e.g. SWIR1 -> SWIR_1)
        normalized_bands = {}
        for k, v in band_arrays.items():
            k_norm = k.upper().replace("SWIR1", "SWIR_1").replace("SWIR2", "SWIR_2")
            normalized_bands[k_norm] = v

        # Scale bands according to sensor profile
        scaled_bands = {}
        for canonical, arr in normalized_bands.items():
            if has_np and isinstance(arr, np.ndarray):
                arr_float = arr.astype(np.float64)
            elif isinstance(arr, (int, float)):
                arr_float = float(arr)
            else:
                arr_float = float(arr)

            # Thermal band scaling (Landsat ST_B10: LST_K = DN * 0.00341802 + 149.0)
            if canonical == "THERMAL" and sensor_profile.thermal_scale_factor is not None:
                if apply_scaling:
                    sf = sensor_profile.thermal_scale_factor
                    off = sensor_profile.thermal_offset or 0.0
                    scaled_bands[canonical] = arr_float * sf + off
                else:
                    scaled_bands[canonical] = arr_float
            else:
                # Optical surface reflectance scaling (e.g. Landsat C2 L2: DN * 0.0000275 - 0.2; S2: DN * 0.0001)
                if apply_scaling and (sensor_profile.scale_factor != 1.0 or sensor_profile.offset != 0.0):
                    sf = sensor_profile.scale_factor
                    off = sensor_profile.offset
                    scaled_bands[canonical] = arr_float * sf + off
                else:
                    scaled_bands[canonical] = arr_float

        # Helper divide
        def _divide(num, den):
            if has_np and (isinstance(num, np.ndarray) or isinstance(den, np.ndarray)):
                return safe_divide_numpy(num, den, nodata=nodata_val)
            return safe_divide_scalar(num, den, nodata=nodata_val)

        iid = index_def.id.lower()

        # 1. Vegetation Indices
        if iid == "ndvi":
            nir, red = scaled_bands["NIR"], scaled_bands["RED"]
            res = _divide(nir - red, nir + red)

        elif iid == "gndvi":
            nir, green = scaled_bands["NIR"], scaled_bands["GREEN"]
            res = _divide(nir - green, nir + green)

        elif iid == "evi":
            nir, red, blue = scaled_bands["NIR"], scaled_bands["RED"], scaled_bands["BLUE"]
            denom = nir + 6.0 * red - 7.5 * blue + 1.0
            res = 2.5 * _divide(nir - red, denom)

        elif iid == "savi":
            nir, red = scaled_bands["NIR"], scaled_bands["RED"]
            res = 1.5 * _divide(nir - red, nir + red + 0.5)

        elif iid in ("msavi", "msavi2"):
            nir, red = scaled_bands["NIR"], scaled_bands["RED"]
            term = (2.0 * nir + 1.0) ** 2 - 8.0 * (nir - red)
            if has_np and isinstance(term, np.ndarray):
                term = np.maximum(term, 0.0)
                res = (2.0 * nir + 1.0 - np.sqrt(term)) / 2.0
            else:
                term = max(term, 0.0)
                res = (2.0 * nir + 1.0 - math.sqrt(term)) / 2.0

        elif iid == "ndmi":
            nir, swir1 = scaled_bands["NIR"], scaled_bands["SWIR_1"]
            res = _divide(nir - swir1, nir + swir1)

        # 2. Water / Flood Indices
        elif iid == "ndwi":
            green, nir = scaled_bands["GREEN"], scaled_bands["NIR"]
            res = _divide(green - nir, green + nir)

        elif iid == "mndwi":
            green, swir1 = scaled_bands["GREEN"], scaled_bands["SWIR_1"]
            res = _divide(green - swir1, green + swir1)

        elif iid == "awei_nsh":
            green, nir, swir1, swir2 = scaled_bands["GREEN"], scaled_bands["NIR"], scaled_bands["SWIR_1"], scaled_bands["SWIR_2"]
            res = 4.0 * (green - swir1) - (0.25 * nir + 2.75 * swir2)

        elif iid == "awei_sh":
            blue, green, nir, swir1, swir2 = scaled_bands["BLUE"], scaled_bands["GREEN"], scaled_bands["NIR"], scaled_bands["SWIR_1"], scaled_bands["SWIR_2"]
            res = blue + 2.5 * green - 1.5 * (nir + swir1) - 0.25 * swir2

        # 3. Built-up / Urban / Bare Soil
        elif iid == "ndbi":
            swir1, nir = scaled_bands["SWIR_1"], scaled_bands["NIR"]
            res = _divide(swir1 - nir, swir1 + nir)

        elif iid == "ui":
            swir2, nir = scaled_bands["SWIR_2"], scaled_bands["NIR"]
            res = _divide(swir2 - nir, swir2 + nir)

        elif iid == "bsi":
            swir1, red, nir, blue = scaled_bands["SWIR_1"], scaled_bands["RED"], scaled_bands["NIR"], scaled_bands["BLUE"]
            res = _divide((swir1 + red) - (nir + blue), (swir1 + red) + (nir + blue))

        # 4. Fire / Burn Ratios
        elif iid == "nbr":
            nir, swir2 = scaled_bands["NIR"], scaled_bands["SWIR_2"]
            res = _divide(nir - swir2, nir + swir2)

        elif iid == "nbr2":
            swir1, swir2 = scaled_bands["SWIR_1"], scaled_bands["SWIR_2"]
            res = _divide(swir1 - swir2, swir1 + swir2)

        # 5. Mineral Ratios (Exploratory Spectral Proxies)
        elif iid in ("clay_ratio", "clay_index"):
            swir1, swir2 = scaled_bands["SWIR_1"], scaled_bands["SWIR_2"]
            res = _divide(swir1, swir2)

        elif iid in ("iron_oxide_ratio", "iron_oxide"):
            red, blue = scaled_bands["RED"], scaled_bands["BLUE"]
            res = _divide(red, blue)

        # 6. Thermal Surface Temperature (LST in Celsius)
        elif iid in ("lst", "lst_c"):
            thermal = scaled_bands["THERMAL"]
            res = thermal - 273.15

        else:
            raise ValueError(f"Unsupported index ID for calculator: {iid}")

        # Physical range clamping / sanitization for normalized difference indices [-1.0, 1.0]
        if has_np and isinstance(res, np.ndarray):
            if index_def.value_range and index_def.value_range == [-1.0, 1.0]:
                invalid_range = (res < -1.0) | (res > 1.0)
                res[invalid_range] = nodata_val

        return res

    @staticmethod
    def calculate_raster_layers(
        index_def: IndexDefinition,
        mapped_bands: Dict[str, Tuple[Any, int]],  # canonical -> (QgsRasterLayer, band_number)
        sensor_profile: SensorProfile,
        output_path: str,
        apply_scaling: bool = True,
        nodata_val: float = -9999.0,
        feedback: Any = None
    ) -> bool:
        """
        Executes accurate Float32 raster index calculation with full NoData masking and physical validation.
        Uses GDAL block-by-block processing when file paths are accessible, falling back to QgsRasterCalculator.
        """
        try:
            from osgeo import gdal
            import numpy as np
            has_gdal = True
        except ImportError:
            try:
                import gdal
                import numpy as np
                has_gdal = True
            except ImportError:
                has_gdal = False
                gdal = None
                np = None

        ref_layer = mapped_bands[index_def.required_bands[0]][0]

        # 1. Try GDAL chunk-based processing
        if has_gdal and hasattr(ref_layer, "source") and os.path.exists(ref_layer.source()):
            try:
                # Open all band datasets
                datasets = {}
                band_objs = {}
                nodata_values = {}

                for canonical in index_def.required_bands:
                    lyr, bnum = mapped_bands[canonical]
                    ds = gdal.Open(lyr.source(), gdal.GA_ReadOnly)
                    if not ds:
                        raise ValueError(f"GDAL could not open raster: {lyr.source()}")
                    datasets[canonical] = ds
                    band_obj = ds.GetRasterBand(bnum)
                    band_objs[canonical] = band_obj
                    nd = band_obj.GetNoDataValue()
                    nodata_values[canonical] = nd

                ref_ds = datasets[index_def.required_bands[0]]
                cols = ref_ds.RasterXSize
                rows = ref_ds.RasterYSize
                geo_transform = ref_ds.GetGeoTransform()
                projection = ref_ds.GetProjectionRef()

                # Create output GeoTIFF
                driver = gdal.GetDriverByName("GTiff")
                out_ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32, ["COMPRESS=LZW", "TILED=YES"])
                if geo_transform:
                    out_ds.SetGeoTransform(geo_transform)
                if projection:
                    out_ds.SetProjection(projection)

                out_band = out_ds.GetRasterBand(1)
                out_band.SetNoDataValue(nodata_val)

                block_size = 1024
                total_blocks = math.ceil(rows / block_size) * math.ceil(cols / block_size)
                blocks_done = 0

                for y in range(0, rows, block_size):
                    y_size = min(block_size, rows - y)
                    for x in range(0, cols, block_size):
                        x_size = min(block_size, cols - x)

                        # Read all required bands for this block
                        block_arrays = {}
                        valid_mask = np.ones((y_size, x_size), dtype=bool)

                        for canonical in index_def.required_bands:
                            b_obj = band_objs[canonical]
                            arr = b_obj.ReadAsArray(x, y, x_size, y_size).astype(np.float64)
                            nd = nodata_values[canonical]

                            # Mask standard GDAL NoData
                            if nd is not None:
                                valid_mask &= (arr != nd)
                            valid_mask &= np.isfinite(arr)

                            # Sensor-specific fill masking (e.g. Landsat / Sentinel raw integer DN <= 0 is background fill)
                            if apply_scaling and sensor_profile.id in ("landsat_8_9_c2_l2", "landsat_5_7_c2_l2", "sentinel_2_l2a"):
                                valid_mask &= (arr > 0)

                            block_arrays[canonical] = arr

                        # Calculate index on block
                        res_block = IndexCalculator.calculate_pure_numpy(
                            index_def,
                            block_arrays,
                            sensor_profile,
                            apply_scaling=apply_scaling,
                            nodata_val=nodata_val
                        )

                        # Apply valid mask
                        res_block[~valid_mask] = nodata_val

                        # Write out block
                        out_band.WriteArray(res_block.astype(np.float32), x, y)
                        blocks_done += 1
                        if feedback and total_blocks > 0:
                            feedback.setProgress(int((blocks_done / total_blocks) * 100))

                out_band.FlushCache()
                out_ds = None
                for ds in datasets.values():
                    ds = None

                return True

            except Exception as e:
                if feedback:
                    feedback.pushWarning(f"GDAL processor failed ({e}), attempting QgsRasterCalculator fallback...")

        # 2. Fallback: QgsRasterCalculator
        try:
            from qgis.analysis import QgsRasterCalculator, QgsRasterCalculatorEntry

            entries = []
            band_refs = {}
            for canonical in index_def.required_bands:
                lyr, bnum = mapped_bands[canonical]
                entry_ref = f"{canonical}_{index_def.id}@{bnum}"
                calc_entry = QgsRasterCalculatorEntry()
                calc_entry.ref = entry_ref
                calc_entry.raster = lyr
                calc_entry.bandNumber = bnum
                entries.append(calc_entry)
                band_refs[canonical] = f'"{entry_ref}"'

            expr = RasterPreprocessor.build_full_index_expression(
                index_def.safe_formula,
                band_refs,
                sensor_profile,
                apply_scaling=apply_scaling
            )

            calc = QgsRasterCalculator(
                expr,
                output_path,
                "GTiff",
                ref_layer.extent(),
                ref_layer.width(),
                ref_layer.height(),
                entries
            )
            res = calc.processCalculation(feedback) if feedback else calc.processCalculation()
            return res == 0
        except Exception as e:
            if feedback:
                feedback.reportError(f"Calculation failed: {e}")
            return False

    @staticmethod
    def build_qgis_calc_expression(
        index_def: IndexDefinition,
        band_layer_map: Dict[str, Tuple[str, int]],  # Canonical band -> (LayerName, BandNumber)
        sensor_profile: SensorProfile,
        apply_scaling: bool = True
    ) -> str:
        """
        Builds a QGIS Raster Calculator compatible expression string with proper quotes and scaling.
        """
        band_refs = {}
        for canonical, (lname, bnum) in band_layer_map.items():
            band_refs[canonical] = f'"{lname}@{bnum}"'

        return RasterPreprocessor.build_full_index_expression(
            index_def.safe_formula,
            band_refs,
            sensor_profile,
            apply_scaling=apply_scaling
        )
