"""
AriesLegacy - Official QGIS Plugin Packager.
Builds the official release ZIP file ready for upload to the official QGIS Plugin Repository (plugins.qgis.org)
Ensures ZERO __pycache__, ZERO .pyc files, and correct top-level folder 'AriesLegacy/'.
"""

import os
import zipfile
import configparser

def package():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    zip_path = os.path.join(base_dir, "AriesLegacy.zip")
    
    # Remove existing zip if present
    if os.path.exists(zip_path):
        os.remove(zip_path)
    
    # 1. Validate metadata.txt
    meta_path = os.path.join(base_dir, "metadata.txt")
    if not os.path.exists(meta_path):
        raise FileNotFoundError("metadata.txt not found!")
        
    config = configparser.ConfigParser()
    config.read(meta_path, encoding="utf-8")
    general = config["general"]
    
    plugin_name = general.get("name", "AriesLegacy").strip()
    plugin_version = general.get("version", "1.0.0").strip()
    
    print(f"Packaging {plugin_name} v{plugin_version} for QGIS Plugin Repository...")
    
    # Explicit exclusions
    exclude_dirs = {
        "__pycache__", ".git", ".github", ".pytest_cache", ".vscode", ".idea",
        "scratch", "output", ".gemini", "tests"
    }
    
    exclude_files = {
        "AriesLegacy.zip", "01-AriesAuto.zip", "package_plugin.py",
        "AriesAuto_Complete_Plugin_Plan (1).md", "AriesAuto_Formula_Algorithm_Specification.md",
        "requirements-dev.txt"
    }
    
    count = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(base_dir):
            # Exclude directory names
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith(".") and "__pycache__" not in d]
            
            for file in sorted(files):
                if file in exclude_files:
                    continue
                if file.startswith(".") or file.endswith((".pyc", ".pyo", ".zip", ".tmp", ".log", ".bak")):
                    continue
                if "__pycache__" in root:
                    continue
                    
                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, base_dir)
                
                # Top level directory inside ZIP MUST BE plugin_name (AriesLegacy)
                archive_name = os.path.join(plugin_name, rel_path).replace("\\", "/")
                
                zipf.write(abs_path, archive_name)
                count += 1
                
    # 2. Strict Verification of the created ZIP
    print(f"\n--- Verifying {zip_path} ---")
    with zipfile.ZipFile(zip_path, "r") as zipf:
        namelist = zipf.namelist()
        
        # Check root folder name
        for name in namelist:
            if not name.startswith(f"{plugin_name}/"):
                raise ValueError(f"CRITICAL ERROR: Entry '{name}' does not start with root folder '{plugin_name}/'")
            if "__pycache__" in name:
                raise ValueError(f"CRITICAL SECURITY ERROR: '__pycache__' found in entry '{name}'")
            if name.endswith((".pyc", ".pyo")):
                raise ValueError(f"CRITICAL ERROR: Bytecode file found in entry '{name}'")
                
        print(f"[OK] Total clean files packaged: {len(namelist)}")
        print(f"[OK] Top-level root directory: '{plugin_name}/'")
        print(f"[OK] Zero '__pycache__' or '.pyc' files found.")
        print(f"[OK] Ready for upload to https://plugins.qgis.org/plugins/add/\n")

if __name__ == "__main__":
    package()
