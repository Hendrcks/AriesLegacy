"""
AriesLegacy - Atmospheric Correction Processing Algorithms.
Implements the 5 algorithms defined in AL-ATM-BOOK-2.0 Section 9.2:
1. arieslegacy:inspectproduct
2. arieslegacy:toacalibration
3. arieslegacy:automaticcorrection
4. arieslegacy:advancedcorrection
5. arieslegacy:correctionquality
"""

import os
import json
from typing import Dict, Any, List, Optional

try:
    from osgeo import gdal
    HAS_GDAL = True
except ImportError:
    HAS_GDAL = False
    gdal = None

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None

try:
    from qgis.core import (
        QgsProcessing,
        QgsProcessingAlgorithm,
        QgsProcessingParameterRasterLayer,
        QgsProcessingParameterString,
        QgsProcessingParameterNumber,
        QgsProcessingParameterBoolean,
        QgsProcessingParameterEnum,
        QgsProcessingParameterFile,
        QgsProcessingParameterFileDestination,
        QgsProcessingParameterRasterDestination,
        QgsProcessingException,
        QgsRasterLayer,
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm:
        pass

try:
    from ...core.radiometric_state import RadiometricState, CorrectionStatus, ProductInspector
    from ...core.radiometry import RadiometryEngine
    from ...core.atmospheric_engine import AtmosphericEngine
    from ...core.quality_masks import QualityMaskGenerator, QualityMaskPolicy
    from ...backends.sixs import SixSAdapter, AerosolModel
except (ImportError, ValueError):
    from core.radiometric_state import RadiometricState, CorrectionStatus, ProductInspector
    from core.radiometry import RadiometryEngine
    from core.atmospheric_engine import AtmosphericEngine
    from core.quality_masks import QualityMaskGenerator, QualityMaskPolicy
    from backends.sixs import SixSAdapter, AerosolModel


# =============================================================================
# 1. Inspect Satellite Product (arieslegacy:inspectproduct)
# =============================================================================
class InspectProductAlgorithm(QgsProcessingAlgorithm):
    INPUT_PATH = "INPUT_PATH"
    OUTPUT_JSON = "OUTPUT_JSON"

    def createInstance(self):
        return InspectProductAlgorithm()

    def name(self):
        return "inspectproduct"

    def displayName(self):
        return "Inspect Satellite Product Metadata & State"

    def group(self):
        return "01 Atmospheric Correction"

    def groupId(self):
        return "atmospheric_correction"

    def shortHelpString(self):
        return (
            "Inspects satellite product containers, SAFE directories, or standalone rasters to "
            "determine sensor family, processing level (Level-1/Level-2), and physical radiometric state.\n\n"
            "Reports whether the scene is RAW_DN, TOA_REFLECTANCE, or BOA_SCALED, and extracts "
            "per-band scale factors, offsets, and solar geometry."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterString(self.INPUT_PATH, "Satellite Product Path (Directory, SAFE, or Raster)"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_JSON, "Output Metadata Manifest (JSON)", "JSON files (*.json)"))

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {}

        path = self.parameterAsString(parameters, self.INPUT_PATH, context)
        out_json = self.parameterAsFileOutput(parameters, self.OUTPUT_JSON, context)

        feedback.setProgressText(f"Inspecting satellite product at: {path}")
        info = ProductInspector.inspect_path(path)

        state_val = info["state"].value if isinstance(info["state"], RadiometricState) else str(info["state"])
        export_data = {
            "product_path": info["product_path"],
            "sensor": info["sensor"],
            "level": info["level"],
            "radiometric_state": state_val,
            "is_level2": info["is_level2"],
            "confidence": info["confidence"],
            "metadata_file": info["metadata_file"],
            "details": info["details"]
        }

        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(export_data, f, indent=2)

        feedback.setProgressText(f"Detected: {info['sensor']} ({info['level']}) — State: {state_val}")
        return {self.OUTPUT_JSON: out_json}


# =============================================================================
# 2. TOA Calibration (arieslegacy:toacalibration)
# =============================================================================
class TOACalibrationAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYER = "INPUT_LAYER"
    SENSOR_TYPE = "SENSOR_TYPE"
    SOLAR_ELEVATION = "SOLAR_ELEVATION"
    QUANTIFICATION = "QUANTIFICATION"
    ADD_OFFSET = "ADD_OFFSET"
    OUTPUT = "OUTPUT"

    def createInstance(self):
        return TOACalibrationAlgorithm()

    def name(self):
        return "toacalibration"

    def displayName(self):
        return "Calibrate Level-1 DN to TOA Reflectance"

    def group(self):
        return "01 Atmospheric Correction"

    def groupId(self):
        return "atmospheric_correction"

    def shortHelpString(self):
        return (
            "Converts raw Level-1 quantized digital numbers (DN) to calibrated Top-Of-Atmosphere (TOA) "
            "planetary reflectance [0.0 - 1.0].\n\n"
            "Supports Landsat Collection 2 L1 with sun elevation correction, and Sentinel-2 L1C with "
            "processing baseline quantification and RADIO_ADD_OFFSET handling."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_LAYER, "Input Level-1 Raster Band (DN)"))
        self.addParameter(QgsProcessingParameterEnum(self.SENSOR_TYPE, "Sensor Family", ["Sentinel-2 L1C", "Landsat C2 L1"], defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(self.SOLAR_ELEVATION, "Solar Elevation Angle (degrees, Landsat only)", QgsProcessingParameterNumber.Double, 45.0, minValue=1.0, maxValue=90.0))
        self.addParameter(QgsProcessingParameterNumber(self.QUANTIFICATION, "Quantification Value (Sentinel-2 only)", QgsProcessingParameterNumber.Double, 10000.0))
        self.addParameter(QgsProcessingParameterNumber(self.ADD_OFFSET, "Radio Add Offset (Sentinel-2 PB 04.00+)", QgsProcessingParameterNumber.Double, 0.0))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Output TOA Reflectance Raster (Float32)"))

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS or not HAS_GDAL:
            return {}

        layer = self.parameterAsRasterLayer(parameters, self.INPUT_LAYER, context)
        sensor_idx = self.parameterAsEnum(parameters, self.SENSOR_TYPE, context)
        sun_elev = self.parameterAsDouble(parameters, self.SOLAR_ELEVATION, context)
        quant = self.parameterAsDouble(parameters, self.QUANTIFICATION, context)
        add_offset = self.parameterAsDouble(parameters, self.ADD_OFFSET, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if not layer or not layer.isValid():
            raise QgsProcessingException("Invalid input raster layer.")

        src_ds = gdal.Open(layer.source(), gdal.GA_ReadOnly)
        cols, rows = src_ds.RasterXSize, src_ds.RasterYSize
        geotransform, projection = src_ds.GetGeoTransform(), src_ds.GetProjection()

        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32, options=["TILED=YES", "COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(geotransform)
        out_ds.SetProjection(projection)
        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(-9999.0)

        in_band = src_ds.GetRasterBand(1)
        block_x, block_y = in_band.GetBlockSize()
        total_blocks = (cols // block_x + 1) * (rows // block_y + 1)
        count = 0

        for y in range(0, rows, block_y):
            if feedback.isCanceled():
                break
            win_y = min(block_y, rows - y)
            for x in range(0, cols, block_x):
                if feedback.isCanceled():
                    break
                win_x = min(block_x, cols - x)

                dn = in_band.ReadAsArray(x, y, win_x, win_y)
                if sensor_idx == 0:
                    # Sentinel-2 L1C
                    toa = RadiometryEngine.sentinel2_l1c_dn_to_toa_reflectance(
                        dn=dn,
                        quantification_value=quant,
                        radio_add_offset=add_offset,
                        nodata_out=-9999.0
                    )
                else:
                    # Landsat C2 L1 (Default reflectance mult 0.00002, add -0.1)
                    toa = RadiometryEngine.landsat_l1_dn_to_toa_reflectance(
                        dn=dn,
                        mult_rho=0.00002,
                        add_rho=-0.1,
                        sun_elevation_deg=sun_elev,
                        nodata_out=-9999.0
                    )

                out_band.WriteArray(toa, x, y)
                count += 1
                feedback.setProgress(int((count / total_blocks) * 100))

        out_band.FlushCache()
        out_ds = None
        src_ds = None

        return {self.OUTPUT: output_path}


# =============================================================================
# 3. Automatic TOA-to-BOA Correction (arieslegacy:automaticcorrection)
# =============================================================================
class AutomaticCorrectionAlgorithm(QgsProcessingAlgorithm):
    INPUT_PATH = "INPUT_PATH"
    OBJECTIVE = "OBJECTIVE"
    POLICY = "POLICY"
    OUTPUT_RASTER = "OUTPUT_RASTER"
    OUTPUT_MANIFEST = "OUTPUT_MANIFEST"

    def createInstance(self):
        return AutomaticCorrectionAlgorithm()

    def name(self):
        return "automaticcorrection"

    def displayName(self):
        return "Automatic TOA-to-BOA Atmospheric Correction (Mode A)"

    def group(self):
        return "01 Atmospheric Correction"

    def groupId(self):
        return "atmospheric_correction"

    def shortHelpString(self):
        return (
            "Mode A — Automatic Atmospheric Correction:\n\n"
            "1. Inspects product metadata to detect Level-1 or Level-2 state.\n"
            "2. If already Level-2 BOA (Landsat C2 L2 or Sentinel-2 L2A), decodes physical reflectance "
            "and strictly bypasses atmospheric correction to prevent duplicate processing.\n"
            "3. If Level-1, checks for verified installed processors (Sen2Cor for Sentinel-2, official USGS L2).\n"
            "4. If processor is missing, falls back safely to calibrated TOA reflectance with explicit warning."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterString(self.INPUT_PATH, "Satellite Product Path (Directory, SAFE, or Raster)"))
        self.addParameter(QgsProcessingParameterEnum(self.OBJECTIVE, "Correction Objective", ["BOA If Possible", "TOA Only"], defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(self.POLICY, "Quality Mask Policy", ["Standard", "Conservative", "Relaxed"], defaultValue=0))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_RASTER, "Output Calibrated Raster (Float32)"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_MANIFEST, "Processing Provenance Manifest (JSON)", "JSON files (*.json)"))

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {}

        path = self.parameterAsString(parameters, self.INPUT_PATH, context)
        obj_idx = self.parameterAsEnum(parameters, self.OBJECTIVE, context)
        pol_idx = self.parameterAsEnum(parameters, self.POLICY, context)
        out_raster = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)
        out_manifest = self.parameterAsFileOutput(parameters, self.OUTPUT_MANIFEST, context)

        requested_prod = "BOA_IF_POSSIBLE" if obj_idx == 0 else "TOA_ONLY"
        policy_map = ["standard", "conservative", "relaxed"]
        chosen_policy = policy_map[pol_idx]

        engine = AtmosphericEngine()
        feedback.setProgressText("Running Mode A Automatic Atmospheric Correction...")
        result = engine.run_automatic(
            product_path=path,
            requested_product=requested_prod,
            quality_policy=chosen_policy,
            feedback=feedback
        )

        manifest = result.get("manifest", {})
        status_val = result["status"].value if isinstance(result["status"], CorrectionStatus) else str(result["status"])
        manifest["final_status"] = status_val

        # If a single raster was provided, process and write to destination
        if os.path.isfile(path) and HAS_GDAL:
            src_ds = gdal.Open(path, gdal.GA_ReadOnly)
            if src_ds:
                cols, rows = src_ds.RasterXSize, src_ds.RasterYSize
                geotransform, projection = src_ds.GetGeoTransform(), src_ds.GetProjection()

                driver = gdal.GetDriverByName("GTiff")
                out_ds = driver.Create(out_raster, cols, rows, 1, gdal.GDT_Float32, options=["TILED=YES", "COMPRESS=DEFLATE"])
                out_ds.SetGeoTransform(geotransform)
                out_ds.SetProjection(projection)
                out_band = out_ds.GetRasterBand(1)
                out_band.SetNoDataValue(-9999.0)

                in_band = src_ds.GetRasterBand(1)
                arr = in_band.ReadAsArray()

                if result["action"] == "DECODE_L2_SCALE_ONLY":
                    # Landsat C2 L2 decoding
                    scaled = RadiometryEngine.landsat_c2_l2_dn_to_surface_reflectance(arr, nodata_out=-9999.0)
                else:
                    scaled = arr.astype(np.float32)

                out_band.WriteArray(scaled)
                out_band.FlushCache()
                out_ds = None
                src_ds = None

        with open(out_manifest, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

        feedback.setProgressText(f"Automatic Mode Completed: {status_val}")
        return {self.OUTPUT_RASTER: out_raster, self.OUTPUT_MANIFEST: out_manifest}


# =============================================================================
# 4. Advanced 6S Physical Atmospheric Correction (arieslegacy:advancedcorrection)
# =============================================================================
class AdvancedCorrectionAlgorithm(QgsProcessingAlgorithm):
    INPUT_TOA = "INPUT_TOA"
    WAVELENGTH = "WAVELENGTH"
    SOLAR_ZENITH = "SOLAR_ZENITH"
    AOT550 = "AOT550"
    AEROSOL_MODEL = "AEROSOL_MODEL"
    WATER_VAPOUR = "WATER_VAPOUR"
    OZONE = "OZONE"
    ELEVATION = "ELEVATION"
    USE_DOS = "USE_DOS"
    OUTPUT_BOA = "OUTPUT_BOA"
    OUTPUT_MANIFEST = "OUTPUT_MANIFEST"

    def createInstance(self):
        return AdvancedCorrectionAlgorithm()

    def name(self):
        return "advancedcorrection"

    def displayName(self):
        return "Advanced 6S Physical Atmospheric Correction (Mode B)"

    def group(self):
        return "01 Atmospheric Correction"

    def groupId(self):
        return "atmospheric_correction"

    def shortHelpString(self):
        return (
            "Mode B — Advanced Atmospheric Correction:\n\n"
            "Applies a validated 6S physical radiative transfer model parameterized by:\n"
            "- Solar zenith angle (SZA)\n"
            "- Aerosol optical depth (AOT550) and aerosol model\n"
            "- Atmospheric gases: Water vapour (g/cm²) and Ozone (DU)\n"
            "- Surface elevation / pressure\n\n"
            "Inverts TOA reflectance to physical BOA surface reflectance:\n"
            "y = rho_TOA - rho_path\n"
            "rho_BOA = y / (T_eff + S * y)\n\n"
            "Optionally applies exploratory Dark Object Subtraction (DOS_APPROXIMATION)."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_TOA, "Input Calibrated TOA Reflectance Band"))
        self.addParameter(QgsProcessingParameterNumber(self.WAVELENGTH, "Center Wavelength (micrometers, e.g. 0.66 for Red)", QgsProcessingParameterNumber.Double, 0.66, minValue=0.4, maxValue=2.5))
        self.addParameter(QgsProcessingParameterNumber(self.SOLAR_ZENITH, "Solar Zenith Angle (degrees)", QgsProcessingParameterNumber.Double, 35.0, minValue=0.0, maxValue=85.0))
        self.addParameter(QgsProcessingParameterNumber(self.AOT550, "Aerosol Optical Thickness at 550nm (AOT550)", QgsProcessingParameterNumber.Double, 0.15, minValue=0.0, maxValue=2.0))
        self.addParameter(QgsProcessingParameterEnum(self.AEROSOL_MODEL, "Aerosol Model", ["Continental", "Maritime", "Urban", "Desert", "Biomass Burning"], defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(self.WATER_VAPOUR, "Total Column Water Vapour (g/cm²)", QgsProcessingParameterNumber.Double, 1.5, minValue=0.0, maxValue=8.0))
        self.addParameter(QgsProcessingParameterNumber(self.OZONE, "Total Column Ozone (Dobson Units)", QgsProcessingParameterNumber.Double, 300.0, minValue=100.0, maxValue=600.0))
        self.addParameter(QgsProcessingParameterNumber(self.ELEVATION, "Target Elevation (meters)", QgsProcessingParameterNumber.Double, 0.0))
        self.addParameter(QgsProcessingParameterBoolean(self.USE_DOS, "Run Exploratory Dark Object Subtraction (DOS) instead", defaultValue=False))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_BOA, "Output Physical BOA Surface Reflectance Raster"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_MANIFEST, "Physical Coefficient Manifest (JSON)", "JSON files (*.json)"))

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS or not HAS_GDAL:
            return {}

        layer = self.parameterAsRasterLayer(parameters, self.INPUT_TOA, context)
        wl = self.parameterAsDouble(parameters, self.WAVELENGTH, context)
        sza = self.parameterAsDouble(parameters, self.SOLAR_ZENITH, context)
        aot = self.parameterAsDouble(parameters, self.AOT550, context)
        aer_idx = self.parameterAsEnum(parameters, self.AEROSOL_MODEL, context)
        wv = self.parameterAsDouble(parameters, self.WATER_VAPOUR, context)
        o3 = self.parameterAsDouble(parameters, self.OZONE, context)
        elev = self.parameterAsDouble(parameters, self.ELEVATION, context)
        use_dos = self.parameterAsBoolean(parameters, self.USE_DOS, context)
        out_boa = self.parameterAsOutputLayer(parameters, self.OUTPUT_BOA, context)
        out_manifest = self.parameterAsFileOutput(parameters, self.OUTPUT_MANIFEST, context)

        aer_models = ["Continental", "Maritime", "Urban", "Desert", "Biomass Burning"]
        chosen_aer = aer_models[aer_idx]

        src_ds = gdal.Open(layer.source(), gdal.GA_ReadOnly)
        cols, rows = src_ds.RasterXSize, src_ds.RasterYSize
        geotransform, projection = src_ds.GetGeoTransform(), src_ds.GetProjection()

        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(out_boa, cols, rows, 1, gdal.GDT_Float32, options=["TILED=YES", "COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(geotransform)
        out_ds.SetProjection(projection)
        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(-9999.0)

        in_band = src_ds.GetRasterBand(1)
        arr = in_band.ReadAsArray()

        if use_dos:
            feedback.setProgressText("Applying Exploratory Dark Object Subtraction (DOS)...")
            dos_res = AtmosphericEngine.calculate_dos_approximation(arr, nodata=-9999.0)
            corrected = dos_res["corrected"]
            manifest = {
                "method": "Exploratory Dark Object Subtraction (DOS)",
                "status": "DOS_APPROXIMATION",
                "path_estimate": dos_res["path_estimate"],
                "notice": "Exploratory approximation only; not a validated physical radiative transfer retrieval."
            }
        else:
            feedback.setProgressText(f"Computing 6S coefficients for lambda={wl:.2f} um, SZA={sza:.1f} deg...")
            coeffs = SixSAdapter.calculate_band_coefficients(
                wavelength_um=wl,
                solar_zenith_deg=sza,
                aot550=aot,
                aerosol_model=chosen_aer,
                water_vapour_g_cm2=wv,
                ozone_du=o3,
                elevation_m=elev
            )

            feedback.setProgressText("Inverting TOA reflectance to BOA surface reflectance in blocks...")
            corrected = SixSAdapter.invert_lambertian_toa_to_boa(
                rho_toa=arr,
                rho_path=coeffs["rho_path"],
                t_eff=coeffs["T_eff"],
                s_albedo=coeffs["S"],
                nodata=-9999.0
            )

            manifest = {
                "method": "6S Physical Radiative Transfer Inversion",
                "status": "BOA_CORRECTED_VERIFIED",
                "wavelength_um": wl,
                "geometry": {"SZA": sza},
                "atmosphere": {
                    "AOT550": aot,
                    "aerosol_model": chosen_aer,
                    "water_vapour_g_cm2": wv,
                    "ozone_du": o3,
                    "elevation_m": elev
                },
                "coefficients": coeffs
            }

        out_band.WriteArray(corrected)
        out_band.FlushCache()
        out_ds = None
        src_ds = None

        with open(out_manifest, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

        feedback.setProgressText("Advanced Atmospheric Correction Completed.")
        return {self.OUTPUT_BOA: out_boa, self.OUTPUT_MANIFEST: out_manifest}


# =============================================================================
# 5. Compare TOA and BOA Quality (arieslegacy:correctionquality)
# =============================================================================
class CorrectionQualityAlgorithm(QgsProcessingAlgorithm):
    INPUT_BOA = "INPUT_BOA"
    INPUT_REF = "INPUT_REF"
    OUTPUT_REPORT = "OUTPUT_REPORT"

    def createInstance(self):
        return CorrectionQualityAlgorithm()

    def name(self):
        return "correctionquality"

    def displayName(self):
        return "Compare TOA and BOA Reflectance Quality"

    def group(self):
        return "01 Atmospheric Correction"

    def groupId(self):
        return "atmospheric_correction"

    def shortHelpString(self):
        return (
            "Compares retrieved BOA surface reflectance against an authoritative Level-2 reference raster "
            "or against initial TOA reflectance.\n\n"
            "Calculates statistical metrics across valid pixels:\n"
            "- Bias (Mean Error)\n"
            "- Mean Absolute Error (MAE)\n"
            "- Root Mean Square Error (RMSE)\n"
            "- Pearson Correlation Coefficient (r)\n"
            "- Valid pixel count and out-of-bounds fraction (negative / >1.0)."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_BOA, "Retrieved BOA Reflectance Layer"))
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_REF, "Reference Surface Reflectance (or TOA) Layer"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_REPORT, "Output Comparison Report (JSON)", "JSON files (*.json)"))

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS or not HAS_GDAL:
            return {}

        boa_layer = self.parameterAsRasterLayer(parameters, self.INPUT_BOA, context)
        ref_layer = self.parameterAsRasterLayer(parameters, self.INPUT_REF, context)
        out_report = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        if not boa_layer or not ref_layer:
            raise QgsProcessingException("Invalid input layers.")

        boa_ds = gdal.Open(boa_layer.source(), gdal.GA_ReadOnly)
        ref_ds = gdal.Open(ref_layer.source(), gdal.GA_ReadOnly)

        boa_arr = boa_ds.GetRasterBand(1).ReadAsArray()
        ref_arr = ref_ds.GetRasterBand(1).ReadAsArray()

        feedback.setProgressText("Computing statistical comparison metrics...")
        metrics = AtmosphericEngine.compare_with_reference(boa_arr, ref_arr, nodata=-9999.0)

        # Compute physical validity statistics for BOA
        valid_boa = (boa_arr != -9999.0) & np.isfinite(boa_arr)
        total_valid = int(np.sum(valid_boa))
        neg_count = int(np.sum(valid_boa & (boa_arr < 0.0)))
        high_count = int(np.sum(valid_boa & (boa_arr > 1.0)))

        report = {
            "comparison_metrics": metrics,
            "physical_diagnostics": {
                "total_valid_pixels": total_valid,
                "negative_reflectance_pixels": neg_count,
                "negative_percent": round(neg_count / total_valid * 100.0, 3) if total_valid > 0 else 0.0,
                "above_one_pixels": high_count,
                "above_one_percent": round(high_count / total_valid * 100.0, 3) if total_valid > 0 else 0.0
            }
        }

        boa_ds = None
        ref_ds = None

        with open(out_report, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)

        feedback.setProgressText(f"Quality Metrics: RMSE={metrics['rmse']}, Bias={metrics['bias']}, Pearson r={metrics['r']}")
        return {self.OUTPUT_REPORT: out_report}
