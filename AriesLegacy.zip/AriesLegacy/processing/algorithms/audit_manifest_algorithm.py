"""
AriesLegacy - Audit Manifest Processing Algorithm.
Generates an immutable scientific JSON run manifest (QA-008) tracking inputs,
cryptographic SHA256 hashes, formulas, calibration constants, and processing environment.
"""

import os
from typing import Dict, Any

try:
    from qgis.core import (
        QgsProcessing,
        QgsProcessingAlgorithm,
        QgsProcessingParameterMultipleLayers,
        QgsProcessingParameterString,
        QgsProcessingParameterFileDestination,
        QgsProcessingException,
        QgsRasterLayer,
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm:
        pass

from ...core.provenance import AuditManifest


class GenerateAuditManifestAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYERS = "INPUT_LAYERS"
    OPERATION_NAME = "OPERATION_NAME"
    NOTES = "NOTES"
    OUTPUT = "OUTPUT"

    def createInstance(self):
        return GenerateAuditManifestAlgorithm()

    def name(self):
        return "generate_audit_manifest"

    def displayName(self):
        return "Generate Scientific Audit Manifest (JSON)"

    def group(self):
        return "08 Statistics & QA"

    def groupId(self):
        return "statistics_qa"

    def shortHelpString(self):
        return (
            "Creates an immutable JSON run manifest documenting input scenes, file paths, "
            "SHA256 checksums, calibration factors, parameters, and reproducibility metadata."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterMultipleLayers(self.INPUT_LAYERS, "Input Scene/Band Rasters", layerType=QgsProcessing.TypeRaster))
        self.addParameter(QgsProcessingParameterString(self.OPERATION_NAME, "Processing Chain Operation Name", defaultValue="Spectral Analysis Pipeline"))
        self.addParameter(QgsProcessingParameterString(self.NOTES, "Analyst Notes & Environmental Context", defaultValue="", optional=True))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT, "Audit Manifest Output (*.json)", fileFilter="JSON files (*.json)"))

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {}

        layers = self.parameterAsLayerList(parameters, self.INPUT_LAYERS, context)
        op_name = self.parameterAsString(parameters, self.OPERATION_NAME, context)
        notes = self.parameterAsString(parameters, self.NOTES, context)
        output_path = self.parameterAsFileOutput(parameters, self.OUTPUT, context)

        inputs_map = {}
        for lyr in layers:
            inputs_map[lyr.name()] = lyr.source()

        manifest = AuditManifest.create_run_manifest(
            operation_id="pipeline_run",
            operation_name=op_name,
            input_files=inputs_map,
            parameters={"total_layers": len(layers)},
            output_files={"manifest": output_path},
            notes=notes
        )

        AuditManifest.save_manifest_json(manifest, output_path)
        return {self.OUTPUT: output_path}

