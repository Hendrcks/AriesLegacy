"""
AriesLegacy - Custom Index Calculation Algorithm.
Evaluates user-defined mathematical expressions safely using Python AST without eval().
"""

import os
from typing import Dict, Any, List

try:
    from qgis.core import (
        QgsProcessing,
        QgsProcessingAlgorithm,
        QgsProcessingParameterMultipleLayers,
        QgsProcessingParameterString,
        QgsProcessingParameterRasterDestination,
        QgsProcessingException,
        QgsRasterLayer,
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm:
        pass

from ...core.formula_parser import SafeFormulaParser, FormulaSecurityError
from ...core.index_calculator import safe_divide_numpy


class CustomIndexAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYERS = "INPUT_LAYERS"
    FORMULA = "FORMULA"
    OUTPUT = "OUTPUT"

    def createInstance(self):
        return CustomIndexAlgorithm()

    def name(self):
        return "calculate_custom_index"

    def displayName(self):
        return "Calculate Custom Spatial Index (Safe AST)"

    def group(self):
        return "04 Spectral Indices"

    def groupId(self):
        return "spectral_indices"

    def shortHelpString(self):
        return (
            "Calculates a user-defined custom formula using restricted AST evaluation.\n\n"
            "Supported functions: sqrt, abs, min, max, log, exp, sin, cos, safe_divide.\n"
            "Band variables (e.g. NIR, RED, GREEN, SWIR1) are bound to the selected input layers.\n"
            "Security: No Python eval() is ever used."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_LAYERS, "Input Band Rasters", layerType=QgsProcessing.TypeRaster
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.FORMULA, "Formula Expression (e.g. (NIR - RED) / (NIR + RED))", defaultValue="(NIR - RED) / (NIR + RED)"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(self.OUTPUT, "Calculated Index Output (Float32)")
        )

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {}
        try:
            from osgeo import gdal
            import numpy as np
        except ImportError:
            raise QgsProcessingException("GDAL with NumPy is required for raster processing.")

        layers = self.parameterAsLayerList(parameters, self.INPUT_LAYERS, context)
        formula = self.parameterAsString(parameters, self.FORMULA, context).strip()
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if not layers:
            raise QgsProcessingException("At least one input raster layer must be provided.")

        try:
            SafeFormulaParser.validate_expression(formula)
            req_vars = SafeFormulaParser.extract_variables(formula)
        except FormulaSecurityError as e:
            raise QgsProcessingException(f"Formula validation rejected: {e}")

        # Bind layers to required variables by name or order
        var_to_layer = {}
        for var in req_vars:
            matched = None
            v_upper = var.upper()
            for lyr in layers:
                if v_upper in lyr.name().upper() or v_upper in lyr.source().upper():
                    matched = lyr
                    break
            if not matched and len(layers) >= len(req_vars):
                # Fallback to index position
                idx = req_vars.index(var)
                matched = layers[idx]
            if not matched:
                raise QgsProcessingException(f"Could not bind formula variable '{var}' to any input layer.")
            var_to_layer[var] = matched

        ref_ds = gdal.Open(layers[0].source(), gdal.GA_ReadOnly)
        cols, rows = ref_ds.RasterXSize, ref_ds.RasterYSize
        geotransform, projection = ref_ds.GetGeoTransform(), ref_ds.GetProjection()

        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32, options=["TILED=YES", "COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(geotransform)
        out_ds.SetProjection(projection)
        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(-9999.0)

        ds_map = {var_name: gdal.Open(var_layer.source(), gdal.GA_ReadOnly) for var_name, var_layer in var_to_layer.items()}
        block_x, block_y = out_band.GetBlockSize()
        total_blocks = (cols // block_x + 1) * (rows // block_y + 1)
        count = 0

        for y in range(0, rows, block_y):
            if feedback.isCanceled(): break
            win_y = min(block_y, rows - y)
            for x in range(0, cols, block_x):
                if feedback.isCanceled(): break
                win_x = min(block_x, cols - x)

                chunk_vars = {}
                for v, ds in ds_map.items():
                    chunk_vars[v] = ds.GetRasterBand(1).ReadAsArray(x, y, win_x, win_y).astype(np.float64)

                res = SafeFormulaParser.evaluate(formula, chunk_vars, nodata_val=-9999.0)
                out_band.WriteArray(res.astype(np.float32), x, y)
                count += 1
                feedback.setProgress(int((count / total_blocks) * 100))

        out_band.FlushCache()
        out_ds = None
        for ds in ds_map.values(): ds = None
        ref_ds = None

        return {self.OUTPUT: output_path}

