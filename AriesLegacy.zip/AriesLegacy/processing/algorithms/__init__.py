"""
AriesLegacy Processing Algorithms Package.
"""

from .index_calculation_algorithm import IndexCalculationAlgorithm
from .batch_indices_algorithm import BatchIndicesAlgorithm
from .change_detection_algorithm import ChangeDetectionAlgorithm
from .classification_stats_algorithm import ClassificationStatsAlgorithm
from .preprocessing_algorithms import LandsatL2SRDecodeAlgorithm, Sentinel2L2ASRDecodeAlgorithm
from .custom_index_algorithm import CustomIndexAlgorithm
from .timeseries_algorithms import OLSTrendAlgorithm, TemporalCompositeAlgorithm
from .dnbr_change_algorithm import DNBRChangeAlgorithm
from .advanced_classification_algorithm import OtsuThresholdAlgorithm
from .audit_manifest_algorithm import GenerateAuditManifestAlgorithm
from .atmospheric_algorithms import (
    InspectProductAlgorithm,
    TOACalibrationAlgorithm,
    AutomaticCorrectionAlgorithm,
    AdvancedCorrectionAlgorithm,
    CorrectionQualityAlgorithm,
)

__all__ = [
    "IndexCalculationAlgorithm",
    "BatchIndicesAlgorithm",
    "ChangeDetectionAlgorithm",
    "ClassificationStatsAlgorithm",
    "LandsatL2SRDecodeAlgorithm",
    "Sentinel2L2ASRDecodeAlgorithm",
    "CustomIndexAlgorithm",
    "OLSTrendAlgorithm",
    "TemporalCompositeAlgorithm",
    "DNBRChangeAlgorithm",
    "OtsuThresholdAlgorithm",
    "GenerateAuditManifestAlgorithm",
    "InspectProductAlgorithm",
    "TOACalibrationAlgorithm",
    "AutomaticCorrectionAlgorithm",
    "AdvancedCorrectionAlgorithm",
    "CorrectionQualityAlgorithm",
]
