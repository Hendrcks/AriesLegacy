"""
AriesLegacy - Burn Severity and dNBR Change Detection Algorithms.
Strictly implements Key & Benson (2006) dNBR (Pre - Post), RdNBR, and RBR.
"""

import os
from typing import Dict, Any

try:
    from qgis.core import (
        QgsProcessing,
        QgsProcessingAlgorithm,
        QgsProcessingParameterRasterLayer,
        QgsProcessingParameterEnum,
        QgsProcessingParameterRasterDestination,
        QgsProcessingException,
        QgsRasterLayer,
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm:
        pass

from ...core.change_detection import ChangeDetector


class DNBRChangeAlgorithm(QgsProcessingAlgorithm):
    PRE_NBR = "PRE_NBR"
    POST_NBR = "POST_NBR"
    METRIC = "METRIC"
    OUTPUT = "OUTPUT"

    def createInstance(self):
        return DNBRChangeAlgorithm()

    def name(self):
        return "dnbr_burn_severity"

    def displayName(self):
        return "Burn Severity Change (dNBR / RdNBR / RBR)"

    def group(self):
        return "06 Change Detection"

    def groupId(self):
        return "change_detection"

    def shortHelpString(self):
        return (
            "Calculates post-wildfire burn severity metrics:\n\n"
            "- dNBR = NBR_pre - NBR_post (Key & Benson 2006)\n"
            "- RdNBR = dNBR / sqrt(|NBR_pre|) (Miller & Thode 2007)\n"
            "- RBR = dNBR / (NBR_pre + 1.001) (Parks et al. 2014)\n\n"
            "Pre and Post dates are enforced strictly to ensure the correct sign of disturbance."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterRasterLayer(self.PRE_NBR, "Pre-Fire NBR Raster"))
        self.addParameter(QgsProcessingParameterRasterLayer(self.POST_NBR, "Post-Fire NBR Raster"))
        self.addParameter(
            QgsProcessingParameterEnum(
                self.METRIC, "Burn Metric", options=["Absolute dNBR (Pre - Post)", "Relative dNBR (RdNBR)", "Relativized Burn Ratio (RBR)"], defaultValue=0
            )
        )
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Burn Severity Raster (Float32)"))

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {}
        try:
            from osgeo import gdal
            import numpy as np
        except ImportError:
            raise QgsProcessingException("GDAL with NumPy is required for burn severity calculation.")

        pre_layer = self.parameterAsRasterLayer(parameters, self.PRE_NBR, context)
        post_layer = self.parameterAsRasterLayer(parameters, self.POST_NBR, context)
        metric_idx = self.parameterAsEnum(parameters, self.METRIC, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if not pre_layer or not post_layer:
            raise QgsProcessingException("Both Pre and Post NBR layers must be specified.")

        pre_ds = gdal.Open(pre_layer.source(), gdal.GA_ReadOnly)
        post_ds = gdal.Open(post_layer.source(), gdal.GA_ReadOnly)

        cols, rows = pre_ds.RasterXSize, pre_ds.RasterYSize
        geotransform, projection = pre_ds.GetGeoTransform(), pre_ds.GetProjection()

        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32, options=["TILED=YES", "COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(geotransform)
        out_ds.SetProjection(projection)
        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(-9999.0)

        block_x, block_y = out_band.GetBlockSize()
        total_blocks = (cols // block_x + 1) * (rows // block_y + 1)
        count = 0

        for y in range(0, rows, block_y):
            if feedback.isCanceled(): break
            win_y = min(block_y, rows - y)
            for x in range(0, cols, block_x):
                if feedback.isCanceled(): break
                win_x = min(block_x, cols - x)

                pre_arr = pre_ds.GetRasterBand(1).ReadAsArray(x, y, win_x, win_y)
                post_arr = post_ds.GetRasterBand(1).ReadAsArray(x, y, win_x, win_y)

                if metric_idx == 0:
                    res = ChangeDetector.calculate_dnbr(pre_arr, post_arr, nodata=-9999.0)
                elif metric_idx == 1:
                    res = ChangeDetector.calculate_rdnbr(pre_arr, post_arr, nodata=-9999.0)
                else:
                    res = ChangeDetector.calculate_rbr(pre_arr, post_arr, nodata=-9999.0)

                out_band.WriteArray(res, x, y)
                count += 1
                feedback.setProgress(int((count / total_blocks) * 100))

        out_band.FlushCache()
        out_ds, pre_ds, post_ds = None, None, None
        return {self.OUTPUT: output_path}

