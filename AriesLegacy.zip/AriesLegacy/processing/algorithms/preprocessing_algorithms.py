"""
AriesLegacy - Preprocessing Processing Algorithms.
Implements QGIS Processing algorithms for radiometric calibration, TOA conversion,
and Level-2 Surface Reflectance decoding.
"""

import os
from typing import Dict, Any, List, Optional

try:
    from qgis.core import (
        QgsProcessing,
        QgsProcessingAlgorithm,
        QgsProcessingParameterRasterLayer,
        QgsProcessingParameterNumber,
        QgsProcessingParameterBoolean,
        QgsProcessingParameterRasterDestination,
        QgsProcessingException,
        QgsRasterLayer,
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm:
        pass

from ...core.radiometry import RadiometryEngine


class LandsatL2SRDecodeAlgorithm(QgsProcessingAlgorithm):
    INPUT = "INPUT"
    OUTPUT = "OUTPUT"

    def createInstance(self):
        return LandsatL2SRDecodeAlgorithm()

    def name(self):
        return "landsat_l2_sr_decode"

    def displayName(self):
        return "Landsat Collection 2 Level-2 SR Decode"

    def group(self):
        return "02 Radiometric Preprocessing"

    def groupId(self):
        return "radiometric_preprocessing"

    def shortHelpString(self):
        return (
            "Decodes USGS Landsat Collection 2 Level-2 Surface Reflectance integer DNs to "
            "calibrated physical float surface reflectance using the standard equation:\n\n"
            "SR = (DN * 0.0000275) - 0.2\n\n"
            "Fill DN=0 is preserved as NoData. This operation must not be repeated on already scaled data."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, "Input Landsat C2 L2 SR Band (DN)"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Decoded Surface Reflectance (Float32)"))

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {}
        try:
            from osgeo import gdal
            import numpy as np
        except ImportError:
            raise QgsProcessingException("GDAL with NumPy is required for raster processing.")

        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if not input_layer or not os.path.exists(input_layer.source()):
            raise QgsProcessingException("Invalid input raster layer source.")

        src_ds = gdal.Open(input_layer.source(), gdal.GA_ReadOnly)
        if not src_ds:
            raise QgsProcessingException("Could not open input raster with GDAL.")

        cols = src_ds.RasterXSize
        rows = src_ds.RasterYSize
        geotransform = src_ds.GetGeoTransform()
        projection = src_ds.GetProjection()

        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(
            output_path, cols, rows, 1, gdal.GDT_Float32,
            options=["TILED=YES", "COMPRESS=DEFLATE", "PREDICTOR=2", "BIGTIFF=IF_SAFER"]
        )
        out_ds.SetGeoTransform(geotransform)
        out_ds.SetProjection(projection)
        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(-9999.0)

        in_band = src_ds.GetRasterBand(1)
        block_x, block_y = out_band.GetBlockSize()
        total_blocks = (cols // block_x + 1) * (rows // block_y + 1)
        count = 0

        for y in range(0, rows, block_y):
            if feedback.isCanceled():
                break
            win_y = min(block_y, rows - y)
            for x in range(0, cols, block_x):
                if feedback.isCanceled():
                    break
                win_x = min(block_x, cols - x)
                arr = in_band.ReadAsArray(x, y, win_x, win_y)
                decoded = RadiometryEngine.landsat_c2_l2_sr_decode(arr)
                out_band.WriteArray(decoded, x, y)
                count += 1
                feedback.setProgress(int((count / total_blocks) * 100))

        out_band.FlushCache()
        out_ds = None
        src_ds = None
        return {self.OUTPUT: output_path}


class Sentinel2L2ASRDecodeAlgorithm(QgsProcessingAlgorithm):
    INPUT = "INPUT"
    BOA_OFFSET = "BOA_OFFSET"
    QUANTIFICATION = "QUANTIFICATION"
    OUTPUT = "OUTPUT"

    def createInstance(self):
        return Sentinel2L2ASRDecodeAlgorithm()

    def name(self):
        return "sentinel2_l2a_sr_decode"

    def displayName(self):
        return "Sentinel-2 Level-2A SR Decode"

    def group(self):
        return "02 Radiometric Preprocessing"

    def groupId(self):
        return "radiometric_preprocessing"

    def shortHelpString(self):
        return (
            "Decodes Copernicus Sentinel-2 Level-2A Surface Reflectance integers into calibrated float SR:\n\n"
            "SR = (DN + BOA_ADD_OFFSET) / QUANTIFICATION_VALUE\n\n"
            "Supports processing baseline 04.00+ negative offsets (-1000) or pre-04.00 zero offset."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, "Input Sentinel-2 L2A Band (DN)"))
        self.addParameter(QgsProcessingParameterNumber(self.BOA_OFFSET, "BOA Add Offset (e.g. 0.0 or -1000.0)", type=QgsProcessingParameterNumber.Double, defaultValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(self.QUANTIFICATION, "Quantification Value (default 10000)", type=QgsProcessingParameterNumber.Double, defaultValue=10000.0))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Decoded Surface Reflectance (Float32)"))

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {}
        try:
            from osgeo import gdal
            import numpy as np
        except ImportError:
            raise QgsProcessingException("GDAL with NumPy is required for raster processing.")

        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        boa_offset = self.parameterAsDouble(parameters, self.BOA_OFFSET, context)
        quant = self.parameterAsDouble(parameters, self.QUANTIFICATION, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if not input_layer or not os.path.exists(input_layer.source()):
            raise QgsProcessingException("Invalid input raster layer source.")

        src_ds = gdal.Open(input_layer.source(), gdal.GA_ReadOnly)
        cols, rows = src_ds.RasterXSize, src_ds.RasterYSize
        geotransform, projection = src_ds.GetGeoTransform(), src_ds.GetProjection()

        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32, options=["TILED=YES", "COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(geotransform)
        out_ds.SetProjection(projection)
        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(-9999.0)

        in_band = src_ds.GetRasterBand(1)
        block_x, block_y = out_band.GetBlockSize()
        total_blocks = (cols // block_x + 1) * (rows // block_y + 1)
        count = 0

        for y in range(0, rows, block_y):
            if feedback.isCanceled(): break
            win_y = min(block_y, rows - y)
            for x in range(0, cols, block_x):
                if feedback.isCanceled(): break
                win_x = min(block_x, cols - x)
                arr = in_band.ReadAsArray(x, y, win_x, win_y)
                decoded = RadiometryEngine.sentinel2_l2a_sr_decode(arr, boa_add_offset=boa_offset, quantification_value=quant)
                out_band.WriteArray(decoded, x, y)
                count += 1
                feedback.setProgress(int((count / total_blocks) * 100))

        out_band.FlushCache()
        out_ds, src_ds = None, None
        return {self.OUTPUT: output_path}

