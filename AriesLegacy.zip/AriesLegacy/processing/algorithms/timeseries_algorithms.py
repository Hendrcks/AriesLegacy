"""
AriesLegacy - Time-Series Processing Algorithms.
Implements OLS Linear Slope, Sen's Slope, and Temporal Compositing algorithms.
"""

import os
from typing import Dict, Any, List

try:
    from qgis.core import (
        QgsProcessing,
        QgsProcessingAlgorithm,
        QgsProcessingParameterMultipleLayers,
        QgsProcessingParameterEnum,
        QgsProcessingParameterRasterDestination,
        QgsProcessingException,
        QgsRasterLayer,
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm:
        pass

from ...core.timeseries_engine import TimeSeriesEngine


class OLSTrendAlgorithm(QgsProcessingAlgorithm):
    INPUT_SERIES = "INPUT_SERIES"
    OUTPUT = "OUTPUT"

    def createInstance(self):
        return OLSTrendAlgorithm()

    def name(self):
        return "ols_trend"

    def displayName(self):
        return "OLS Linear Trend Slope (Time-Series)"

    def group(self):
        return "07 Multitemporal & Trends"

    def groupId(self):
        return "multitemporal_trends"

    def shortHelpString(self):
        return (
            "Computes Ordinary Least Squares (OLS) linear trend slope (beta) across an ordered time-series of index rasters.\n\n"
            "beta = sum((t - t_bar)*(I - I_bar)) / sum((t - t_bar)^2)\n\n"
            "Positive values represent an upward/increasing trajectory in the spectral index (e.g. greening), "
            "while negative values represent a downward trend (e.g. degradation or browning)."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_SERIES, "Ordered Time-Series Rasters (T1, T2, ... Tn)", layerType=QgsProcessing.TypeRaster
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(self.OUTPUT, "Linear Trend Slope Raster (Float32)")
        )

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {}
        try:
            from osgeo import gdal
            import numpy as np
        except ImportError:
            raise QgsProcessingException("GDAL with NumPy is required for time-series raster processing.")

        layers = self.parameterAsLayerList(parameters, self.INPUT_SERIES, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if len(layers) < 2:
            raise QgsProcessingException("At least 2 ordered time-series raster layers are required.")

        ref_ds = gdal.Open(layers[0].source(), gdal.GA_ReadOnly)
        cols, rows = ref_ds.RasterXSize, ref_ds.RasterYSize
        geotransform, projection = ref_ds.GetGeoTransform(), ref_ds.GetProjection()

        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32, options=["TILED=YES", "COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(geotransform)
        out_ds.SetProjection(projection)
        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(-9999.0)

        datasets = [gdal.Open(lyr.source(), gdal.GA_ReadOnly) for lyr in layers]
        t_steps = list(range(1, len(layers) + 1))

        block_x, block_y = out_band.GetBlockSize()
        total_blocks = (cols // block_x + 1) * (rows // block_y + 1)
        count = 0

        for y in range(0, rows, block_y):
            if feedback.isCanceled(): break
            win_y = min(block_y, rows - y)
            for x in range(0, cols, block_x):
                if feedback.isCanceled(): break
                win_x = min(block_x, cols - x)

                stack_chunks = []
                for ds in datasets:
                    arr = ds.GetRasterBand(1).ReadAsArray(x, y, win_x, win_y)
                    stack_chunks.append(arr)

                stack_arr = np.array(stack_chunks)  # (T, win_y, win_x)
                slope_chunk = TimeSeriesEngine.calculate_ols_slope(t_steps, stack_arr, nodata=-9999.0)
                out_band.WriteArray(slope_chunk, x, y)
                count += 1
                feedback.setProgress(int((count / total_blocks) * 100))

        out_band.FlushCache()
        out_ds = None
        datasets.clear()
        ref_ds = None

        return {self.OUTPUT: output_path}


class TemporalCompositeAlgorithm(QgsProcessingAlgorithm):
    INPUT_STACK = "INPUT_STACK"
    METHOD = "METHOD"
    OUTPUT = "OUTPUT"

    def createInstance(self):
        return TemporalCompositeAlgorithm()

    def name(self):
        return "temporal_composite"

    def displayName(self):
        return "Temporal Composite (Median / Mean / Max)"

    def group(self):
        return "07 Multitemporal & Trends"

    def groupId(self):
        return "multitemporal_trends"

    def shortHelpString(self):
        return (
            "Creates a pixel-level multitemporal composite from a stack of cloud-masked index rasters.\n\n"
            "Methods supported:\n"
            "- Median: Highly robust against remnant cloud and shadow noise.\n"
            "- Max-Value (e.g. Max-NDVI): Conventional vegetation peak synthesis.\n"
            "- Mean: Average radiometric response."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_STACK, "Input Masked Raster Stack", layerType=QgsProcessing.TypeRaster
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.METHOD, "Composite Statistic Method", options=["Median (Recommended)", "Max Value", "Mean"], defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(self.OUTPUT, "Composited Raster (Float32)")
        )

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {}
        try:
            from osgeo import gdal
            import numpy as np
        except ImportError:
            raise QgsProcessingException("GDAL with NumPy is required for composite processing.")

        layers = self.parameterAsLayerList(parameters, self.INPUT_STACK, context)
        method_idx = self.parameterAsEnum(parameters, self.METHOD, context)
        methods = ["median", "max", "mean"]
        chosen_method = methods[method_idx]
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if not layers:
            raise QgsProcessingException("At least one input raster is required.")

        ref_ds = gdal.Open(layers[0].source(), gdal.GA_ReadOnly)
        cols, rows = ref_ds.RasterXSize, ref_ds.RasterYSize
        geotransform, projection = ref_ds.GetGeoTransform(), ref_ds.GetProjection()

        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32, options=["TILED=YES", "COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(geotransform)
        out_ds.SetProjection(projection)
        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(-9999.0)

        datasets = [gdal.Open(lyr.source(), gdal.GA_ReadOnly) for lyr in layers]
        block_x, block_y = out_band.GetBlockSize()
        total_blocks = (cols // block_x + 1) * (rows // block_y + 1)
        count = 0

        for y in range(0, rows, block_y):
            if feedback.isCanceled(): break
            win_y = min(block_y, rows - y)
            for x in range(0, cols, block_x):
                if feedback.isCanceled(): break
                win_x = min(block_x, cols - x)

                stack_chunks = [ds.GetRasterBand(1).ReadAsArray(x, y, win_x, win_y) for ds in datasets]
                stack_arr = np.array(stack_chunks)
                comp = TimeSeriesEngine.composite_stack(stack_arr, method=chosen_method, nodata=-9999.0)
                out_band.WriteArray(comp, x, y)
                count += 1
                feedback.setProgress(int((count / total_blocks) * 100))

        out_band.FlushCache()
        out_ds = None
        datasets.clear()
        ref_ds = None

        return {self.OUTPUT: output_path}

