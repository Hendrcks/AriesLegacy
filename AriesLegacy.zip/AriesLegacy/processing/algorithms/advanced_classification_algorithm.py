"""
AriesLegacy - Advanced Classification Algorithms.
Implements Otsu binary thresholding and Jenks Natural Breaks classification.
"""

import os
from typing import Dict, Any

try:
    from qgis.core import (
        QgsProcessing,
        QgsProcessingAlgorithm,
        QgsProcessingParameterRasterLayer,
        QgsProcessingParameterNumber,
        QgsProcessingParameterRasterDestination,
        QgsProcessingOutputNumber,
        QgsProcessingException,
        QgsRasterLayer,
    )
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm:
        pass

from ...core.classifier import Classifier, ClassificationScheme, ThresholdClass


class OtsuThresholdAlgorithm(QgsProcessingAlgorithm):
    INPUT = "INPUT"
    OUTPUT = "OUTPUT"
    THRESHOLD_VALUE = "THRESHOLD_VALUE"

    def createInstance(self):
        return OtsuThresholdAlgorithm()

    def name(self):
        return "otsu_threshold"

    def displayName(self):
        return "Otsu Automated Binary Threshold"

    def group(self):
        return "05 Classification"

    def groupId(self):
        return "classification"

    def shortHelpString(self):
        return (
            "Applies Otsu's thresholding method to an index raster (e.g. NDWI for water extraction, "
            "or NDVI for vegetation segmentation). Maximizes between-class variance across the valid histogram.\n\n"
            "Output raster values:\n"
            "0 = Below threshold (e.g. Non-water or Non-vegetation)\n"
            "1 = Above threshold (e.g. Water or Vegetation)"
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, "Input Continuous Index Raster"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Binarized Output Raster (Byte/Int32)"))
        self.addOutput(QgsProcessingOutputNumber(self.THRESHOLD_VALUE, "Computed Otsu Threshold Value"))

    def processAlgorithm(self, parameters, context, feedback):
        if not HAS_QGIS:
            return {}
        try:
            from osgeo import gdal
            import numpy as np
        except ImportError:
            raise QgsProcessingException("GDAL with NumPy is required for Otsu thresholding.")

        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        src_ds = gdal.Open(input_layer.source(), gdal.GA_ReadOnly)
        cols, rows = src_ds.RasterXSize, src_ds.RasterYSize
        geotransform, projection = src_ds.GetGeoTransform(), src_ds.GetProjection()

        # Step 1: Compute Otsu threshold from subsampled array
        sample_step_x = max(1, cols // 500)
        sample_step_y = max(1, rows // 500)
        sample_arr = src_ds.GetRasterBand(1).ReadAsArray(0, 0, cols, rows, buf_xsize=cols // sample_step_x, buf_ysize=rows // sample_step_y)
        threshold_val = Classifier.compute_otsu_threshold(sample_arr, nodata=-9999.0)

        # Step 2: Write binary raster
        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_Byte, options=["TILED=YES", "COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(geotransform)
        out_ds.SetProjection(projection)
        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(255)

        block_x, block_y = out_band.GetBlockSize()
        total_blocks = (cols // block_x + 1) * (rows // block_y + 1)
        count = 0

        for y in range(0, rows, block_y):
            if feedback.isCanceled(): break
            win_y = min(block_y, rows - y)
            for x in range(0, cols, block_x):
                if feedback.isCanceled(): break
                win_x = min(block_x, cols - x)

                arr = src_ds.GetRasterBand(1).ReadAsArray(x, y, win_x, win_y)
                valid = (arr != -9999.0) & np.isfinite(arr)
                bin_chunk = np.full((win_y, win_x), 255, dtype=np.uint8)
                bin_chunk[valid] = (arr[valid] >= threshold_val).astype(np.uint8)

                out_band.WriteArray(bin_chunk, x, y)
                count += 1
                feedback.setProgress(int((count / total_blocks) * 100))

        out_band.FlushCache()
        out_ds, src_ds = None, None

        return {self.OUTPUT: output_path, self.THRESHOLD_VALUE: threshold_val}

