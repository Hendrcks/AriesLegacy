"""
AriesLegacy - Processing Provider.
Registers all AriesLegacy algorithms in the QGIS Processing Toolbox.
Complies with AriesLegacy v2 Scientific Remote Sensing Workbench specification.
"""

import os

try:
    from qgis.core import QgsProcessingProvider
    from qgis.PyQt.QtGui import QIcon
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingProvider:
        pass

from .algorithms.index_calculation_algorithm import IndexCalculationAlgorithm
from .algorithms.batch_indices_algorithm import BatchIndicesAlgorithm
from .algorithms.change_detection_algorithm import ChangeDetectionAlgorithm
from .algorithms.classification_stats_algorithm import ClassificationStatsAlgorithm
from .algorithms.preprocessing_algorithms import LandsatL2SRDecodeAlgorithm, Sentinel2L2ASRDecodeAlgorithm
from .algorithms.custom_index_algorithm import CustomIndexAlgorithm
from .algorithms.timeseries_algorithms import OLSTrendAlgorithm, TemporalCompositeAlgorithm
from .algorithms.dnbr_change_algorithm import DNBRChangeAlgorithm
from .algorithms.advanced_classification_algorithm import OtsuThresholdAlgorithm
from .algorithms.audit_manifest_algorithm import GenerateAuditManifestAlgorithm
from .algorithms.atmospheric_algorithms import (
    InspectProductAlgorithm,
    TOACalibrationAlgorithm,
    AutomaticCorrectionAlgorithm,
    AdvancedCorrectionAlgorithm,
    CorrectionQualityAlgorithm,
)


class AriesLegacyProcessingProvider(QgsProcessingProvider):
    """QGIS Processing Provider for AriesLegacy."""

    def id(self):
        return "arieslegacy"

    def name(self):
        return "AriesLegacy — Scientific Remote Sensing"

    def icon(self):
        if not HAS_QGIS:
            return None
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        icon_path = os.path.join(base_dir, "icons", "icon.svg")
        if not os.path.exists(icon_path):
            icon_path = os.path.join(base_dir, "icons", "icon.png")
        if os.path.exists(icon_path):
            return QIcon(icon_path)
        return super().icon()

    def loadAlgorithms(self):
        # 01 Atmospheric Correction (AL-ATM-BOOK-2.0)
        self.addAlgorithm(InspectProductAlgorithm())
        self.addAlgorithm(TOACalibrationAlgorithm())
        self.addAlgorithm(AutomaticCorrectionAlgorithm())
        self.addAlgorithm(AdvancedCorrectionAlgorithm())
        self.addAlgorithm(CorrectionQualityAlgorithm())

        # 02 Radiometric Preprocessing
        self.addAlgorithm(LandsatL2SRDecodeAlgorithm())
        self.addAlgorithm(Sentinel2L2ASRDecodeAlgorithm())

        # 04 Spectral Indices
        self.addAlgorithm(IndexCalculationAlgorithm())
        self.addAlgorithm(BatchIndicesAlgorithm())
        self.addAlgorithm(CustomIndexAlgorithm())

        # 05 Classification
        self.addAlgorithm(ClassificationStatsAlgorithm())
        self.addAlgorithm(OtsuThresholdAlgorithm())

        # 06 Change Detection
        self.addAlgorithm(ChangeDetectionAlgorithm())
        self.addAlgorithm(DNBRChangeAlgorithm())

        # 07 Multitemporal & Trends
        self.addAlgorithm(OLSTrendAlgorithm())
        self.addAlgorithm(TemporalCompositeAlgorithm())

        # 08 Statistics & QA
        self.addAlgorithm(GenerateAuditManifestAlgorithm())
