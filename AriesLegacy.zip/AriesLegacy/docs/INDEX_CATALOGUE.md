# AriesLegacy Geospatial Index Catalogue (v2.0.0)

This catalogue documents all 42 peer-reviewed optical and thermal spectral indices supported in **AriesLegacy v2.0.0**. Every index includes its canonical mathematical formula, required spectral bands, recommended symbology, primary application, and scientific literature reference.

---

## 1. Vegetation, Chlorophyll & Canopy Vigor

### NDVI — Normalized Difference Vegetation Index (IND-001)
- **Formula:** $\text{NDVI} = \frac{\text{NIR} - \text{RED}}{\text{NIR} + \text{RED}}$
- **Required Bands:** `NIR`, `RED`
- **Output Range:** $[-1.0, 1.0]$
- **Recommended Style:** `RdYlGn`
- **Application:** General vegetation vigor, canopy density, photosynthetic capacity, and phenology.
- **Reference:** Rouse, J. W., et al. (1974). Monitoring the vernal advancement and retrogradation of natural vegetation. *NASA/GSFC Type III Final Report*, Greenbelt, MD.

### GNDVI — Green Normalized Difference Vegetation Index (IND-002)
- **Formula:** $\text{GNDVI} = \frac{\text{NIR} - \text{GREEN}}{\text{NIR} + \text{GREEN}}$
- **Required Bands:** `NIR`, `GREEN`
- **Output Range:** $[-1.0, 1.0]$
- **Recommended Style:** `RdYlGn`
- **Application:** Chlorophyll concentration, canopy nitrogen status, and late-season crop monitoring.
- **Reference:** Gitelson, A. A., & Merzlyak, M. N. (1998). Remote sensing of chlorophyll concentration in higher plant leaves. *Adv. Space Res.*, 22(5), 689–692.

### EVI — Enhanced Vegetation Index (IND-003)
- **Formula:** $\text{EVI} = 2.5 \times \frac{\text{NIR} - \text{RED}}{\text{NIR} + 6.0\,\text{RED} - 7.5\,\text{BLUE} + 1.0}$
- **Required Bands:** `NIR`, `RED`, `BLUE`
- **Recommended Style:** `RdYlGn`
- **Application:** High-biomass canopy monitoring, dense tropical forests, resistant to atmospheric aerosols.
- **Reference:** Huete, A., et al. (2002). Overview of the radiometric and biophysical performance of the MODIS vegetation indices. *Remote Sens. Environ.*, 83(1-2), 195–213.

### EVI2 — Two-Band Enhanced Vegetation Index (IND-004)
- **Formula:** $\text{EVI2} = 2.5 \times \frac{\text{NIR} - \text{RED}}{\text{NIR} + 2.4\,\text{RED} + 1.0}$
- **Required Bands:** `NIR`, `RED`
- **Recommended Style:** `RdYlGn`
- **Application:** High-biomass vegetation tracking when blue band is missing or atmospherically contaminated.
- **Reference:** Jiang, Z., et al. (2008). Development of a two-band enhanced vegetation index without a blue band. *Remote Sens. Environ.*, 112(10), 3833–3845.

### SAVI — Soil-Adjusted Vegetation Index (IND-005)
- **Formula:** $\text{SAVI} = \frac{\text{NIR} - \text{RED}}{\text{NIR} + \text{RED} + 0.5} \times 1.5$
- **Required Bands:** `NIR`, `RED`
- **Recommended Style:** `RdYlGn`
- **Application:** Arid, semi-arid, and early-stage crop canopies with visible soil background ($L=0.5$).
- **Reference:** Huete, A. R. (1988). A soil-adjusted vegetation index (SAVI). *Remote Sens. Environ.*, 25(3), 295–309.

### MSAVI — Modified Soil-Adjusted Vegetation Index (IND-006)
- **Formula:** $\text{MSAVI} = \frac{2\,\text{NIR} + 1 - \sqrt{(2\,\text{NIR} + 1)^2 - 8(\text{NIR} - \text{RED})}}{2}$
- **Required Bands:** `NIR`, `RED`
- **Recommended Style:** `RdYlGn`
- **Application:** Self-adjusting soil background correction across varying vegetation densities.
- **Reference:** Qi, J., et al. (1994). A modified soil adjusted vegetation index. *Remote Sens. Environ.*, 48(2), 119–126.

### OSAVI — Optimized Soil-Adjusted Vegetation Index (IND-007)
- **Formula:** $\text{OSAVI} = \frac{\text{NIR} - \text{RED}}{\text{NIR} + \text{RED} + 0.16}$
- **Required Bands:** `NIR`, `RED`
- **Recommended Style:** `RdYlGn`
- **Application:** Optimized soil adjustment factor ($X=0.16$) for intermediate canopy covers.
- **Reference:** Rondeaux, G., et al. (1996). Optimization of soil-adjusted vegetation indices. *Remote Sens. Environ.*, 55(2), 95–107.

### NDRE — Normalized Difference Red Edge Index (IND-008)
- **Formula:** $\text{NDRE} = \frac{\text{NIR} - \text{RED\_EDGE\_1}}{\text{NIR} + \text{RED\_EDGE\_1}}$
- **Required Bands:** `NIR`, `RED_EDGE_1` (Sentinel-2 B05)
- **Recommended Style:** `RdYlGn`
- **Application:** Precision agriculture, mid-to-late season crop nitrogen and leaf chlorophyll.
- **Reference:** Barnes, E. M., et al. (2000). Coincident detection of crop water stress, nitrogen status and canopy density. *Proc. 5th Int. Conf. Prec. Agric.*

### MTCI — MERIS Terrestrial Chlorophyll Index (IND-009)
- **Formula:** $\text{MTCI} = \frac{\text{RED\_EDGE\_2} - \text{RED\_EDGE\_1}}{\text{RED\_EDGE\_1} - \text{RED}}$
- **Required Bands:** `RED_EDGE_2`, `RED_EDGE_1`, `RED`
- **Recommended Style:** `RdYlGn`
- **Application:** Canopy chlorophyll content estimation without saturation at high biomass.
- **Reference:** Dash, J., & Curran, P. J. (2004). The MERIS terrestrial chlorophyll index. *Int. J. Remote Sens.*, 25(23), 5403–5413.

### CI_green — Chlorophyll Index Green (IND-010)
- **Formula:** $\text{CI\_green} = \frac{\text{NIR}}{\text{GREEN}} - 1.0$
- **Required Bands:** `NIR`, `GREEN`
- **Recommended Style:** `RdYlGn`
- **Application:** Total chlorophyll content across broadleaf and cereal crop canopies.
- **Reference:** Gitelson, A. A., et al. (2005). Remote estimation of canopy chlorophyll content in crops. *Geophys. Res. Lett.*, 32(8).

### CI_re — Chlorophyll Index Red Edge (IND-011)
- **Formula:** $\text{CI\_re} = \frac{\text{NIR}}{\text{RED\_EDGE\_1}} - 1.0$
- **Required Bands:** `NIR`, `RED_EDGE_1`
- **Recommended Style:** `RdYlGn`
- **Application:** Red-edge based chlorophyll tracking in Sentinel-2 imagery.
- **Reference:** Gitelson, A. A., et al. (2003). Relationships between leaf chlorophyll content and spectral reflectance. *J. Plant Physiol.*, 160(3), 271–282.

### ARI — Anthocyanin Reflectance Index (IND-012)
- **Formula:** $\text{ARI} = \frac{1.0}{\text{GREEN}} - \frac{1.0}{\text{RED\_EDGE\_1}}$
- **Required Bands:** `GREEN`, `RED_EDGE_1`
- **Recommended Style:** `Magma`
- **Application:** Foliar anthocyanin accumulation indicating plant stress, senescence, and disease.
- **Reference:** Gitelson, A. A., et al. (2001). Non-destructive assessment of anthocyanin content in higher plant leaves. *Photochem. Photobiol.*, 74(1), 38–45.

### CRI — Carotenoid Reflectance Index (IND-013)
- **Formula:** $\text{CRI} = \frac{1.0}{\text{BLUE}} - \frac{1.0}{\text{GREEN}}$
- **Required Bands:** `BLUE`, `GREEN`
- **Recommended Style:** `Spectral`
- **Application:** Carotenoid pigment concentration relative to chlorophyll.
- **Reference:** Gitelson, A. A., et al. (2002). Assessing carotenoid content in plant leaves. *Photochem. Photobiol.*, 75(3), 272–281.

### VARI — Visible Atmospherically Resistant Index (IND-014)
- **Formula:** $\text{VARI} = \frac{\text{GREEN} - \text{RED}}{\text{GREEN} + \text{RED} - \text{BLUE}}$
- **Required Bands:** `GREEN`, `RED`, `BLUE`
- **Recommended Style:** `RdYlGn`
- **Application:** RGB-only vegetation fraction estimation with atmospheric resistance.
- **Reference:** Gitelson, A. A., et al. (2002). Novel algorithms for remote estimation of vegetation fraction. *Remote Sens. Environ.*, 80(1), 76–87.

### SIPI — Structure Insensitive Pigment Index (IND-015)
- **Formula:** $\text{SIPI} = \frac{\text{NIR} - \text{BLUE}}{\text{NIR} - \text{RED}}$
- **Required Bands:** `NIR`, `BLUE`, `RED`
- **Recommended Style:** `Spectral`
- **Application:** Ratio of carotenoids to chlorophyll $a$ independent of canopy architecture.
- **Reference:** Peñuelas, J., et al. (1995). The reflectance spectrum of plant leaves: carotenoid/chlorophyll ratio. *Int. J. Remote Sens.*, 16(12), 2199–2216.

---

## 2. Water, Inundation & Wetlands

### NDWI — Normalized Difference Water Index (IND-016)
- **Formula:** $\text{NDWI} = \frac{\text{GREEN} - \text{NIR}}{\text{GREEN} + \text{NIR}}$
- **Required Bands:** `GREEN`, `NIR`
- **Output Range:** $[-1.0, 1.0]$
- **Recommended Style:** `Blues`
- **Application:** Delineation of open surface water bodies and river networks.
- **Reference:** McFeeters, S. K. (1996). The use of the Normalized Difference Water Index (NDWI) in the delineation of open water features. *Int. J. Remote Sens.*, 17(7), 1425–1432.

### MNDWI — Modified Normalized Difference Water Index (IND-017)
- **Formula:** $\text{MNDWI} = \frac{\text{GREEN} - \text{SWIR\_1}}{\text{GREEN} + \text{SWIR\_1}}$
- **Required Bands:** `GREEN`, `SWIR_1`
- **Output Range:** $[-1.0, 1.0]$
- **Recommended Style:** `Blues`
- **Application:** Urban flood delineation and surface water extraction with built-up noise suppressed.
- **Reference:** Xu, H. (2006). Modification of normalised difference water index (NDWI) to enhance open water features in remotely sensed imagery. *Int. J. Remote Sens.*, 27(14), 3025–3033.

### AWEI_nsh — Automated Water Extraction Index Non-Shadow (IND-018)
- **Formula:** $\text{AWEI\_nsh} = 4(\text{GREEN} - \text{SWIR\_1}) - (0.25\,\text{NIR} + 2.75\,\text{SWIR\_2})$
- **Required Bands:** `GREEN`, `SWIR_1`, `NIR`, `SWIR_2`
- **Recommended Style:** `Blues`
- **Application:** Robust water surface extraction in non-mountainous, urban and agricultural scenes.
- **Reference:** Feyisa, G. L., et al. (2014). Automated Water Extraction Index: A new technique for surface water mapping using Landsat imagery. *Remote Sens. Environ.*, 140, 23–35.

### AWEI_sh — Automated Water Extraction Index Shadow (IND-019)
- **Formula:** $\text{AWEI\_sh} = \text{BLUE} + 2.5\,\text{GREEN} - 1.5(\text{NIR} + \text{SWIR\_1}) - 0.25\,\text{SWIR\_2}$
- **Required Bands:** `BLUE`, `GREEN`, `NIR`, `SWIR_1`, `SWIR_2`
- **Recommended Style:** `Blues`
- **Application:** Water extraction specifically designed to suppress mountain, building, and cloud cast shadows.
- **Reference:** Feyisa, G. L., et al. (2014). Automated Water Extraction Index. *Remote Sens. Environ.*, 140, 23–35.

### WI — Water Index 2015 (IND-020)
- **Formula:** $\text{WI} = 1.7204 + 171\,\text{GREEN} + 3\,\text{RED} - 70\,\text{NIR} - 45\,\text{SWIR\_1} - 71\,\text{SWIR\_2}$
- **Required Bands:** `GREEN`, `RED`, `NIR`, `SWIR_1`, `SWIR_2`
- **Recommended Style:** `Blues`
- **Application:** Multi-spectral empirical water classification model.
- **Reference:** Fisher, A., et al. (2016). Comparing Landsat water index methods for automated water classification in eastern Australia. *Remote Sens. Environ.*, 175, 167–182.

---

## 3. Canopy Moisture & Drought

### NDMI — Normalized Difference Moisture Index (IND-021)
- **Formula:** $\text{NDMI} = \frac{\text{NIR} - \text{SWIR\_1}}{\text{NIR} + \text{SWIR\_1}}$
- **Required Bands:** `NIR`, `SWIR_1`
- **Output Range:** $[-1.0, 1.0]$
- **Recommended Style:** `Blues`
- **Application:** Canopy liquid water content, fuel moisture, and agricultural drought severity.
- **Reference:** Gao, B. C. (1996). NDWI—A normalized difference water index for remote sensing of vegetation liquid water from space. *Remote Sens. Environ.*, 58(3), 257–266.

### MSI — Moisture Stress Index (IND-022)
- **Formula:** $\text{MSI} = \frac{\text{SWIR\_1}}{\text{NIR}}$
- **Required Bands:** `SWIR_1`, `NIR`
- **Recommended Style:** `Magma`
- **Application:** Leaf and canopy moisture stress; higher values indicate increasing water deficit.
- **Reference:** Rock, B. N., et al. (1986). Remote detection of forest damage. *BioScience*, 36(7), 439–445.

### NMDI — Normalized Multi-band Drought Index (IND-023)
- **Formula:** $\text{NMDI} = \frac{\text{NIR} - (\text{SWIR\_1} - \text{SWIR\_2})}{\text{NIR} + (\text{SWIR\_1} - \text{SWIR\_2})}$
- **Required Bands:** `NIR`, `SWIR_1`, `SWIR_2`
- **Recommended Style:** `Spectral`
- **Application:** Soil and vegetation moisture monitoring using two distinct SWIR absorption channels.
- **Reference:** Wang, L., & Qu, J. J. (2007). NMDI: A normalized multi-band drought index for monitoring soil and vegetation moisture with satellite data. *Geophys. Res. Lett.*, 34(20).

---

## 4. Built-Up, Settlement & Impervious Surface

### NDBI — Normalized Difference Built-Up Index (IND-024)
- **Formula:** $\text{NDBI} = \frac{\text{SWIR\_1} - \text{NIR}}{\text{SWIR\_1} + \text{NIR}}$
- **Required Bands:** `SWIR_1`, `NIR`
- **Output Range:** $[-1.0, 1.0]$
- **Recommended Style:** `YlOrBr`
- **Application:** Urban settlement delineation and impervious surface footprint mapping.
- **Reference:** Zha, Y., et al. (2003). Use of normalized difference built-up index in automatically mapping urban areas from TM imagery. *Int. J. Remote Sens.*, 24(3), 583–594.

### UI — Urban Index (IND-025)
- **Formula:** $\text{UI} = \frac{\text{SWIR\_2} - \text{NIR}}{\text{SWIR\_2} + \text{NIR}}$
- **Required Bands:** `SWIR_2`, `NIR`
- **Recommended Style:** `YlOrBr`
- **Application:** High-density urban infrastructure and industrial built-up mapping.
- **Reference:** Kawamura, M., et al. (1996). Relation between social and environmental conditions in urban areas and urban index. *Proc. 17th ACRS*, Colombo, Sri Lanka.

### NDISI — Normalized Difference Impervious Surface Index (IND-026)
- **Formula:** $\text{NDISI} = \frac{\text{THERMAL} - (\text{MNDWI} + \text{NIR} + \text{SWIR\_1})/3.0}{\text{THERMAL} + (\text{MNDWI} + \text{NIR} + \text{SWIR\_1})/3.0}$
- **Required Bands:** `THERMAL`, `GREEN`, `NIR`, `SWIR_1`
- **Recommended Style:** `YlOrBr`
- **Application:** Impervious surface extraction integrating thermal emission with optical reflectance.
- **Reference:** Xu, H. (2010). Analysis of impervious surface and its impact on urban heat environment using the normalized difference impervious surface index (NDISI). *Photogramm. Eng. Remote Sensing*, 76(5), 557–565.

### EBBI — Enhanced Built-Up and Bareness Index (IND-027)
- **Formula:** $\text{EBBI} = \frac{\text{SWIR\_1} - \text{NIR}}{10.0\,\sqrt{\text{SWIR\_1} + \text{THERMAL}}}$
- **Required Bands:** `SWIR_1`, `NIR`, `THERMAL`
- **Recommended Style:** `YlOrBr`
- **Application:** Differentiating built-up areas from bare soil using combined SWIR and thermal data.
- **Reference:** As-syakur, A. R., et al. (2012). Enhanced Built-Up and Bareness Index (EBBI) for mapping built-up and bare land in an urban area. *Remote Sens.*, 4(10), 2957–2970.

### IBI — Index-based Built-up Index (IND-028)
- **Formula:** $\text{IBI} = \frac{\text{NDBI} - (\text{SAVI} + \text{MNDWI})/2.0}{\text{NDBI} + (\text{SAVI} + \text{MNDWI})/2.0}$
- **Required Bands:** `SWIR_1`, `NIR`, `RED`, `GREEN`
- **Recommended Style:** `YlOrBr`
- **Application:** Highly selective built-up extraction subtracting vegetation and water index responses.
- **Reference:** Xu, H. (2008). A new index for delineating built-up land features in satellite imagery. *Int. J. Remote Sens.*, 29(14), 4269–4276.

---

## 5. Bare Soil, Mineral & Mining

### BSI — Bare Soil Index (IND-029)
- **Formula:** $\text{BSI} = \frac{(\text{SWIR\_1} + \text{RED}) - (\text{NIR} + \text{BLUE})}{(\text{SWIR\_1} + \text{RED}) + (\text{NIR} + \text{BLUE})}$
- **Required Bands:** `SWIR_1`, `RED`, `NIR`, `BLUE`
- **Output Range:** $[-1.0, 1.0]$
- **Recommended Style:** `YlOrBr`
- **Application:** Exposed soil, mine pits, artisanal excavation, and soil erosion monitoring.
- **Reference:** Rikimaru, A., et al. (2002). Tropical forest cover review by Landsat data analysis. *Int. Arch. Photogramm. Remote Sens.*, 34(7), 18–24.

### Clay Minerals Ratio (IND-030)
- **Formula:** $\text{Clay Ratio} = \frac{\text{SWIR\_1}}{\text{SWIR\_2}}$
- **Required Bands:** `SWIR_1`, `SWIR_2`
- **Recommended Style:** `Spectral`
- **Application:** Hydrothermal alteration zones, clay-bearing minerals (kaolinite, alunite), and mining geology.
- **Reference:** Drury, S. A. (2001). *Image Interpretation in Geology* (3rd ed.). Blackwell Science, Oxford.

### Iron Oxide Ratio (IND-031)
- **Formula:** $\text{Iron Oxide} = \frac{\text{RED}}{\text{BLUE}}$
- **Required Bands:** `RED`, `BLUE`
- **Recommended Style:** `Spectral`
- **Application:** Gossan zones, hematite/goethite enrichment, and mine tailings deposits.
- **Reference:** Segal, D. B. (1989). Use of Landsat Thematic Mapper data for mineral exploration. *Proc. 7th Thematic Conf. Remote Sens. Explor. Geol.*, 149–158.

### Ferrous Iron Ratio (IND-032)
- **Formula:** $\text{Ferrous Iron} = \frac{\text{SWIR\_1}}{\text{NIR}}$
- **Required Bands:** `SWIR_1`, `NIR`
- **Recommended Style:** `Spectral`
- **Application:** Iron-bearing silicates and mining waste rock classification.
- **Reference:** Drury, S. A. (2001). *Image Interpretation in Geology* (3rd ed.). Blackwell Science, Oxford.

---

## 6. Fire, Burn Severity & Non-Photosynthetic Vegetation

### NBR — Normalized Burn Ratio (IND-033)
- **Formula:** $\text{NBR} = \frac{\text{NIR} - \text{SWIR\_2}}{\text{NIR} + \text{SWIR\_2}}$
- **Required Bands:** `NIR`, `SWIR_2`
- **Output Range:** $[-1.0, 1.0]$
- **Recommended Style:** `RdYlGn`
- **Application:** Pre-fire and post-fire canopy condition baseline.
- **Reference:** Key, C. H., & Benson, N. C. (2006). Landscape assessment: Ground measure of severity, the Composite Burn Index; and Remote sensing of severity, the Normalized Burn Ratio. *FIREMON: Fire Effects Monitoring and Inventory System*, RMRS-GTR-164-CD.

### NBR2 — Normalized Burn Ratio 2 (IND-034)
- **Formula:** $\text{NBR2} = \frac{\text{SWIR\_1} - \text{SWIR\_2}}{\text{SWIR\_1} + \text{SWIR\_2}}$
- **Required Bands:** `SWIR_1`, `SWIR_2`
- **Output Range:** $[-1.0, 1.0]$
- **Recommended Style:** `Spectral`
- **Application:** Non-photosynthetic vegetation (NPV), dry litter, crop residue, and fire scar persistence.
- **Reference:** Miller, J. D., & Thode, A. E. (2007). Quantifying burn severity in a heterogeneous landscape with a relative version of the delta Normalized Burn Ratio (RdNBR). *Remote Sens. Environ.*, 109(1), 66–80.

### BAI — Burn Area Index (IND-035)
- **Formula:** $\text{BAI} = \frac{1.0}{(0.1 - \text{RED})^2 + (0.06 - \text{NIR})^2}$
- **Required Bands:** `RED`, `NIR`
- **Recommended Style:** `Magma`
- **Application:** Charcoal and ash deposit detection emphasizing fire-affected reflectance convergence.
- **Reference:** Chuvieco, E., et al. (2002). Burned area mapping in the Mediterranean region using Landsat TM and NOAA-AVHRR data. *Remote Sens. Environ.*, 82(2-3), 431–442.

### dNBR — Differenced Normalized Burn Ratio (IND-036 / CHG-004)
- **Formula:** $\text{dNBR} = \text{NBR}_{\text{pre}} - \text{NBR}_{\text{post}}$
- **Required Bands:** `NBR_pre`, `NBR_post`
- **Recommended Style:** `Magma`
- **Application:** USGS/USFS standard post-wildfire burn severity categorization.
- **Reference:** Key, C. H., & Benson, N. C. (2006). *FIREMON: Fire Effects Monitoring and Inventory System*, USDA Forest Service RMRS-GTR-164-CD.

### RdNBR — Relativized Differenced Normalized Burn Ratio (IND-037 / CHG-005)
- **Formula:** $\text{RdNBR} = \frac{\text{NBR}_{\text{pre}} - \text{NBR}_{\text{post}}}{\sqrt{|\text{NBR}_{\text{pre}}| + 0.001}}$
- **Required Bands:** `NBR_pre`, `NBR_post`
- **Recommended Style:** `Magma`
- **Application:** Burn severity normalization across sparse vegetation ecosystems.
- **Reference:** Miller, J. D., & Thode, A. E. (2007). *Remote Sens. Environ.*, 109(1), 66–80.

### RBR — Relativized Burn Ratio (IND-038 / CHG-006)
- **Formula:** $\text{RBR} = \frac{\text{NBR}_{\text{pre}} - \text{NBR}_{\text{post}}}{\text{NBR}_{\text{pre}} + 1.001}$
- **Required Bands:** `NBR_pre`, `NBR_post`
- **Recommended Style:** `Magma`
- **Application:** Burn severity robust against zero or negative pre-fire NBR values.
- **Reference:** Parks, S. A., et al. (2014). A new metric for quantifying burn severity: The Relativized Burn Ratio. *Remote Sens.*, 6(3), 1827–1844.

### MIRBI — Mid-Infrared Burn Index (IND-039)
- **Formula:** $\text{MIRBI} = 10.0\,\text{SWIR\_2} - 9.8\,\text{SWIR\_1} + 2.0$
- **Required Bands:** `SWIR_2`, `SWIR_1`
- **Recommended Style:** `Magma`
- **Application:** Fire scar discrimination in arid and savannah shrublands.
- **Reference:** Trigg, S., & Flasse, S. (2001). An evaluation of the bi-spectral MIRBI burn index for burned area mapping in savannah. *Int. J. Remote Sens.*, 22(12), 2371–2378.

---

## 7. Cryosphere, Snow & Ice

### NDSI — Normalized Difference Snow Index (IND-040)
- **Formula:** $\text{NDSI} = \frac{\text{GREEN} - \text{SWIR\_1}}{\text{GREEN} + \text{SWIR\_1}}$
- **Required Bands:** `GREEN`, `SWIR_1`
- **Output Range:** $[-1.0, 1.0]$
- **Recommended Style:** `Blues`
- **Application:** Snow and ice cover delineation separating snow from optical cloud reflections.
- **Reference:** Hall, D. K., et al. (1995). Development of methods for mapping global snow cover using moderate resolution imaging spectroradiometer data. *Remote Sens. Environ.*, 54(2), 127–140.

### NDGI — Normalized Difference Glacier Index (IND-041)
- **Formula:** $\text{NDGI} = \frac{\text{GREEN} - \text{RED}}{\text{GREEN} + \text{RED}}$
- **Required Bands:** `GREEN`, `RED`
- **Output Range:** $[-1.0, 1.0]$
- **Recommended Style:** `Blues`
- **Application:** Glacier ice detection and debris-covered glacier margin tracking.
- **Reference:** Keshri, A. K., et al. (2009). Mapping of snow and glacier ice using normalized difference snow index (NDSI) and normalized difference glacier index (NDGI) on IRS-1D LISS-III data. *Geocarto Int.*, 24(4), 283–296.

### S3 — S3 Snow Index (IND-042)
- **Formula:** $\text{S3} = \frac{\text{NIR}(\text{GREEN} - \text{SWIR\_1})}{(\text{NIR} + \text{GREEN})(\text{NIR} + \text{SWIR\_1})}$
- **Required Bands:** `NIR`, `GREEN`, `SWIR_1`
- **Recommended Style:** `Blues`
- **Application:** Snow detection under forest canopies and mountainous terrain.
- **Reference:** Saito, A., et al. (1999). S3: Snow index for complex terrain and forest covers. *Proc. 20th Asian Conf. Remote Sens.*

---

## 8. Thermal & Land Surface Temperature

### LST_C — Land Surface Temperature in Celsius (IND-043 / PRE-009)
- **Formula:** $T_{\text{Celsius}} = (\text{THERMAL} \times 0.00341802 + 149.0) - 273.15$
- **Required Bands:** `THERMAL` (USGS Landsat Collection 2 Level-2 `ST_B10`)
- **Recommended Style:** `Magma`
- **Application:** Urban Heat Island (UHI) analysis, geothermal anomaly mapping, drought and evapotranspiration assessment.
- **Reference:** Cook, M. (2014). Atmospheric compensation for a Landsat land surface temperature product. *PhD Diss., RIT*; USGS Landsat 8-9 Collection 2 Level 2 Science Product Guide.
