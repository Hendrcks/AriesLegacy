# AriesLegacy User Guide

## Table of Contents
1. [Overview & Interface Layout](#1-overview--interface-layout)
2. [Quick Index Analysis & AST Formula Builder](#2-quick-index-analysis--ast-formula-builder)
3. [Multi-Index Batching](#3-multi-index-batching)
4. [Two-Date Change Detection Studio](#4-two-date-change-detection-studio)
5. [Thematic Classification & Area Statistics](#5-thematic-classification--area-statistics)
6. [Time-Series & Trend Analytics](#6-time-series--trend-analytics)
7. [Audit Reports & Scientific Provenance](#7-audit-reports--scientific-provenance)
8. [QGIS Processing Toolbox Provider](#8-qgis-processing-toolbox-provider)
9. [Settings & Radiometric Calibration](#9-settings--radiometric-calibration)

---

## 1. Overview & Interface Layout

AriesLegacy is integrated as a dockable panel in QGIS. You can open it via:
- The **AriesLegacy** satellite constellation icon on the Raster Toolbar.
- The top menu **Raster** > **AriesLegacy** > **AriesLegacy — Scientific Remote Sensing**.

The panel is organized into 8 functional tabs:
1. **Quick Index**: Instant single index calculation with auto-detected bands, radiometric calibration, and safe AST custom formulas.
2. **Multi-Index**: Batch calculation of multiple indices across an entire scene.
3. **☀️ Atmospheric**: TOA-to-BOA atmospheric correction supporting Mode A Automatic state inspection and Mode B Advanced 6S Radiative Transfer.
4. **Change Detection**: Rigorous two-date change analysis (signed diff, dNBR, RdNBR, RBR, CVA, transition matrices).
5. **Stats & Classes**: Interactive thresholding, statistical breaks (Jenks, Quantile, Equal Interval, StdDev, Otsu), and hectare area statistics.
6. **📈 Time-Series**: Multi-temporal trend analysis (OLS, Sen's slope, Mann-Kendall with p-values) and compositing (Median, Max, Mean).
7. **Export & Report**: Research-grade HTML and Markdown audit reports with complete mathematical formulas, peer-reviewed citations, SHA256 provenance hashes, and the official AriesLegacy banner.
8. **Settings**: Output directory defaults, default sensor profiles, and processing parameters.

---

## 2. Quick Index Analysis & AST Formula Builder

1. Select your **Raster Layer** from the dropdown, or check **Individual Band Layers** if your bands are separate files.
2. AriesLegacy automatically identifies the sensor profile (e.g. `Sentinel-2 MSI Level-2A`, `Sentinel-2 MSI Level-1C`, `Landsat 8/9 C2 L2`, `Landsat 4-7 C2 L2`, or `NASA HLS`).
3. Select an index from the **Geospatial Index** dropdown (e.g. NDVI, EVI, SAVI, MNDWI, NDWI, NDBI, BSI, NBR, NDRE, LST).
4. Review the auto-mapped canonical bands (`NIR`, `RED`, `GREEN`, `BLUE`, `SWIR_1`, `SWIR_2`, `RED_EDGE_1`, `THERMAL`).
5. Ensure **Apply radiometric scale factor** is checked to decode raw integer DN values to Surface Reflectance ($0.0 - 1.0$) and Celsius temperatures ($^\circ\text{C}$).
6. **Custom AST Formulas**: If you need a specialized index, type your formula into the custom expression field (e.g. `(NIR - RED) / (NIR + RED + 0.16)`). The parser uses an Abstract Syntax Tree (AST) evaluator with an allowlist of mathematical functions (`sqrt`, `abs`, `min`, `max`, `log`, `exp`, `sin`, `cos`, `safe_divide`) and strictly disallows arbitrary code execution.
7. Click **⚡ Calculate Index**. The styled index raster is calculated with GDAL chunk processing and added directly to your QGIS map canvas.

---

## 3. Multi-Index Batching

When you need multiple indices for comprehensive environmental monitoring:
1. Open the **Multi-Index** tab.
2. Select your input image.
3. Select the desired indices (e.g. NDVI for vegetation, MNDWI for surface water, NDBI for built-up, and BSI for bare ground).
4. Click **🚀 Run Multi-Index Batch**.
5. All layers are processed sequentially and saved with descriptive filenames and QML symbology into your output directory.

---

## 4. Two-Date Change Detection Studio

Compare two co-registered satellite scenes to quantify temporal landscape dynamics:
1. Open the **Change Detection** tab.
2. Select your **Pre-Date (Baseline)** and **Post-Date (After)** index layers.
3. Choose your analysis method:
   - **Signed Difference (CHG-001)**: $\Delta = Post - Pre$.
   - **Percentage Change (CHG-002)**: $\% = \frac{Post - Pre}{|Pre| + \epsilon} \times 100$.
   - **Difference Normalized Burn Ratio (CHG-004)**: Strictly $\text{dNBR} = Pre\_NBR - Post\_NBR$ (Key & Benson, 2006). Positive values indicate burn severity.
   - **Relativized dNBR (CHG-005)**: $\text{RdNBR} = \frac{Pre\_NBR - Post\_NBR}{\sqrt{|Pre\_NBR| + 0.001}}$.
   - **Relativized Burn Ratio (CHG-006)**: $\text{RBR} = \frac{Pre\_NBR - Post\_NBR}{Pre\_NBR + 1.001}$.
   - **Change Vector Analysis (CHG-007 / CHG-008)**: Computes 2D/multi-spectral magnitude $M = \sqrt{\sum (\Delta B_i)^2}$ and direction angle $\theta$.
   - **Transition Matrix (CHG-009)**: Cross-tabulates discrete thematic classes between Date 1 and Date 2, quantifying categorical gains, losses, and persistences.
4. Click **🔄 Calculate Two-Date Change**.

---

## 5. Thematic Classification & Area Statistics

1. Select your target continuous index layer in the **Stats & Classes** tab.
2. Choose your classification scheme:
   - **Manual Thresholds**: User-defined breaks and class labels.
   - **Equal Interval**: Breaks continuous values into equal-width intervals.
   - **Empirical Quantile**: Distributes pixels equally across classes (percentile breaks).
   - **Fisher-Jenks Natural Breaks**: Optimizes variance to minimize intra-class variance and maximize inter-class variance.
   - **Standard Deviation Intervals**: Bins based on multiples of standard deviation ($\mu \pm 0.5\sigma, \pm 1.0\sigma, \pm 2.0\sigma$).
   - **Otsu Binary Thresholding**: Automatically determines the optimal bimodal separation threshold maximizing between-class variance.
3. Click **📊 Classify & Calculate Area (Hectares)**.
4. AriesLegacy outputs exact pixel counts, total area in **Hectares ($ha$)**, **Square Kilometres ($km^2$)**, and percentage coverage for each class.
5. Export the summary table directly as CSV or include it in the HTML audit report.

---

## 6. Time-Series & Trend Analytics

Assess multi-temporal sensor stacks to determine vegetation greening/browning, water depletion, or climate trends:
1. Open the **📈 Time-Series** tab.
2. Select your ordered stack of temporal index rasters (or time-stamped band series).
3. Select the analytical model:
   - **OLS Linear Trend (TS-001)**: Computes ordinary least-squares slope $\beta_1$ and coefficient of determination $R^2$.
   - **Theil-Sen Robust Slope (TS-002)**: Computes the median pairwise slope across all observation pairs, resistant to outliers and cloud contamination.
   - **Mann-Kendall Trend Test (TS-003)**: Non-parametric monotonic trend test computing Mann-Kendall $S$, tie-corrected variance $\text{Var}(S)$, standardized $Z$-score, and two-tailed $p$-value.
   - **Baseline Anomaly (TS-005 / TS-006)**: Absolute anomaly $X_t - \mu_{\text{base}}$ or standardized $Z$-score anomaly $(X_t - \mu_{\text{base}}) / \sigma_{\text{base}}$.
   - **Temporal Composites (TS-007)**: Generates cloud-free temporal composites using pixel-level **Median**, **Maximum**, or **Mean**.
4. Click **Run Time-Series Analysis**.

---

## 7. Audit Reports & Scientific Provenance

Maintain full scientific transparency for peer-reviewed research, legal inquiries, or consulting deliverables:
1. In the **Export & Report** tab, fill in the Project/Study Area name, Analyst name, and contextual notes.
2. Click **📄 HTML Report** or **📝 Markdown** to generate a complete audit report including:
   - Base64-embedded official AriesLegacy spectral satellite logo banner.
   - Sensor metadata, acquisition timestamps, and radiometric scaling factors.
   - Exact mathematical formulas and peer-reviewed scientific citations.
   - Canonical band mapping tables.
   - Thematic classification area breakdown ($ha$, $km^2$, %).
   - Cryptographic SHA256 input/output file checksums and runtime parameter manifest.
   - Methodological cautions and spectral limitations.

---

## 8. QGIS Processing Toolbox Provider

All core AriesLegacy capabilities are registered as native QGIS Processing algorithms under the provider ID `arieslegacy`:
- **AriesLegacy: Inspect Satellite Product Metadata & State**: Automated detection of sensor level and radiometric state.
- **AriesLegacy: Calibrate Level-1 DN to TOA Reflectance**: Physical DN to TOA planetary reflectance conversion.
- **AriesLegacy: Automatic TOA-to-BOA Atmospheric Correction**: Mode A automated state inspection, Level-2 decode, and fail-safe TOA fallback.
- **AriesLegacy: Advanced 6S Physical Atmospheric Correction**: Mode B 6S physical radiative transfer model and inversion.
- **AriesLegacy: Compare TOA and BOA Reflectance Quality**: Statistical comparison (Bias, MAE, RMSE, Pearson r) against reference L2 imagery.
- **AriesLegacy: Calculate Spectral Index**: Single index calculation with automatic sensor detection.
- **AriesLegacy: Batch Calculate Spectral Indices**: Batch calculation of multiple indices.
- **AriesLegacy: Custom Index Calculator**: Safe AST-based custom mathematical expression evaluator.
- **AriesLegacy: Decode Landsat Collection 2 L2 Surface Reflectance**: Scientific scaling ($0.0000275 \times \text{DN} - 0.2$).
- **AriesLegacy: Decode Sentinel-2 L2A Surface Reflectance**: Scientific scaling with baseline 04.00+ BOA offset support.
- **AriesLegacy: Two-Date Change Detection**: Signed diff, relative %, and gain/loss classification.
- **AriesLegacy: Post-Fire dNBR & Burn Severity**: Standardized Key & Benson (2006) burn severity.
- **AriesLegacy: OLS Linear Trend Analysis**: Multi-temporal OLS slope calculation.
- **AriesLegacy: Multitemporal Composite**: Pixel-level median, maximum, or mean compositing.
- **AriesLegacy: Otsu Automated Thresholding**: Optimal bimodal raster binarization.
- **AriesLegacy: Generate Audit Manifest**: Cryptographic SHA256 parameter and checksum manifest.

All algorithms are fully compatible with the **QGIS Graphical Modeler**, batch processing, and PyQGIS scripting!

---

## 9. Settings & Radiometric Calibration

- **Output Directory**: Configure your preferred destination folder for calculated rasters, vectors, tables, and reports.
- **Default Sensor Profile**: Set a preferred default sensor profile (e.g. `Sentinel-2 MSI Level-2A` or `Landsat 8/9 C2 L2`).
- **Radiometric Validation**: Enable strict surface reflectance checks to identify and warn when sub-zero reflectance or extreme out-of-range values occur.
