"""
AriesLegacy - Band Detector.
Inspects raster layers, filenames, band names, and metadata to identify sensors and map bands automatically.
Complies with AriesLegacy v2 canonical variables:
COASTAL, BLUE, GREEN, RED, RE1, RE2, RE3, NIR, NIR_NARROW, SWIR1, SWIR2, THERMAL.
"""

import os
import re
from typing import Dict, List, Optional, Tuple, Any

from .sensor_profiles import SensorProfile, SensorProfileManager


class BandDetectionResult:
    """Encapsulates detected sensor and canonical band mappings."""

    def __init__(self, sensor_profile: SensorProfile, confidence: str = "Low"):
        self.sensor_profile: SensorProfile = sensor_profile
        self.confidence: str = confidence  # "High", "Medium", "Low", "Manual"
        self.band_to_number: Dict[str, int] = {}       # Canonical -> band index (1-based)
        self.band_to_layer_id: Dict[str, str] = {}    # Canonical -> layer ID (for multi-layer setups)
        self.band_to_path: Dict[str, str] = {}        # Canonical -> file path
        self.warnings: List[str] = []
        self.detected_resolutions: Dict[str, float] = {}

    def is_complete_for_index(self, required_canonical_bands: List[str]) -> bool:
        # Check normalized band keys
        mapped_keys = {k.upper().replace("_", "") for k in list(self.band_to_number.keys()) + list(self.band_to_layer_id.keys()) + list(self.band_to_path.keys())}
        for b in required_canonical_bands:
            if b.upper().replace("_", "") not in mapped_keys:
                return False
        return True

    def get_missing_bands(self, required_canonical_bands: List[str]) -> List[str]:
        mapped_keys = {k.upper().replace("_", "") for k in list(self.band_to_number.keys()) + list(self.band_to_layer_id.keys()) + list(self.band_to_path.keys())}
        missing = []
        for b in required_canonical_bands:
            if b.upper().replace("_", "") not in mapped_keys:
                missing.append(b)
        return missing

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sensor_id": self.sensor_profile.id,
            "sensor_name": self.sensor_profile.name,
            "confidence": self.confidence,
            "band_to_number": self.band_to_number,
            "band_to_path": self.band_to_path,
            "warnings": self.warnings,
            "detected_resolutions": self.detected_resolutions,
        }


class BandDetector:
    """Automated detector for imagery sensors and band configurations."""

    def __init__(self, profile_manager: Optional[SensorProfileManager] = None):
        self.profile_mgr = profile_manager or SensorProfileManager.get_instance()

    def detect_sensor_from_text(self, text: str) -> SensorProfile:
        """Determines sensor profile based on file path, layer name, or metadata string."""
        matched = self.profile_mgr.match_sensor_by_name_or_metadata(text)
        if matched:
            return matched
        return self.profile_mgr.get_profile("generic") or SensorProfile({"id": "generic", "name": "Generic"})

    def detect_from_file_path(self, file_path: str, band_count: int = 1, band_names: Optional[List[str]] = None) -> BandDetectionResult:
        """
        Detects sensor and canonical band mappings for a given raster file path and band list.
        """
        filename = os.path.basename(file_path)
        profile = self.detect_sensor_from_text(file_path)
        confidence = "Low"
        if profile.id != "generic":
            confidence = "High"

        result = BandDetectionResult(profile, confidence)
        names = band_names or []

        # If multiband stack
        if band_count > 1:
            self._map_multiband_stack(result, band_count, names, filename)
        else:
            # Single band file
            canonical = self._identify_canonical_from_filename(filename, profile)
            if canonical:
                result.band_to_number[canonical] = 1
                result.band_to_path[canonical] = file_path
                # Also store alias
                if canonical == "SWIR1": result.band_to_number["SWIR_1"] = 1
                elif canonical == "SWIR2": result.band_to_number["SWIR_2"] = 1
                elif canonical == "RE1": result.band_to_number["RED_EDGE_1"] = 1
                elif canonical == "RE2": result.band_to_number["RED_EDGE_2"] = 1
                elif canonical == "RE3": result.band_to_number["RED_EDGE_3"] = 1
                result.confidence = "High"

        return result

    def detect_from_layer_collection(self, layers_info: List[Dict[str, Any]]) -> BandDetectionResult:
        """
        Detects bands across a collection of single-band layers.
        layers_info: list of dicts with {"id": layer_id, "name": layer_name, "source": file_path}
        """
        all_text = " ".join([info.get("source", "") + " " + info.get("name", "") for info in layers_info])
        profile = self.detect_sensor_from_text(all_text)
        confidence = "Medium" if profile.id != "generic" else "Low"
        result = BandDetectionResult(profile, confidence)

        for info in layers_info:
            source = info.get("source", "")
            name = info.get("name", "")
            lid = info.get("id", "")
            fname = os.path.basename(source) if source else name

            canonical = self._identify_canonical_from_filename(fname, profile)
            if not canonical:
                canonical = self._identify_canonical_from_filename(name, profile)

            if canonical and canonical not in result.band_to_layer_id:
                result.band_to_layer_id[canonical] = lid
                result.band_to_path[canonical] = source
                result.band_to_number[canonical] = 1

                # Normalize aliases
                if canonical == "SWIR1":
                    result.band_to_layer_id["SWIR_1"] = lid
                    result.band_to_number["SWIR_1"] = 1
                elif canonical == "SWIR2":
                    result.band_to_layer_id["SWIR_2"] = lid
                    result.band_to_number["SWIR_2"] = 1
                elif canonical == "RE1":
                    result.band_to_layer_id["RED_EDGE_1"] = lid
                    result.band_to_number["RED_EDGE_1"] = 1

        if len(result.band_to_layer_id) >= 3:
            result.confidence = "High"

        return result

    def _map_multiband_stack(self, result: BandDetectionResult, band_count: int, band_names: List[str], filename: str) -> None:
        """Heuristically maps bands for multiband composite rasters."""
        profile = result.sensor_profile
        
        # 1. Try matching with explicit band names if provided
        for idx, bname in enumerate(band_names, start=1):
            canonical = profile.get_canonical_name_for_alias(bname)
            if canonical:
                result.band_to_number[canonical] = idx
                if canonical == "SWIR1": result.band_to_number["SWIR_1"] = idx
                elif canonical == "SWIR2": result.band_to_number["SWIR_2"] = idx
                elif canonical == "RE1": result.band_to_number["RED_EDGE_1"] = idx

        # 2. If nothing matched from band names, use sensor standard stack conventions
        if not result.band_to_number:
            if "sentinel" in profile.id:
                # Standard S2 12-band stack: B1, B2(Blue), B3(Green), B4(Red), B5(RE1), B6(RE2), B7(RE3), B8(NIR), B8A(NN), B9, B11(SWIR1), B12(SWIR2)
                if band_count >= 12:
                    result.band_to_number["COASTAL"] = 1
                    result.band_to_number["BLUE"] = 2
                    result.band_to_number["GREEN"] = 3
                    result.band_to_number["RED"] = 4
                    result.band_to_number["RE1"] = 5
                    result.band_to_number["RED_EDGE_1"] = 5
                    result.band_to_number["RE2"] = 6
                    result.band_to_number["RED_EDGE_2"] = 6
                    result.band_to_number["RE3"] = 7
                    result.band_to_number["RED_EDGE_3"] = 7
                    result.band_to_number["NIR"] = 8
                    result.band_to_number["NIR_NARROW"] = 9
                    result.band_to_number["NN"] = 9
                    result.band_to_number["SWIR1"] = 11
                    result.band_to_number["SWIR_1"] = 11
                    result.band_to_number["SWIR2"] = 12
                    result.band_to_number["SWIR_2"] = 12
                elif band_count == 4:
                    result.band_to_number["BLUE"] = 1
                    result.band_to_number["GREEN"] = 2
                    result.band_to_number["RED"] = 3
                    result.band_to_number["NIR"] = 4

            elif "landsat_8" in profile.id or "landsat_9" in profile.id:
                if band_count >= 7:
                    result.band_to_number["COASTAL"] = 1
                    result.band_to_number["BLUE"] = 2
                    result.band_to_number["GREEN"] = 3
                    result.band_to_number["RED"] = 4
                    result.band_to_number["NIR"] = 5
                    result.band_to_number["SWIR1"] = 6
                    result.band_to_number["SWIR_1"] = 6
                    result.band_to_number["SWIR2"] = 7
                    result.band_to_number["SWIR_2"] = 7
                    if band_count >= 8:
                        result.band_to_number["THERMAL"] = 8

            elif "landsat_5" in profile.id or "landsat_7" in profile.id:
                if band_count >= 6:
                    result.band_to_number["BLUE"] = 1
                    result.band_to_number["GREEN"] = 2
                    result.band_to_number["RED"] = 3
                    result.band_to_number["NIR"] = 4
                    result.band_to_number["SWIR1"] = 5
                    result.band_to_number["SWIR_1"] = 5
                    result.band_to_number["THERMAL"] = 6
                    result.band_to_number["SWIR2"] = 7
                    result.band_to_number["SWIR_2"] = 7

            else:
                if band_count >= 4:
                    result.band_to_number["BLUE"] = 1
                    result.band_to_number["GREEN"] = 2
                    result.band_to_number["RED"] = 3
                    result.band_to_number["NIR"] = 4
                elif band_count == 3:
                    result.band_to_number["RED"] = 1
                    result.band_to_number["GREEN"] = 2
                    result.band_to_number["BLUE"] = 3

    def _identify_canonical_from_filename(self, filename: str, profile: SensorProfile) -> Optional[str]:
        """Matches a single band filename to a canonical band name."""
        base, _ = os.path.splitext(filename)
        upper = base.upper()

        profiles_to_check = [profile]
        if profile.id == "generic":
            profiles_to_check.extend(self.profile_mgr.list_profiles())

        for p in profiles_to_check:
            for canonical, info in p.bands.items():
                bname = info.get("name", "").upper()
                aliases = [a.upper() for a in info.get("aliases", [])]

                tokens = [bname] + aliases
                for token in tokens:
                    if not token: continue
                    pattern = rf"(?:^|[_\-\.\s]){re.escape(token)}(?:[_\-\.\s]|$)"
                    if re.search(pattern, upper):
                        return canonical

        # Heuristic keywords
        if "RED" in upper and "RED_EDGE" not in upper and "RE1" not in upper and "RE2" not in upper and "RE3" not in upper:
            return "RED"
        if "NIR_NARROW" in upper or "B8A" in upper:
            return "NIR_NARROW"
        if "NIR" in upper or "NEAR_INFRARED" in upper or "B08" in upper or "B8" in upper:
            return "NIR"
        if "GREEN" in upper or "B03" in upper or "B3" in upper:
            return "GREEN"
        if "BLUE" in upper or "B02" in upper or "B2" in upper:
            return "BLUE"
        if "RE1" in upper or "B05" in upper or "B5" in upper:
            return "RE1"
        if "RE2" in upper or "B06" in upper:
            return "RE2"
        if "RE3" in upper or "B07" in upper:
            return "RE3"
        if "SWIR1" in upper or "SWIR_1" in upper or "B11" in upper or "B6" in upper:
            return "SWIR1"
        if "SWIR2" in upper or "SWIR_2" in upper or "B12" in upper or "B7" in upper:
            return "SWIR2"
        if "THERMAL" in upper or "TEMP" in upper or "ST_B10" in upper or "B10" in upper or "ST_B6" in upper:
            return "THERMAL"

        return None
