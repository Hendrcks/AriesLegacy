"""
AriesLegacy - Time-Series and Trend Analytics Engine.
Implements TS-001 through TS-014 from the AriesLegacy v2 specification.
Provides OLS Linear Slope, Sen's Slope (Theil-Sen), Mann-Kendall Trend Test,
Standardized Anomalies, and Multitemporal Compositing.
"""

import math
from typing import Dict, List, Optional, Tuple, Any, Union

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None


class TimeSeriesEngine:
    """Core mathematical and statistical engines for time-series analysis."""

    # -------------------------------------------------------------------------
    # TS-001: Ordinary Least Squares (OLS) Linear Trend
    # -------------------------------------------------------------------------
    @staticmethod
    def calculate_ols_slope(
        time_values: List[float],
        index_series: Any,  # 1D array/list of values, or 3D (T, Y, X)
        nodata: float = -9999.0
    ) -> Any:
        """
        TS-001: beta = sum((t - t_bar)*(I - I_bar)) / sum((t - t_bar)^2)
        Computes rate of change per time unit.
        """
        if len(time_values) < 2:
            raise ValueError("Time series requires at least 2 observations.")

        t = np.asarray(time_values, dtype=np.float64) if HAS_NUMPY else [float(x) for x in time_values]
        t_bar = np.mean(t) if HAS_NUMPY else sum(t) / len(t)
        t_diff = (t - t_bar) if HAS_NUMPY else [x - t_bar for x in t]
        denom = np.sum(t_diff ** 2) if HAS_NUMPY else sum(x ** 2 for x in t_diff)

        if denom == 0.0:
            raise ValueError("Zero variance in time steps.")

        if HAS_NUMPY and isinstance(index_series, np.ndarray):
            if index_series.ndim == 1:
                valid = (index_series != nodata) & np.isfinite(index_series)
                if np.count_nonzero(valid) < 2:
                    return nodata
                # Recompute on valid subset
                t_sub = t[valid]
                y_sub = index_series[valid].astype(np.float64)
                tb = np.mean(t_sub)
                yb = np.mean(y_sub)
                d = np.sum((t_sub - tb) ** 2)
                if d == 0.0:
                    return nodata
                return float(np.sum((t_sub - tb) * (y_sub - yb)) / d)
            elif index_series.ndim == 3:
                # 3D stack (T, rows, cols)
                T, rows, cols = index_series.shape
                out_slope = np.full((rows, cols), nodata, dtype=np.float32)
                # Vectorized slope across T axis
                valid = (index_series != nodata) & np.isfinite(index_series)
                valid_counts = np.sum(valid, axis=0)
                mask = valid_counts >= 2

                # Broadcasting for cells with full observations
                y_full = index_series.astype(np.float64)
                y_bar = np.mean(y_full, axis=0)
                t_expanded = t[:, np.newaxis, np.newaxis]
                numer = np.sum((t_expanded - t_bar) * (y_full - y_bar), axis=0)
                out_slope[mask] = (numer[mask] / denom).astype(np.float32)
                return out_slope
        else:
            # Scalar / list mode
            y = [float(v) for v in index_series if v != nodata and math.isfinite(v)]
            if len(y) < 2:
                return nodata
            y_bar = sum(y) / len(y)
            numer = sum(td * (y_val - y_bar) for td, y_val in zip(t_diff, y))
            return numer / denom

    # -------------------------------------------------------------------------
    # TS-002: Sen's Slope (Theil-Sen Robust Estimator)
    # -------------------------------------------------------------------------
    @staticmethod
    def calculate_sens_slope(
        time_values: List[float],
        series: List[float],
        nodata: float = -9999.0
    ) -> float:
        """
        TS-002: median_{i < j} [(I_j - I_i) / (t_j - t_i)]
        Robust against extreme atmospheric outliers and seasonal noise.
        """
        # Filter valid observations
        pairs = []
        for t, val in zip(time_values, series):
            if val != nodata and math.isfinite(val):
                pairs.append((float(t), float(val)))

        n = len(pairs)
        if n < 2:
            return nodata

        slopes = []
        for i in range(n - 1):
            t_i, y_i = pairs[i]
            for j in range(i + 1, n):
                t_j, y_j = pairs[j]
                dt = t_j - t_i
                if dt != 0.0:
                    slopes.append((y_j - y_i) / dt)

        if not slopes:
            return nodata

        if HAS_NUMPY:
            return float(np.median(slopes))
        else:
            slopes.sort()
            mid = len(slopes) // 2
            if len(slopes) % 2 == 1:
                return slopes[mid]
            return (slopes[mid - 1] + slopes[mid]) / 2.0

    # -------------------------------------------------------------------------
    # TS-003: Mann-Kendall Monotonic Trend Test
    # -------------------------------------------------------------------------
    @staticmethod
    def calculate_mann_kendall(
        series: List[float],
        nodata: float = -9999.0
    ) -> Dict[str, Any]:
        """
        TS-003: Non-parametric monotonic trend test.
        Returns S statistic, variance var(S) with ties, Z test statistic, and two-tailed p-value.
        """
        valid_vals = [float(x) for x in series if x != nodata and math.isfinite(x)]
        n = len(valid_vals)
        if n < 3:
            return {"s": 0, "var_s": 0.0, "z": 0.0, "p_value": 1.0, "trend": "insufficient_data"}

        # Calculate Kendall's S
        s = 0
        for i in range(n - 1):
            for j in range(i + 1, n):
                diff = valid_vals[j] - valid_vals[i]
                if diff > 1e-7:
                    s += 1
                elif diff < -1e-7:
                    s -= 1

        # Tie calculation
        tie_counts: Dict[float, int] = {}
        for v in valid_vals:
            tie_counts[round(v, 6)] = tie_counts.get(round(v, 6), 0) + 1

        sum_ties = 0
        for count in tie_counts.values():
            if count > 1:
                sum_ties += count * (count - 1) * (2 * count + 5)

        # Variance of S
        var_s = (n * (n - 1) * (2 * n + 5) - sum_ties) / 18.0

        # Standardized test statistic Z
        if var_s <= 0.0:
            z = 0.0
        elif s > 0:
            z = (s - 1) / math.sqrt(var_s)
        elif s < 0:
            z = (s + 1) / math.sqrt(var_s)
        else:
            z = 0.0

        # Two-tailed p-value via normal error function
        p_value = 2.0 * (1.0 - 0.5 * (1.0 + math.erf(abs(z) / math.sqrt(2.0))))
        p_value = max(0.0, min(1.0, p_value))

        trend = "no_trend"
        if p_value < 0.05:
            trend = "increasing" if z > 0 else "decreasing"

        return {
            "n": n,
            "s": s,
            "var_s": var_s,
            "z": z,
            "p_value": p_value,
            "trend": trend
        }

    # -------------------------------------------------------------------------
    # TS-005 & TS-006: Temporal Anomalies
    # -------------------------------------------------------------------------
    @staticmethod
    def calculate_standardized_anomaly(val: Any, mu_ref: float, sigma_ref: float, nodata: float = -9999.0) -> Any:
        """TS-005: Z_t = (I_t - mu_ref) / sigma_ref."""
        if sigma_ref <= 0.0:
            raise ValueError("Reference sigma must be strictly positive.")
        if HAS_NUMPY and isinstance(val, np.ndarray):
            valid = (val != nodata) & np.isfinite(val)
            out = np.full(val.shape, nodata, dtype=np.float32)
            out[valid] = ((val[valid] - mu_ref) / sigma_ref).astype(np.float32)
            return out
        else:
            v = float(val)
            if v == nodata or not math.isfinite(v):
                return nodata
            return (v - mu_ref) / sigma_ref

    @staticmethod
    def calculate_percentage_anomaly(val: Any, ref_val: float, eps: float = 1e-4, nodata: float = -9999.0) -> Any:
        """TS-006: 100 * (I_t - I_ref) / |I_ref|."""
        if abs(ref_val) <= eps:
            return nodata
        if HAS_NUMPY and isinstance(val, np.ndarray):
            valid = (val != nodata) & np.isfinite(val)
            out = np.full(val.shape, nodata, dtype=np.float32)
            out[valid] = (((val[valid] - ref_val) / abs(ref_val)) * 100.0).astype(np.float32)
            return out
        else:
            v = float(val)
            if v == nodata or not math.isfinite(v):
                return nodata
            return ((v - ref_val) / abs(ref_val)) * 100.0

    # -------------------------------------------------------------------------
    # TS-007: Multitemporal Compositing
    # -------------------------------------------------------------------------
    @staticmethod
    def composite_stack(
        raster_stack: Any,  # 3D NumPy array (T, rows, cols)
        method: str = "median",  # "median", "mean", "max"
        nodata: float = -9999.0
    ) -> Any:
        """
        TS-007: Computes temporal composite pixel-by-pixel ignoring nodata/cloud pixels.
        """
        if not HAS_NUMPY or not isinstance(raster_stack, np.ndarray):
            raise ValueError("raster_stack must be a 3D NumPy array.")

        T, rows, cols = raster_stack.shape
        out = np.full((rows, cols), nodata, dtype=np.float32)
        valid = (raster_stack != nodata) & np.isfinite(raster_stack)

        # Mask invalid with nan for nan-aggregations
        stack_float = raster_stack.astype(np.float64)
        stack_float[~valid] = np.nan

        # Ignore runtime warnings for all-NaN slices
        with np.errstate(all="ignore"):
            if method == "median":
                res = np.nanmedian(stack_float, axis=0)
            elif method == "max":
                res = np.nanmax(stack_float, axis=0)
            else:
                res = np.nanmean(stack_float, axis=0)

        valid_out = np.isfinite(res)
        out[valid_out] = res[valid_out].astype(np.float32)
        return out

