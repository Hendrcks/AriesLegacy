"""
AriesLegacy - Change Detection Engine.
Calculates multi-temporal differences, dNBR, RdNBR, RBR, CVA,
and post-classification transition matrices.
Supports scalars, NumPy arrays, and nested Python lists.
Strictly implements Section 5 (CHG-001 through CHG-014) of the AriesLegacy v2 specification.
"""

import math
from typing import Dict, List, Optional, Tuple, Any, Union

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None


class ChangeDetectionMode:
    SIGNED_DIFFERENCE = "signed_difference"          # Post - Pre (CHG-001)
    ABSOLUTE_DIFFERENCE = "absolute_difference"      # Post - Pre (legacy compatibility name)
    TRUE_ABSOLUTE_DIFFERENCE = "true_absolute_diff"  # |Post - Pre| (CHG-002)
    PERCENTAGE_CHANGE = "percentage_change"          # 100 * (Post - Pre) / (|Pre| + eps) (CHG-003)
    STANDARDIZED_CHANGE = "standardized_change"      # (Delta - mu) / sigma (CHG-004)
    DNBR_BURN_SEVERITY = "dnbr_burn_severity"        # Pre_NBR - Post_NBR (CHG-005)
    RDNBR = "rdnbr"                                  # dNBR / sqrt(|Pre_NBR|) (CHG-006)
    RBR = "rbr"                                      # dNBR / (Pre_NBR + 1.001) (CHG-007)
    CVA = "cva"                                      # Spectral Change Vector Analysis (CHG-008)
    GAIN_LOSS_THRESHOLD = "gain_loss_threshold"      # Categorical Loss/NoChange/Gain


class ChangeDetectionResult:
    """Encapsulates change detection analysis outputs and metadata."""

    def __init__(self, mode: str, output_path: str, pre_date_label: str = "", post_date_label: str = ""):
        self.mode: str = mode
        self.output_path: str = output_path
        self.pre_date_label: str = pre_date_label
        self.post_date_label: str = post_date_label
        self.statistics: Dict[str, Any] = {}
        self.gain_loss_thresholds: Tuple[float, float] = (-0.1, 0.1)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mode": self.mode,
            "output_path": self.output_path,
            "pre_date_label": self.pre_date_label,
            "post_date_label": self.post_date_label,
            "statistics": self.statistics,
            "gain_loss_thresholds": self.gain_loss_thresholds,
        }


class ChangeDetector:
    """Performs two-date index and multi-spectral comparison calculations."""

    @staticmethod
    def calculate_signed_difference(pre_arr: Any, post_arr: Any, nodata: float = -9999.0) -> Any:
        """
        CHG-001: Signed difference delta_I = Post - Pre.
        Positive indicates an increase in the index value.
        """
        if isinstance(pre_arr, list) and isinstance(post_arr, list):
            if len(pre_arr) > 0 and isinstance(pre_arr[0], list):
                return [
                    [
                        (p2 - p1 if p1 != nodata and p2 != nodata and math.isfinite(p1) and math.isfinite(p2) else nodata)
                        for p1, p2 in zip(r1, r2)
                    ]
                    for r1, r2 in zip(pre_arr, post_arr)
                ]
            return [
                (p2 - p1 if p1 != nodata and p2 != nodata and math.isfinite(p1) and math.isfinite(p2) else nodata)
                for p1, p2 in zip(pre_arr, post_arr)
            ]

        if HAS_NUMPY and isinstance(pre_arr, np.ndarray) and isinstance(post_arr, np.ndarray):
            valid_mask = (pre_arr != nodata) & (post_arr != nodata) & np.isfinite(pre_arr) & np.isfinite(post_arr)
            out = np.full(pre_arr.shape, nodata, dtype=np.float32)
            out[valid_mask] = (post_arr[valid_mask] - pre_arr[valid_mask]).astype(np.float32)
            return out
        else:
            p1, p2 = float(pre_arr), float(post_arr)
            if p1 == nodata or p2 == nodata or not math.isfinite(p1) or not math.isfinite(p2):
                return nodata
            return p2 - p1

    @staticmethod
    def calculate_absolute_difference(pre_arr: Any, post_arr: Any, nodata: float = -9999.0) -> Any:
        """
        Calculates Post - Pre (retained for exact backward compatibility with v1 test suite).
        """
        return ChangeDetector.calculate_signed_difference(pre_arr, post_arr, nodata=nodata)

    @staticmethod
    def calculate_true_magnitude(pre_arr: Any, post_arr: Any, nodata: float = -9999.0) -> Any:
        """
        CHG-002: Absolute change magnitude |Post - Pre|.
        """
        diff = ChangeDetector.calculate_signed_difference(pre_arr, post_arr, nodata=nodata)
        if isinstance(diff, list):
            if len(diff) > 0 and isinstance(diff[0], list):
                return [[(abs(v) if v != nodata and math.isfinite(v) else nodata) for v in row] for row in diff]
            return [(abs(v) if v != nodata and math.isfinite(v) else nodata) for v in diff]
        if HAS_NUMPY and isinstance(diff, np.ndarray):
            valid = (diff != nodata) & np.isfinite(diff)
            out = np.full(diff.shape, nodata, dtype=np.float32)
            out[valid] = np.abs(diff[valid]).astype(np.float32)
            return out
        return abs(diff) if diff != nodata else nodata

    @staticmethod
    def calculate_percentage_change(pre_arr: Any, post_arr: Any, eps: float = 1e-4, nodata: float = -9999.0) -> Any:
        """
        CHG-003: 100 * (Post - Pre) / (|Pre| + eps).
        """
        if isinstance(pre_arr, list) and isinstance(post_arr, list):
            def _pct(p1, p2):
                if p1 == nodata or p2 == nodata or not math.isfinite(p1) or not math.isfinite(p2) or abs(p1) <= eps:
                    return nodata
                return ((p2 - p1) / abs(p1)) * 100.0

            if len(pre_arr) > 0 and isinstance(pre_arr[0], list):
                return [[_pct(p1, p2) for p1, p2 in zip(r1, r2)] for r1, r2 in zip(pre_arr, post_arr)]
            return [_pct(p1, p2) for p1, p2 in zip(pre_arr, post_arr)]

        if HAS_NUMPY and isinstance(pre_arr, np.ndarray) and isinstance(post_arr, np.ndarray):
            valid = (pre_arr != nodata) & (post_arr != nodata) & np.isfinite(pre_arr) & np.isfinite(post_arr)
            denom = np.abs(pre_arr)
            valid &= (denom > eps)
            out = np.full(pre_arr.shape, nodata, dtype=np.float32)
            out[valid] = (((post_arr[valid] - pre_arr[valid]) / denom[valid]) * 100.0).astype(np.float32)
            return out
        else:
            p1, p2 = float(pre_arr), float(post_arr)
            if p1 == nodata or p2 == nodata or not math.isfinite(p1) or not math.isfinite(p2) or abs(p1) <= eps:
                return nodata
            return ((p2 - p1) / abs(p1)) * 100.0

    @staticmethod
    def calculate_standardized_change(
        pre_arr: Any,
        post_arr: Any,
        mu_ref: float = 0.0,
        sigma_ref: float = 1.0,
        nodata: float = -9999.0
    ) -> Any:
        """
        CHG-004: Z = (delta_I - mu_ref) / sigma_ref.
        """
        if sigma_ref <= 0.0:
            raise ValueError("Standard deviation sigma_ref must be strictly positive.")
        diff = ChangeDetector.calculate_signed_difference(pre_arr, post_arr, nodata=nodata)
        if isinstance(diff, list):
            def _std(v):
                if v == nodata or not math.isfinite(v): return nodata
                return (v - mu_ref) / sigma_ref
            if len(diff) > 0 and isinstance(diff[0], list):
                return [[_std(v) for v in row] for row in diff]
            return [_std(v) for v in diff]
        if HAS_NUMPY and isinstance(diff, np.ndarray):
            valid = (diff != nodata) & np.isfinite(diff)
            out = np.full(diff.shape, nodata, dtype=np.float32)
            out[valid] = ((diff[valid] - mu_ref) / sigma_ref).astype(np.float32)
            return out
        return (diff - mu_ref) / sigma_ref if diff != nodata else nodata

    @staticmethod
    def calculate_dnbr(nbr_pre: Any, nbr_post: Any, nodata: float = -9999.0) -> Any:
        """
        CHG-005: dNBR = NBR_pre - NBR_post.
        Enforces standard pre - post convention (Key & Benson, 2006).
        """
        if isinstance(nbr_pre, list) and isinstance(nbr_post, list):
            if len(nbr_pre) > 0 and isinstance(nbr_pre[0], list):
                return [
                    [
                        (p1 - p2 if p1 != nodata and p2 != nodata and math.isfinite(p1) and math.isfinite(p2) else nodata)
                        for p1, p2 in zip(r1, r2)
                    ]
                    for r1, r2 in zip(nbr_pre, nbr_post)
                ]
            return [
                (p1 - p2 if p1 != nodata and p2 != nodata and math.isfinite(p1) and math.isfinite(p2) else nodata)
                for p1, p2 in zip(nbr_pre, nbr_post)
            ]

        if HAS_NUMPY and isinstance(nbr_pre, np.ndarray) and isinstance(nbr_post, np.ndarray):
            valid = (nbr_pre != nodata) & (nbr_post != nodata) & np.isfinite(nbr_pre) & np.isfinite(nbr_post)
            out = np.full(nbr_pre.shape, nodata, dtype=np.float32)
            out[valid] = (nbr_pre[valid] - nbr_post[valid]).astype(np.float32)
            return out
        else:
            p1, p2 = float(nbr_pre), float(nbr_post)
            if p1 == nodata or p2 == nodata or not math.isfinite(p1) or not math.isfinite(p2):
                return nodata
            return p1 - p2

    @staticmethod
    def calculate_rdnbr(nbr_pre: Any, nbr_post: Any, eps: float = 1e-4, nodata: float = -9999.0) -> Any:
        """
        CHG-006: Relative dNBR = dNBR / sqrt(|NBR_pre|).
        Miller & Thode (2007).
        """
        dnbr = ChangeDetector.calculate_dnbr(nbr_pre, nbr_post, nodata=nodata)
        if HAS_NUMPY and isinstance(nbr_pre, np.ndarray):
            valid = (dnbr != nodata) & np.isfinite(dnbr) & (np.abs(nbr_pre) > eps)
            out = np.full(nbr_pre.shape, nodata, dtype=np.float32)
            sqrt_pre = np.sqrt(np.abs(nbr_pre[valid]))
            out[valid] = (dnbr[valid] / sqrt_pre).astype(np.float32)
            return out
        else:
            p1 = float(nbr_pre)
            if dnbr == nodata or abs(p1) <= eps:
                return nodata
            return dnbr / math.sqrt(abs(p1))

    @staticmethod
    def calculate_rbr(nbr_pre: Any, nbr_post: Any, nodata: float = -9999.0) -> Any:
        """
        CHG-007: Relativized Burn Ratio = dNBR / (NBR_pre + 1.001).
        Parks et al. (2014).
        """
        dnbr = ChangeDetector.calculate_dnbr(nbr_pre, nbr_post, nodata=nodata)
        if HAS_NUMPY and isinstance(nbr_pre, np.ndarray):
            denom = nbr_pre + 1.001
            valid = (dnbr != nodata) & np.isfinite(dnbr) & (np.abs(denom) > 1e-6)
            out = np.full(nbr_pre.shape, nodata, dtype=np.float32)
            out[valid] = (dnbr[valid] / denom[valid]).astype(np.float32)
            return out
        else:
            p1 = float(nbr_pre)
            denom = p1 + 1.001
            if dnbr == nodata or abs(denom) <= 1e-6:
                return nodata
            return dnbr / denom

    @staticmethod
    def calculate_cva(
        pre_bands: List[Any],
        post_bands: List[Any],
        weights: Optional[List[float]] = None,
        nodata: float = -9999.0
    ) -> Any:
        """
        CHG-008: Change Vector Analysis magnitude:
        CVA = sqrt( sum_j ( w_j * (post_j - pre_j)^2 ) )
        """
        if len(pre_bands) != len(post_bands) or len(pre_bands) == 0:
            raise ValueError("Pre and Post band lists must have identical non-zero lengths.")

        num_bands = len(pre_bands)
        if weights is None:
            weights = [1.0] * num_bands

        if HAS_NUMPY and isinstance(pre_bands[0], np.ndarray):
            shape = pre_bands[0].shape
            sum_sq = np.zeros(shape, dtype=np.float64)
            valid_mask = np.ones(shape, dtype=bool)

            for b_pre, b_post, w in zip(pre_bands, post_bands, weights):
                valid = (b_pre != nodata) & (b_post != nodata) & np.isfinite(b_pre) & np.isfinite(b_post)
                valid_mask &= valid
                diff = b_post.astype(np.float64) - b_pre.astype(np.float64)
                sum_sq += w * (diff ** 2)

            out = np.full(shape, nodata, dtype=np.float32)
            out[valid_mask] = np.sqrt(sum_sq[valid_mask]).astype(np.float32)
            return out
        else:
            sum_sq = 0.0
            for b1, b2, w in zip(pre_bands, post_bands, weights):
                v1, v2 = float(b1), float(b2)
                if v1 == nodata or v2 == nodata or not math.isfinite(v1) or not math.isfinite(v2):
                    return nodata
                sum_sq += w * ((v2 - v1) ** 2)
            return math.sqrt(sum_sq)

    @staticmethod
    def classify_gain_loss(
        diff_arr: Any,
        loss_threshold: float = -0.1,
        gain_threshold: float = 0.1,
        nodata_in: float = -9999.0,
        nodata_out: int = 0
    ) -> Any:
        """
        Reclassifies difference array into:
        1: Significant Loss (diff <= loss_threshold)
        2: No Significant Change (loss_threshold < diff < gain_threshold)
        3: Significant Gain (diff >= gain_threshold)
        """
        def _classify_scalar(val):
            if val == nodata_in or not math.isfinite(val):
                return nodata_out
            if val <= loss_threshold:
                return 1
            elif val >= gain_threshold:
                return 3
            return 2

        if isinstance(diff_arr, list):
            if len(diff_arr) > 0 and isinstance(diff_arr[0], list):
                return [[_classify_scalar(v) for v in row] for row in diff_arr]
            return [_classify_scalar(v) for v in diff_arr]

        if HAS_NUMPY and isinstance(diff_arr, np.ndarray):
            valid = (diff_arr != nodata_in) & np.isfinite(diff_arr)
            out = np.full(diff_arr.shape, nodata_out, dtype=np.int32)
            out[valid & (diff_arr <= loss_threshold)] = 1
            out[valid & (diff_arr > loss_threshold) & (diff_arr < gain_threshold)] = 2
            out[valid & (diff_arr >= gain_threshold)] = 3
            return out

        return _classify_scalar(float(diff_arr))

    @staticmethod
    def compute_transition_matrix(
        pre_class_arr: Any,
        post_class_arr: Any,
        classes: List[int],
        nodata_val: int = 0
    ) -> Dict[str, Any]:
        """
        CHG-009 & CHG-010: Computes transition matrix n_ij (pre -> post) and class gains/losses.
        """
        if not HAS_NUMPY or not isinstance(pre_class_arr, np.ndarray):
            return {"matrix": {}, "gains": {}, "losses": {}}

        valid = (pre_class_arr != nodata_val) & (post_class_arr != nodata_val)
        pre_valid = pre_class_arr[valid]
        post_valid = post_class_arr[valid]

        matrix: Dict[int, Dict[int, int]] = {c: {c2: 0 for c2 in classes} for c in classes}
        for c1 in classes:
            c1_mask = (pre_valid == c1)
            for c2 in classes:
                count = int(np.count_nonzero(c1_mask & (post_valid == c2)))
                matrix[c1][c2] = count

        gains = {}
        losses = {}
        for c in classes:
            gains[c] = sum(matrix[i][c] for i in classes if i != c)
            losses[c] = sum(matrix[c][j] for j in classes if j != c)

        return {
            "matrix": matrix,
            "gains": gains,
            "losses": losses,
            "total_valid_pixels": int(np.count_nonzero(valid))
        }
