"""
AriesLegacy - Radiometric State and Processing Status Contracts.
Implements radiometric state detection and invariant tracking according to
AL-ATM-BOOK-2.0 Section 1.2, 1.3, and 5.5.
"""

from enum import Enum
from typing import Dict, Any, Optional, Tuple
import os
import re


class RadiometricState(Enum):
    """
    Physical radiometric state of a raster product.
    Invariant: Never infer state from pixel ranges alone.
    """
    RAW_DN = "RAW_DN"                      # Raw quantized digital numbers (uncalibrated)
    TOA_RADIANCE = "TOA_RADIANCE"          # At-sensor spectral radiance (W m^-2 sr^-1 um^-1)
    TOA_REFLECTANCE = "TOA_REFLECTANCE"    # Top-Of-Atmosphere planetary reflectance (0.0 - 1.0)
    BOA_SCALED = "BOA_SCALED"              # Level-2 BOA Surface Reflectance stored as scaled integers
    BOA_REFLECTANCE = "BOA_REFLECTANCE"    # Surface/BOA reflectance in physical units (0.0 - 1.0)
    MANUAL_UNVERIFIED = "MANUAL_UNVERIFIED" # User-supplied raster without verified provenance
    UNKNOWN = "UNKNOWN"                    # Unrecognized product or ambiguous metadata


class CorrectionStatus(Enum):
    """
    Official processing outcome status according to AL-ATM-BOOK-2.0 Section 5.5.
    """
    EXISTING_BOA_DECODED = "EXISTING_BOA_DECODED"          # Validated L2 product; scale factor decoded
    EXISTING_BOA_ACCEPTED = "EXISTING_BOA_ACCEPTED"        # Float BOA values already verified; no rerun
    BOA_CORRECTED_VERIFIED = "BOA_CORRECTED_VERIFIED"      # L1 corrected by validated physical backend
    TOA_ONLY = "TOA_ONLY"                                  # Calibrated TOA requested by user
    BOA_UNAVAILABLE_TOA_ONLY = "BOA_UNAVAILABLE_TOA_ONLY"  # Missing backend/auxiliary blocked BOA; TOA exported
    DOS_APPROXIMATION = "DOS_APPROXIMATION"                # Exploratory Dark Object Subtraction applied
    INSUFFICIENT_METADATA = "INSUFFICIENT_METADATA"        # Sensor/level/radiometry unknown
    BACKEND_FAILED = "BACKEND_FAILED"                      # Processor returned error or invalid output


class ProductInspector:
    """
    Inspects satellite product directories, SAFE containers, and metadata files
    to determine sensor family, processing level, and radiometric state.
    """

    @staticmethod
    def inspect_path(path: str) -> Dict[str, Any]:
        """
        Inspects an input path (directory or file) and returns product metadata:
        {
            "product_path": path,
            "sensor": sensor_id,
            "level": processing_level,
            "state": RadiometricState,
            "baseline": str,
            "metadata_file": path_to_mtl_or_xml,
            "is_level2": bool,
            "confidence": "High" | "Medium" | "Low"
        }
        """
        res: Dict[str, Any] = {
            "product_path": path,
            "sensor": "generic",
            "level": "UNKNOWN",
            "state": RadiometricState.UNKNOWN,
            "baseline": "",
            "metadata_file": None,
            "is_level2": False,
            "confidence": "Low",
            "details": ""
        }

        if not path:
            res["details"] = "Empty path provided"
            return res

        norm_path = os.path.normpath(path)
        base_name = os.path.basename(norm_path).upper()
        path_exists = os.path.exists(path)

        if not path_exists:
            res["details"] = "Offline or simulated path recognized from product identifier naming conventions"
            res["confidence"] = "Medium"

        # ---------------------------------------------------------------------
        # 1. Sentinel-2 SAFE container or metadata XML
        # ---------------------------------------------------------------------
        if "MSIL2A" in base_name or "MSIL2A" in norm_path.upper() or "_L2A_" in base_name:
            res["sensor"] = "sentinel_2_l2a"
            res["level"] = "Level-2A"
            res["state"] = RadiometricState.BOA_SCALED
            res["is_level2"] = True
            res["confidence"] = "High"
            res["details"] = "Sentinel-2 Level-2A BOA Surface Reflectance product"
            # Look for MTD_MSIL2A.xml
            ProductInspector._find_s2_metadata(norm_path, res, "MSIL2A")
            return res

        if "MSIL1C" in base_name or "MSIL1C" in norm_path.upper() or "_L1C_" in base_name:
            res["sensor"] = "sentinel_2_l1c"
            res["level"] = "Level-1C"
            res["state"] = RadiometricState.TOA_REFLECTANCE
            res["is_level2"] = False
            res["confidence"] = "High"
            res["details"] = "Sentinel-2 Level-1C TOA Reflectance product"
            ProductInspector._find_s2_metadata(norm_path, res, "MSIL1C")
            return res

        # ---------------------------------------------------------------------
        # 2. Landsat Collection 2 products (MTL or scene directory)
        # ---------------------------------------------------------------------
        # Pattern: L[C|O|T|E]0[4-9]_L[1|2][S|T|A]P_...
        # L2: LC08_L2SP_..., LC09_L2SR_..., LE07_L2SP_...
        if re.search(r"L[COTE]\d{2}_L2[A-Z]{2}_", base_name) or "_L2SP_" in base_name or "_L2SR_" in base_name:
            res["sensor"] = ProductInspector._detect_landsat_sensor(base_name, level2=True)
            res["level"] = "Level-2"
            res["state"] = RadiometricState.BOA_SCALED
            res["is_level2"] = True
            res["confidence"] = "High"
            res["details"] = "Landsat Collection 2 Level-2 Surface Reflectance product"
            ProductInspector._find_landsat_mtl(norm_path, res)
            return res

        # L1: LC08_L1TP_..., LC09_L1GT_..., LE07_L1TP_...
        if re.search(r"L[COTE]\d{2}_L1[A-Z]{2}_", base_name) or "_L1TP_" in base_name or "_L1GT_" in base_name:
            res["sensor"] = ProductInspector._detect_landsat_sensor(base_name, level2=False)
            res["level"] = "Level-1"
            res["state"] = RadiometricState.RAW_DN
            res["is_level2"] = False
            res["confidence"] = "High"
            res["details"] = "Landsat Collection 2 Level-1 Calibrated DN product"
            ProductInspector._find_landsat_mtl(norm_path, res)
            return res

        # ---------------------------------------------------------------------
        # 3. NASA HLS products (Harmonized Landsat Sentinel)
        # ---------------------------------------------------------------------
        if base_name.startswith("HLS.L30") or base_name.startswith("HLS.S30"):
            res["sensor"] = "nasa_hls"
            res["level"] = "Level-30"
            res["state"] = RadiometricState.BOA_SCALED
            res["is_level2"] = True
            res["confidence"] = "High"
            res["details"] = "NASA Harmonized Landsat-Sentinel (HLS) Surface Reflectance product"
            return res

        # ---------------------------------------------------------------------
        # 4. Check contents if directory provided
        # ---------------------------------------------------------------------
        if os.path.isdir(norm_path):
            files = os.listdir(norm_path)
            for f in files:
                f_upper = f.upper()
                if "MTD_MSIL2A.XML" in f_upper:
                    res["sensor"] = "sentinel_2_l2a"
                    res["level"] = "Level-2A"
                    res["state"] = RadiometricState.BOA_SCALED
                    res["is_level2"] = True
                    res["confidence"] = "High"
                    res["metadata_file"] = os.path.join(norm_path, f)
                    return res
                elif "MTD_MSIL1C.XML" in f_upper:
                    res["sensor"] = "sentinel_2_l1c"
                    res["level"] = "Level-1C"
                    res["state"] = RadiometricState.TOA_REFLECTANCE
                    res["is_level2"] = False
                    res["confidence"] = "High"
                    res["metadata_file"] = os.path.join(norm_path, f)
                    return res
                elif f_upper.endswith("_MTL.TXT"):
                    mtl_file = os.path.join(norm_path, f)
                    res["metadata_file"] = mtl_file
                    if "_L2" in f_upper:
                        res["sensor"] = ProductInspector._detect_landsat_sensor(f_upper, level2=True)
                        res["level"] = "Level-2"
                        res["state"] = RadiometricState.BOA_SCALED
                        res["is_level2"] = True
                        res["confidence"] = "High"
                    else:
                        res["sensor"] = ProductInspector._detect_landsat_sensor(f_upper, level2=False)
                        res["level"] = "Level-1"
                        res["state"] = RadiometricState.RAW_DN
                        res["is_level2"] = False
                        res["confidence"] = "High"
                    return res

        # Fallback if single TIFF without original metadata
        if base_name.endswith((".TIF", ".TIFF")):
            if "_SR_" in base_name or "_BOA" in base_name:
                res["state"] = RadiometricState.BOA_SCALED
                res["level"] = "Level-2"
                res["is_level2"] = True
                res["confidence"] = "Medium"
                res["details"] = "Filename indicates Surface Reflectance (SR/BOA)"
            elif "_TOA" in base_name:
                res["state"] = RadiometricState.TOA_REFLECTANCE
                res["level"] = "Level-1"
                res["is_level2"] = False
                res["confidence"] = "Medium"
                res["details"] = "Filename indicates Top-Of-Atmosphere Reflectance (TOA)"
            else:
                res["state"] = RadiometricState.MANUAL_UNVERIFIED
                res["confidence"] = "Low"
                res["details"] = "Standalone raster without sidecar metadata. Requires user verification."

        return res

    @staticmethod
    def _detect_landsat_sensor(name: str, level2: bool = True) -> str:
        suffix = "l2" if level2 else "l1"
        if "LC08" in name or "LC09" in name:
            return f"landsat_8_{suffix}"
        elif "LE07" in name:
            return f"landsat_7_{suffix}"
        elif "LT05" in name or "LT04" in name:
            return f"landsat_5_{suffix}"
        return f"landsat_8_{suffix}"

    @staticmethod
    def _find_s2_metadata(norm_path: str, res: Dict[str, Any], prefix: str):
        search_dir = norm_path if os.path.isdir(norm_path) else os.path.dirname(norm_path)
        if not os.path.exists(search_dir):
            return
        target = f"MTD_{prefix}.xml".upper()
        for root, _, files in os.walk(search_dir):
            for f in files:
                if f.upper() == target or f.upper().startswith(f"MTD_{prefix}"):
                    res["metadata_file"] = os.path.join(root, f)
                    return

    @staticmethod
    def _find_landsat_mtl(norm_path: str, res: Dict[str, Any]):
        search_dir = norm_path if os.path.isdir(norm_path) else os.path.dirname(norm_path)
        if not os.path.exists(search_dir):
            return
        for root, _, files in os.walk(search_dir):
            for f in files:
                if f.upper().endswith("_MTL.TXT"):
                    res["metadata_file"] = os.path.join(root, f)
                    return
