"""
AriesLegacy - Satellite Metadata Parser.
Extracts radiometric calibration parameters, solar angles, processing baselines,
acquisition dates, and QA layers from Landsat MTL and Sentinel-2 SAFE XML files.
"""

import os
import re
from typing import Dict, Optional, Any


class LandsatMTLParser:
    """Parses Landsat Collection 2 Level-1 and Level-2 *_MTL.txt files."""

    @staticmethod
    def parse_file(mtl_path: str) -> Dict[str, Any]:
        """Parses a text MTL file into a hierarchical dictionary."""
        metadata: Dict[str, Any] = {}
        if not os.path.exists(mtl_path):
            return metadata

        current_group = metadata
        group_stack = []

        with open(mtl_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line or line == "END":
                    continue

                if line.startswith("GROUP = "):
                    group_name = line.split("=", 1)[1].strip()
                    new_group: Dict[str, Any] = {}
                    current_group[group_name] = new_group
                    group_stack.append(current_group)
                    current_group = new_group
                elif line.startswith("END_GROUP = "):
                    if group_stack:
                        current_group = group_stack.pop()
                elif "=" in line:
                    key, val = line.split("=", 1)
                    key = key.strip()
                    val = val.strip().strip('"')

                    # Parse float or int if possible
                    try:
                        if "." in val or "e" in val.lower():
                            parsed_val: Any = float(val)
                        else:
                            parsed_val = int(val)
                    except ValueError:
                        parsed_val = val

                    current_group[key] = parsed_val

        return metadata

    @staticmethod
    def extract_calibration_parameters(metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Extracts key radiometric, thermal, and solar parameters from parsed MTL."""
        res: Dict[str, Any] = {
            "spacecraft_id": "",
            "sensor_id": "",
            "date_acquired": "",
            "sun_elevation": None,
            "sun_azimuth": None,
            "radiance_mult": {},
            "radiance_add": {},
            "reflectance_mult": {},
            "reflectance_add": {},
            "thermal_k1": {},
            "thermal_k2": {},
        }

        # Search groups recursively
        def _search(d: Dict[str, Any]):
            for k, v in d.items():
                if isinstance(v, dict):
                    _search(v)
                else:
                    k_upper = k.upper()
                    if k_upper == "SPACECRAFT_ID":
                        res["spacecraft_id"] = str(v)
                    elif k_upper == "SENSOR_ID":
                        res["sensor_id"] = str(v)
                    elif k_upper == "DATE_ACQUIRED":
                        res["date_acquired"] = str(v)
                    elif k_upper == "SUN_ELEVATION":
                        res["sun_elevation"] = float(v)
                    elif k_upper == "SUN_AZIMUTH":
                        res["sun_azimuth"] = float(v)
                    elif k_upper.startswith("RADIANCE_MULT_BAND_"):
                        band_num = k_upper.replace("RADIANCE_MULT_BAND_", "")
                        res["radiance_mult"][band_num] = float(v)
                    elif k_upper.startswith("RADIANCE_ADD_BAND_"):
                        band_num = k_upper.replace("RADIANCE_ADD_BAND_", "")
                        res["radiance_add"][band_num] = float(v)
                    elif k_upper.startswith("REFLECTANCE_MULT_BAND_"):
                        band_num = k_upper.replace("REFLECTANCE_MULT_BAND_", "")
                        res["reflectance_mult"][band_num] = float(v)
                    elif k_upper.startswith("REFLECTANCE_ADD_BAND_"):
                        band_num = k_upper.replace("REFLECTANCE_ADD_BAND_", "")
                        res["reflectance_add"][band_num] = float(v)
                    elif k_upper.startswith("K1_CONSTANT_BAND_"):
                        band_num = k_upper.replace("K1_CONSTANT_BAND_", "")
                        res["thermal_k1"][band_num] = float(v)
                    elif k_upper.startswith("K2_CONSTANT_BAND_"):
                        band_num = k_upper.replace("K2_CONSTANT_BAND_", "")
                        res["thermal_k2"][band_num] = float(v)

        _search(metadata)
        return res


class Sentinel2SAFEParser:
    """Parses Sentinel-2 MTD_MSIL1C.xml / MTD_MSIL2A.xml metadata."""

    @staticmethod
    def parse_metadata_xml(xml_path: str) -> Dict[str, Any]:
        """Parses processing baseline and quantification / BOA offsets from Sentinel-2 XML."""
        try:
            import defusedxml.ElementTree as ET  # type: ignore
        except ImportError:
            import xml.etree.ElementTree as ET  # nosec B405

        res: Dict[str, Any] = {
            "product_type": "",
            "processing_baseline": "",
            "quantification_value": 10000.0,
            "boa_add_offsets": {},
            "radio_add_offsets": {},
            "cloud_percentage": None,
            "acquisition_date": ""
        }

        if not os.path.exists(xml_path):
            return res

        try:
            tree = ET.parse(xml_path)  # nosec B314
            root = tree.getroot()

            for elem in root.iter():
                tag = elem.tag.split("}")[-1]  # Strip XML namespace
                if tag == "PROCESSING_BASELINE" and elem.text:
                    res["processing_baseline"] = elem.text.strip()
                elif tag == "PRODUCT_TYPE" and elem.text:
                    res["product_type"] = elem.text.strip()
                elif tag == "QUANTIFICATION_VALUE" and elem.text:
                    try:
                        res["quantification_value"] = float(elem.text.strip())
                    except ValueError:
                        pass
                elif tag == "Cloud_Coverage_Assessment" and elem.text:
                    try:
                        res["cloud_percentage"] = float(elem.text.strip())
                    except ValueError:
                        pass
                elif tag == "PRODUCT_START_TIME" and elem.text:
                    res["acquisition_date"] = elem.text.strip()

                # Offsets (Baseline 04.00+)
                if tag == "BOA_ADD_OFFSET" and elem.text:
                    band_id = elem.attrib.get("band_id", "default")
                    try:
                        res["boa_add_offsets"][band_id] = float(elem.text.strip())
                    except ValueError:
                        pass
                elif tag == "RADIO_ADD_OFFSET" and elem.text:
                    band_id = elem.attrib.get("band_id", "default")
                    try:
                        res["radio_add_offsets"][band_id] = float(elem.text.strip())
                    except ValueError:
                        pass
        except Exception as e:
            print(f"[AriesLegacy] Error parsing S2 XML: {e}")

        return res

