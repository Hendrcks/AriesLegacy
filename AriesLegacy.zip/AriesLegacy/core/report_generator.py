"""
AriesLegacy - Report Generator.
Generates comprehensive Markdown and HTML scientific method, interpretation, and audit reports.
Integrates official AriesLegacy spectral satellite logo branding and scientific provenance.
"""

import os
import base64
from datetime import datetime
from typing import Dict, List, Optional, Any

from .index_library import IndexDefinition
from .sensor_profiles import SensorProfile
from .area_statistics import AreaStatisticsResult


class ReportMetadata:
    """Stores contextual metadata for analysis reports."""

    def __init__(
        self,
        title: str = "Satellite Spectral Analysis & Scientific Audit Report",
        study_area: str = "Study Area",
        analyst: str = "Remote Sensing Analyst",
        organization: str = "AriesPlus Geospatial Solutions",
        notes: str = "",
        input_scene_ids: Optional[List[str]] = None,
        checksums: Optional[Dict[str, str]] = None,
        valid_pixel_fraction: Optional[float] = None
    ):
        self.title: str = title
        self.study_area: str = study_area
        self.analyst: str = analyst
        self.organization: str = organization
        self.notes: str = notes
        self.input_scene_ids: List[str] = input_scene_ids or []
        self.checksums: Dict[str, str] = checksums or {}
        self.valid_pixel_fraction: Optional[float] = valid_pixel_fraction
        self.timestamp: str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class ReportGenerator:
    """Generates styled HTML and Markdown analysis reports."""

    @staticmethod
    def _get_logo_base64() -> str:
        """Loads and encodes official logo banner as base64 string."""
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        logo_path = os.path.join(base_dir, "icons", "arieslegacy_logo.png")
        if not os.path.exists(logo_path):
            logo_path = os.path.join(base_dir, "icons", "logo.png")

        if os.path.exists(logo_path):
            try:
                with open(logo_path, "rb") as f:
                    return base64.b64encode(f.read()).decode("ascii")
            except (OSError, IOError):
                pass
        return ""

    @staticmethod
    def generate_markdown_report(
        metadata: ReportMetadata,
        index_def: IndexDefinition,
        sensor_profile: SensorProfile,
        band_mappings: Dict[str, str],
        stats_result: Optional[AreaStatisticsResult] = None,
        continuous_stats: Optional[Dict[str, float]] = None,
        output_file_path: Optional[str] = None
    ) -> str:
        """Generates a GitHub-flavored Markdown report."""
        lines = [
            f"# {metadata.title}",
            f"**Study Area:** {metadata.study_area}  ",
            f"**Analyst / Organization:** {metadata.analyst} ({metadata.organization})  ",
            f"**Date Generated:** {metadata.timestamp}  ",
            f"**Software:** AriesLegacy 2.0 (Scientific Remote Sensing Workbench)  ",
            "\n---\n",
            "## 1. Executive Summary",
            f"This report documents the scientific spectral index analysis conducted for **{metadata.study_area}** using the **{index_def.name} ({index_def.short_name})**.",
            f"\n> **Index Description & Purpose:** {index_def.description}\n",
            "## 2. Sensor & Radiometric Calibration",
            f"- **Sensor Platform:** {sensor_profile.name} ({sensor_profile.agency})",
            f"- **Sensor ID:** `{sensor_profile.id}`",
            f"- **Processing Level:** `{sensor_profile.processing_level or sensor_profile.level}`",
            f"- **Radiometric Scale Factor:** `{sensor_profile.scale_factor}`",
            f"- **Offset:** `{sensor_profile.offset}`",
        ]

        if metadata.valid_pixel_fraction is not None:
            lines.append(f"- **Valid Analysis Coverage:** `{metadata.valid_pixel_fraction * 100.0:.2f}%`")

        if metadata.input_scene_ids:
            lines.append(f"- **Input Scene IDs:** {', '.join(metadata.input_scene_ids)}")

        lines.extend([
            "\n### Band Mappings Applied",
            "| Canonical Variable | Source Layer / Band Assignment |",
            "| :--- | :--- |"
        ])

        for canon, src in band_mappings.items():
            lines.append(f"| **{canon}** | `{src}` |")

        lines.extend([
            "\n## 3. Mathematical Formula & Literature Reference",
            f"$$\\text{{{index_def.short_name}}} = {index_def.formula}$$",
            f"\n- **Standard ID:** `{index_def.standard_id}`",
            f"- **Safe Evaluation Expression:** `{index_def.safe_formula}`",
            f"- **Scientific Reference:** *{index_def.reference}*",
            "\n## 4. Results & Area Statistics"
        ])

        if continuous_stats:
            lines.extend([
                "\n### Continuous Index Distribution",
                f"- **Valid Pixels:** {continuous_stats.get('valid_pixel_count', 0):,}",
                f"- **Minimum Value:** {continuous_stats.get('min', 0.0):.4f}",
                f"- **Maximum Value:** {continuous_stats.get('max', 0.0):.4f}",
                f"- **Mean:** {continuous_stats.get('mean', 0.0):.4f} (± {continuous_stats.get('std', 0.0):.4f})",
                f"- **Median:** {continuous_stats.get('median', 0.0):.4f}",
            ])

        if stats_result and stats_result.classes:
            lines.extend([
                "\n### Thematic Classification & Area Breakdown",
                "| Class ID | Thematic Label | Pixel Count | Area (Hectares) | Area (km²) | Coverage (%) |",
                "| :---: | :--- | :---: | :---: | :---: | :---: |"
            ])
            for c in stats_result.classes:
                lines.append(f"| {c.class_id} | {c.label} | {c.pixel_count:,} | {c.area_ha:.2f} ha | {c.area_km2:.3f} km² | {c.percentage:.2f}% |")
            lines.append(f"| **Total** | **All Classified Area** | **{stats_result.total_valid_pixels:,}** | **{stats_result.total_area_ha:.2f} ha** | **{stats_result.total_area_km2:.3f} km²** | **100.00%** |")

        if metadata.notes:
            lines.extend([
                "\n## 5. Analyst Notes & Interpretation",
                metadata.notes
            ])

        lines.extend([
            "\n## 6. Scientific QA & Reproducibility Guardrails",
            "> 1. **Calibration & Surface Reflectance:** Calibrated physical surface reflectance is required for temporal comparability.",
            "> 2. **Atmospheric & Cloud Masking:** Atmospheric effects and undetected clouds can contaminate reflectance.",
            "> 3. **Spatial Scale & Mixed Pixels:** Pixel resolution dictates mapping bounds. Mixed pixels can produce intermediate values."
        ])

        content = "\n".join(lines)
        if output_file_path:
            with open(output_file_path, "w", encoding="utf-8") as f:
                f.write(content)

        return content

    @staticmethod
    def generate_html_report(
        metadata: ReportMetadata,
        index_def: IndexDefinition,
        sensor_profile: SensorProfile,
        band_mappings: Dict[str, str],
        stats_result: Optional[AreaStatisticsResult] = None,
        continuous_stats: Optional[Dict[str, float]] = None,
        output_file_path: Optional[str] = None
    ) -> str:
        """Generates a standalone styled HTML report with official logo branding and print-ready CSS."""
        logo_b64 = ReportGenerator._get_logo_base64()
        logo_tag = f'<img src="data:image/png;base64,{logo_b64}" alt="AriesLegacy" style="max-height: 55px; margin-bottom: 12px;">' if logo_b64 else '<h2 style="color:#0284c7; margin:0 0 10px 0;">AriesLegacy</h2>'

        table_rows_html = ""
        if stats_result and stats_result.classes:
            for c in stats_result.classes:
                table_rows_html += f"""
                <tr>
                    <td style="text-align: center;"><span style="display:inline-block; width:12px; height:12px; background-color:{c.color}; border-radius:2px; margin-right:6px;"></span>{c.class_id}</td>
                    <td><strong>{c.label}</strong></td>
                    <td style="text-align: right;">{c.pixel_count:,}</td>
                    <td style="text-align: right;">{c.area_ha:,.2f} ha</td>
                    <td style="text-align: right;">{c.area_km2:,.3f} km²</td>
                    <td style="text-align: right;"><strong>{c.percentage:.2f}%</strong></td>
                </tr>"""
            table_rows_html += f"""
                <tr style="background:#f1f5f9; font-weight:bold;">
                    <td colspan="2">TOTAL VALID AREA</td>
                    <td style="text-align: right;">{stats_result.total_valid_pixels:,}</td>
                    <td style="text-align: right;">{stats_result.total_area_ha:,.2f} ha</td>
                    <td style="text-align: right;">{stats_result.total_area_km2:,.3f} km²</td>
                    <td style="text-align: right;">100.00%</td>
                </tr>"""

        bands_rows_html = ""
        for canon, src in band_mappings.items():
            bands_rows_html += f"<tr><td><strong>{canon}</strong></td><td><code>{src}</code></td></tr>"

        cont_html = ""
        if continuous_stats:
            cont_html = f"""
            <div class="stats-grid">
                <div class="stat-card"><span class="stat-label">Min</span><span class="stat-val">{continuous_stats.get('min', 0.0):.3f}</span></div>
                <div class="stat-card"><span class="stat-label">Max</span><span class="stat-val">{continuous_stats.get('max', 0.0):.3f}</span></div>
                <div class="stat-card"><span class="stat-label">Mean</span><span class="stat-val">{continuous_stats.get('mean', 0.0):.3f}</span></div>
                <div class="stat-card"><span class="stat-label">Std Dev</span><span class="stat-val">±{continuous_stats.get('std', 0.0):.3f}</span></div>
            </div>"""

        coverage_info = ""
        if metadata.valid_pixel_fraction is not None:
            coverage_info = f'<span><strong>Valid Coverage:</strong> {metadata.valid_pixel_fraction * 100.0:.2f}%</span>'

        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{metadata.title}</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #f8fafc; color: #1e293b; margin: 0; padding: 30px; }}
        .container {{ max-width: 920px; margin: 0 auto; background: #ffffff; padding: 40px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.06); }}
        .header {{ border-bottom: 2px solid #0284c7; padding-bottom: 20px; margin-bottom: 30px; }}
        .header h1 {{ margin: 10px 0 10px 0; color: #0f172a; font-size: 24px; }}
        .meta-bar {{ display: flex; flex-wrap: wrap; gap: 15px; font-size: 13px; color: #64748b; }}
        .badge {{ background: #e0f2fe; color: #0369a1; padding: 4px 10px; border-radius: 6px; font-weight: 600; }}
        h2 {{ color: #0f172a; font-size: 18px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-top: 30px; }}
        table {{ width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 14px; }}
        th, td {{ padding: 10px 14px; border: 1px solid #e2e8f0; text-align: left; }}
        th {{ background: #f8fafc; color: #475569; font-weight: 600; }}
        .formula-box {{ background: #f1f5f9; padding: 15px; border-radius: 8px; border-left: 4px solid #0284c7; font-family: monospace; font-size: 15px; margin: 15px 0; }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin: 15px 0; }}
        .stat-card {{ background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px; border-radius: 8px; text-align: center; }}
        .stat-label {{ display: block; font-size: 12px; color: #64748b; }}
        .stat-val {{ font-size: 18px; font-weight: 700; color: #0f172a; }}
        .alert-box {{ background: #fffbeb; border-left: 4px solid #f59e0b; padding: 15px; border-radius: 8px; font-size: 13px; color: #92400e; margin: 20px 0; }}
        .footer {{ margin-top: 40px; padding-top: 15px; border-top: 1px solid #e2e8f0; font-size: 12px; color: #94a3b8; text-align: center; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            {logo_tag}
            <h1>{metadata.title}</h1>
            <div class="meta-bar">
                <span><strong>Study Area:</strong> {metadata.study_area}</span>
                <span><strong>Analyst:</strong> {metadata.analyst}</span>
                <span><strong>Organization:</strong> {metadata.organization}</span>
                {coverage_info}
                <span class="badge">{metadata.timestamp}</span>
            </div>
        </div>

        <h2>1. Index & Sensor Definition</h2>
        <p><strong>{index_def.name} ({index_def.short_name}) &mdash; {index_def.standard_id}</strong>: {index_def.description}</p>
        <div class="formula-box">
            <strong>Formula:</strong> {index_def.short_name} = {index_def.formula}<br>
            <small style="color: #64748b;">Safe execution: {index_def.safe_formula}</small>
        </div>
        <p><small><strong>Reference:</strong> {index_def.reference}</small></p>

        <h2>2. Data Sources & Radiometric Mappings</h2>
        <p><strong>Sensor Platform:</strong> {sensor_profile.name} ({sensor_profile.agency}) &bull; Level: <code>{sensor_profile.processing_level or sensor_profile.level}</code></p>
        <table>
            <thead>
                <tr><th>Canonical Variable</th><th>Mapped Layer / Source</th></tr>
            </thead>
            <tbody>
                {bands_rows_html}
            </tbody>
        </table>

        <h2>3. Results & Classification Area</h2>
        {cont_html}
        <table>
            <thead>
                <tr>
                    <th style="text-align: center;">ID</th>
                    <th>Thematic Class</th>
                    <th style="text-align: right;">Pixels</th>
                    <th style="text-align: right;">Area (ha)</th>
                    <th style="text-align: right;">Area (km²)</th>
                    <th style="text-align: right;">Coverage</th>
                </tr>
            </thead>
            <tbody>
                {table_rows_html}
            </tbody>
        </table>

        <div class="alert-box">
            <strong>Scientific Quality Assurance:</strong> Calculations are performed in floating-point surface reflectance. Cloud, shadow, aerosol saturation, and seasonal phenology must be verified against QA masks and local reference sampling.
        </div>

        <div class="footer">
            AriesLegacy 2.0 &bull; Scientific Satellite Remote Sensing & Change Detection Workbench &bull; AriesPlus Geospatial Solutions
        </div>
    </div>
</body>
</html>"""

        if output_file_path:
            with open(output_file_path, "w", encoding="utf-8") as f:
                f.write(html_content)

        return html_content
