"""
AriesLegacy - Safe AST Formula Parser.
Strictly parses and executes arithmetic expressions without using Python eval().
Supports Float32 NumPy arrays and scalars with safe divide and boundary checks.
"""

import ast
import math
from typing import Dict, List, Set, Any, Union

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None


class FormulaSecurityError(Exception):
    """Raised when an expression contains forbidden AST nodes or identifiers."""
    pass


class SafeFormulaParser:
    """
    Parses and evaluates mathematical formula strings safely using Python's ast module.
    Never calls eval() or exec().
    """

    ALLOWED_FUNCTIONS = {
        "sqrt": lambda x: np.sqrt(np.maximum(x, 0.0)) if HAS_NUMPY and isinstance(x, np.ndarray) else (math.sqrt(max(float(x), 0.0)) if x >= 0 else 0.0),
        "abs": lambda x: np.abs(x) if HAS_NUMPY and isinstance(x, np.ndarray) else abs(float(x)),
        "max": lambda a, b: np.maximum(a, b) if HAS_NUMPY and (isinstance(a, np.ndarray) or isinstance(b, np.ndarray)) else max(float(a), float(b)),
        "min": lambda a, b: np.minimum(a, b) if HAS_NUMPY and (isinstance(a, np.ndarray) or isinstance(b, np.ndarray)) else min(float(a), float(b)),
        "log": lambda x: np.log(np.maximum(x, 1e-8)) if HAS_NUMPY and isinstance(x, np.ndarray) else math.log(max(float(x), 1e-8)),
        "exp": lambda x: np.exp(x) if HAS_NUMPY and isinstance(x, np.ndarray) else math.exp(float(x)),
        "sin": lambda x: np.sin(x) if HAS_NUMPY and isinstance(x, np.ndarray) else math.sin(float(x)),
        "cos": lambda x: np.cos(x) if HAS_NUMPY and isinstance(x, np.ndarray) else math.cos(float(x)),
        "safe_divide": lambda num, den: SafeFormulaParser._safe_divide(num, den),
    }

    @staticmethod
    def _safe_divide(num: Any, den: Any, eps: float = 1e-8, nodata: float = -9999.0) -> Any:
        if HAS_NUMPY and (isinstance(num, np.ndarray) or isinstance(den, np.ndarray)):
            num_arr = np.asarray(num, dtype=np.float64)
            den_arr = np.asarray(den, dtype=np.float64)
            out = np.full(num_arr.shape, nodata, dtype=np.float32)
            valid = np.isfinite(num_arr) & np.isfinite(den_arr) & (np.abs(den_arr) > eps)
            np.divide(num_arr, den_arr, out=out, where=valid)
            return out
        else:
            n, d = float(num), float(den)
            if not math.isfinite(n) or not math.isfinite(d) or abs(d) <= eps:
                return nodata
            return n / d

    @classmethod
    def extract_variables(cls, expression: str) -> List[str]:
        """Parses expression and returns unique variable identifier names."""
        try:
            tree = ast.parse(expression, mode="eval")
        except SyntaxError as e:
            raise FormulaSecurityError(f"Syntax error in formula: {e}")

        variables: Set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Name):
                if node.id not in cls.ALLOWED_FUNCTIONS:
                    variables.add(node.id)
        return sorted(list(variables))

    @classmethod
    def validate_expression(cls, expression: str) -> bool:
        """Validates that expression contains only permitted mathematical nodes."""
        try:
            tree = ast.parse(expression, mode="eval")
        except SyntaxError as e:
            raise FormulaSecurityError(f"Syntax error: {e}")

        for node in ast.walk(tree):
            # Allowed node types
            if isinstance(node, (
                ast.Expression, ast.BinOp, ast.UnaryOp, ast.Call,
                ast.Constant, ast.Name, ast.Load,
                ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod,
                ast.USub, ast.UAdd
            )):
                if isinstance(node, ast.Call):
                    if not isinstance(node.func, ast.Name) or node.func.id not in cls.ALLOWED_FUNCTIONS:
                        raise FormulaSecurityError(f"Disallowed function call: {ast.dump(node.func)}")
            elif hasattr(ast, "Num") and isinstance(node, ast.Num):  # Python < 3.8 compat
                pass
            else:
                raise FormulaSecurityError(f"Disallowed expression node: {type(node).__name__}")
        return True

    @classmethod
    def evaluate(cls, expression: str, variables: Dict[str, Any], nodata_val: float = -9999.0) -> Any:
        """
        Safely evaluates an expression against supplied variable values (scalars or NumPy arrays).
        """
        cls.validate_expression(expression)
        tree = ast.parse(expression, mode="eval")

        # Standardize variable lookup keys (case-insensitive fallback)
        var_map = {k: v for k, v in variables.items()}
        for k, v in variables.items():
            var_map[k.upper()] = v
            var_map[k.lower()] = v

        def _eval_node(node: ast.AST) -> Any:
            if isinstance(node, ast.Constant):
                return float(node.value)
            elif hasattr(ast, "Num") and isinstance(node, ast.Num):
                return float(node.n)
            elif isinstance(node, ast.Name):
                name = node.id
                if name in var_map:
                    return var_map[name]
                elif name.upper() in var_map:
                    return var_map[name.upper()]
                elif name.lower() in var_map:
                    return var_map[name.lower()]
                raise FormulaSecurityError(f"Variable '{name}' not found in supplied inputs.")
            elif isinstance(node, ast.UnaryOp):
                operand = _eval_node(node.operand)
                if isinstance(node.op, ast.USub):
                    return -operand
                elif isinstance(node.op, ast.UAdd):
                    return operand
                raise FormulaSecurityError(f"Unsupported unary operator: {type(node.op).__name__}")
            elif isinstance(node, ast.BinOp):
                left = _eval_node(node.left)
                right = _eval_node(node.right)
                if isinstance(node.op, ast.Add):
                    return left + right
                elif isinstance(node.op, ast.Sub):
                    return left - right
                elif isinstance(node.op, ast.Mult):
                    return left * right
                elif isinstance(node.op, ast.Div):
                    return cls._safe_divide(left, right, nodata=nodata_val)
                elif isinstance(node.op, ast.Pow):
                    if HAS_NUMPY and (isinstance(left, np.ndarray) or isinstance(right, np.ndarray)):
                        return np.power(left, right)
                    return left ** right
                elif isinstance(node.op, ast.Mod):
                    return left % right
                raise FormulaSecurityError(f"Unsupported binary operator: {type(node.op).__name__}")
            elif isinstance(node, ast.Call):
                func_name = node.func.id  # type: ignore
                fn = cls.ALLOWED_FUNCTIONS.get(func_name)
                if not fn:
                    raise FormulaSecurityError(f"Unsupported function '{func_name}'")
                args = [_eval_node(a) for a in node.args]
                return fn(*args)
            elif isinstance(node, ast.Expression):
                return _eval_node(node.body)
            else:
                raise FormulaSecurityError(f"Unexpected AST node: {type(node).__name__}")

        return _eval_node(tree.body)

