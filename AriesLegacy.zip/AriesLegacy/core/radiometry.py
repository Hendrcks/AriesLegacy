"""
AriesLegacy - Radiometry and Atmospheric Preprocessing Engine.
Implements PRE-001 through PRE-017 from the AriesLegacy v2 Scientific Specification.
Handles DN to TOA Radiance, TOA Reflectance, Surface Reflectance decoding,
Atmospheric radiative transfer inversion, thermal brightness/surface temperature,
and QA bitmask decoding.
"""

import math
from typing import Dict, List, Optional, Tuple, Any, Union

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None


class RadiometryError(Exception):
    """Raised when radiometric parameters are invalid or missing."""
    pass


class RadiometryEngine:
    """Core mathematical and scientific algorithms for radiometric operations."""

    # -------------------------------------------------------------------------
    # PRE-001: Landsat Level-1 DN to TOA Spectral Radiance
    # -------------------------------------------------------------------------
    @staticmethod
    def landsat_l1_dn_to_radiance(
        dn: Any,
        gain_m_l: float,
        offset_a_l: float,
        nodata_dn: int = 0,
        nodata_out: float = -9999.0
    ) -> Any:
        """
        PRE-001: L_lambda = M_L * Q_cal + A_L
        Returns Float32 spectral radiance in W m^-2 sr^-1 um^-1.
        """
        if gain_m_l is None or not math.isfinite(gain_m_l):
            raise RadiometryError("Invalid or missing RADIANCE_MULT_BAND gain (M_L).")
        if offset_a_l is None or not math.isfinite(offset_a_l):
            raise RadiometryError("Invalid or missing RADIANCE_ADD_BAND offset (A_L).")

        if HAS_NUMPY and isinstance(dn, np.ndarray):
            out = np.full(dn.shape, nodata_out, dtype=np.float32)
            valid = (dn != nodata_dn) & np.isfinite(dn) & (dn > 0)
            np.add(gain_m_l * dn.astype(np.float64), offset_a_l, out=out, where=valid)
            return out
        else:
            dn_val = float(dn)
            if dn_val == nodata_dn or not math.isfinite(dn_val) or dn_val <= 0:
                return nodata_out
            return gain_m_l * dn_val + offset_a_l

    # -------------------------------------------------------------------------
    # PRE-002: Landsat Level-1 DN to TOA Reflectance
    # -------------------------------------------------------------------------
    @staticmethod
    def landsat_l1_dn_to_toa_reflectance(
        dn: Any,
        gain_m_rho: Optional[float] = None,
        offset_a_rho: Optional[float] = None,
        sun_elevation_deg: float = 45.0,
        nodata_dn: int = 0,
        nodata_out: float = -9999.0,
        mult_rho: Optional[float] = None,
        add_rho: Optional[float] = None
    ) -> Any:
        """
        PRE-002: rho_TOA = (M_rho * Q_cal + A_rho) / sin(theta_SE)
        where theta_SE is sun elevation in degrees.
        """
        m_rho = gain_m_rho if gain_m_rho is not None else (mult_rho if mult_rho is not None else 0.00002)
        a_rho = offset_a_rho if offset_a_rho is not None else (add_rho if add_rho is not None else -0.1)

        if sun_elevation_deg <= 0.0 or sun_elevation_deg > 90.0:
            raise RadiometryError(f"Invalid solar elevation angle: {sun_elevation_deg} deg.")
        sin_se = math.sin(math.radians(sun_elevation_deg))
        if sin_se <= 1e-6:
            raise RadiometryError("Solar elevation sine is zero or negative.")

        if HAS_NUMPY and isinstance(dn, np.ndarray):
            out = np.full(dn.shape, nodata_out, dtype=np.float32)
            valid = (dn != nodata_dn) & np.isfinite(dn) & (dn > 0)
            uncorrected = m_rho * dn.astype(np.float64) + a_rho
            np.divide(uncorrected, sin_se, out=out, where=valid)
            return out
        else:
            dn_val = float(dn)
            if dn_val == nodata_dn or not math.isfinite(dn_val) or dn_val <= 0:
                return nodata_out
            return (m_rho * dn_val + a_rho) / sin_se

    # -------------------------------------------------------------------------
    # PRE-003: Radiance to TOA Reflectance (Irradiance route)
    # -------------------------------------------------------------------------
    @staticmethod
    def radiance_to_toa_reflectance(
        radiance: Any,
        esun_lambda: float,
        earth_sun_dist_au: float,
        sun_zenith_deg: float,
        nodata_out: float = -9999.0
    ) -> Any:
        """
        PRE-003: rho_TOA = (pi * L_lambda * d_AU^2) / (ESUN_lambda * cos(theta_SZ))
        """
        cos_sz = math.cos(math.radians(sun_zenith_deg))
        if cos_sz <= 1e-6 or esun_lambda <= 0.0:
            raise RadiometryError("Invalid solar geometry or ESUN irradiance.")

        factor = (math.pi * (earth_sun_dist_au ** 2)) / (esun_lambda * cos_sz)

        if HAS_NUMPY and isinstance(radiance, np.ndarray):
            out = np.full(radiance.shape, nodata_out, dtype=np.float32)
            valid = (radiance != nodata_out) & np.isfinite(radiance) & (radiance >= 0.0)
            np.multiply(radiance.astype(np.float64), factor, out=out, where=valid)
            return out
        else:
            r_val = float(radiance)
            if r_val == nodata_out or not math.isfinite(r_val) or r_val < 0.0:
                return nodata_out
            return r_val * factor

    # -------------------------------------------------------------------------
    # PRE-004: Sentinel-2 Level-1C DN to TOA Reflectance
    # -------------------------------------------------------------------------
    @staticmethod
    def sentinel2_l1c_dn_to_toa(
        dn: Any,
        radio_add_offset: float = 0.0,
        quantification_value: float = 10000.0,
        nodata_dn: int = 0,
        nodata_out: float = -9999.0
    ) -> Any:
        """
        PRE-004: rho_TOA_i = (DN_i + RADIO_ADD_OFFSET_i) / QUANTIFICATION_VALUE
        Pre-baseline 04.00 has RADIO_ADD_OFFSET = 0.
        Baseline 04.00+ introduces negative additive offset (typically -1000 DN).
        """
        if quantification_value <= 0:
            raise RadiometryError("Quantification value must be strictly positive.")

        if HAS_NUMPY and isinstance(dn, np.ndarray):
            out = np.full(dn.shape, nodata_out, dtype=np.float32)
            valid = (dn != nodata_dn) & np.isfinite(dn) & (dn > 0)
            val = (dn.astype(np.float64) + radio_add_offset) / quantification_value
            out[valid] = val[valid].astype(np.float32)
            return out
        else:
            dn_val = float(dn)
            if dn_val == nodata_dn or not math.isfinite(dn_val) or dn_val <= 0:
                return nodata_out
            return (dn_val + radio_add_offset) / quantification_value

    # -------------------------------------------------------------------------
    # PRE-005: Landsat Collection 2 Level-2 SR Scaling
    # -------------------------------------------------------------------------
    @staticmethod
    def landsat_c2_l2_sr_decode(
        dn: Any,
        scale: float = 0.0000275,
        offset: float = -0.2,
        nodata_dn: int = 0,
        nodata_out: float = -9999.0
    ) -> Any:
        """
        PRE-005: rho_SR = (DN * 0.0000275) - 0.2
        Masks fill DN=0 BEFORE scaling.
        Example: DN=18639 -> 18639 * 0.0000275 - 0.2 = 0.3125725.
        """
        if HAS_NUMPY and isinstance(dn, np.ndarray):
            out = np.full(dn.shape, nodata_out, dtype=np.float32)
            valid = (dn != nodata_dn) & np.isfinite(dn) & (dn > 0)
            val = dn.astype(np.float64) * scale + offset
            out[valid] = val[valid].astype(np.float32)
            return out
        else:
            dn_val = float(dn)
            if dn_val == nodata_dn or not math.isfinite(dn_val) or dn_val <= 0:
                return nodata_out
            return dn_val * scale + offset

    # -------------------------------------------------------------------------
    # PRE-006: Sentinel-2 Level-2A SR Decoding
    # -------------------------------------------------------------------------
    @staticmethod
    def sentinel2_l2a_sr_decode(
        dn: Any,
        boa_add_offset: float = 0.0,
        quantification_value: float = 10000.0,
        nodata_dn: int = 0,
        nodata_out: float = -9999.0
    ) -> Any:
        """
        PRE-006: rho_SR_i = (DN_i + BOA_ADD_OFFSET_i) / QUANTIFICATION_VALUE
        Example: DN=3000, BOA=-1000, Q=10000 -> (3000 - 1000) / 10000 = 0.20.
        """
        if quantification_value <= 0:
            raise RadiometryError("Quantification value must be strictly positive.")

        if HAS_NUMPY and isinstance(dn, np.ndarray):
            out = np.full(dn.shape, nodata_out, dtype=np.float32)
            valid = (dn != nodata_dn) & np.isfinite(dn) & (dn > 0)
            val = (dn.astype(np.float64) + boa_add_offset) / quantification_value
            out[valid] = val[valid].astype(np.float32)
            return out
        else:
            dn_val = float(dn)
            if dn_val == nodata_dn or not math.isfinite(dn_val) or dn_val <= 0:
                return nodata_out
            return (dn_val + boa_add_offset) / quantification_value

    # -------------------------------------------------------------------------
    # PRE-007: Radiative Transfer Forward & Inverse Atmospheric Model
    # -------------------------------------------------------------------------
    @staticmethod
    def radiative_transfer_forward(
        rho_sr: float,
        t_g: float,
        rho_path: float,
        t_down_up: float,
        s_albedo: float
    ) -> float:
        """
        Computes synthetic TOA reflectance:
        rho_TOA = T_g * [ rho_path + (T_down * T_up * rho_SR) / (1 - S * rho_SR) ]
        """
        denom = 1.0 - s_albedo * rho_sr
        if abs(denom) < 1e-7:
            raise RadiometryError("Multiple-scattering denominator approaches singularity.")
        bracket = rho_path + (t_down_up * rho_sr) / denom
        return t_g * bracket

    @staticmethod
    def radiative_transfer_invert(
        rho_toa: float,
        t_g: float,
        rho_path: float,
        t_down_up: float,
        s_albedo: float
    ) -> float:
        """
        Inverts TOA reflectance back to surface reflectance:
        X = rho_TOA / T_g - rho_path
        rho_SR = X / (T_down_up + S * X)
        """
        if abs(t_g) < 1e-7:
            raise RadiometryError("Gaseous transmittance T_g is near zero.")
        x = (rho_toa / t_g) - rho_path
        denom = t_down_up + (s_albedo * x)
        if abs(denom) < 1e-7:
            raise RadiometryError("Inversion denominator is near zero.")
        return x / denom

    @staticmethod
    def invert_6sv_coefficients(l_toa: float, xa: float, xb: float, xc: float) -> float:
        """
        6SV coefficient inversion:
        y = xa * L_TOA - xb
        rho_SR = y / (1 + xc * y)
        """
        y = xa * l_toa - xb
        denom = 1.0 + xc * y
        if abs(denom) < 1e-7:
            raise RadiometryError("6SV inversion denominator is zero.")
        return y / denom

    # -------------------------------------------------------------------------
    # PRE-008: Dark Object Subtraction (DOS) Approximate Adjustment
    # -------------------------------------------------------------------------
    @staticmethod
    def dark_object_subtraction(
        radiance: Any,
        l_dark: float,
        l_assumed_dark_surface: float = 0.01,
        nodata_out: float = -9999.0
    ) -> Any:
        """
        PRE-008: L_path_est = L_dark - L_assumed_dark_surface
        L_corrected_approx = max(L_TOA - L_path_est, 0)
        Clearly flagged as exploratory DOS_APPROX, not physical SR.
        """
        l_path_est = max(l_dark - l_assumed_dark_surface, 0.0)
        if HAS_NUMPY and isinstance(radiance, np.ndarray):
            out = np.full(radiance.shape, nodata_out, dtype=np.float32)
            valid = (radiance != nodata_out) & np.isfinite(radiance)
            corr = np.maximum(radiance.astype(np.float64) - l_path_est, 0.0)
            out[valid] = corr[valid].astype(np.float32)
            return out
        else:
            r_val = float(radiance)
            if r_val == nodata_out or not math.isfinite(r_val):
                return nodata_out
            return max(r_val - l_path_est, 0.0)

    # -------------------------------------------------------------------------
    # PRE-009: Thermal Radiance to Brightness Temperature & L2 ST
    # -------------------------------------------------------------------------
    @staticmethod
    def landsat_l1_brightness_temperature(
        l_lambda: Any,
        k1: float,
        k2: float,
        nodata_out: float = -9999.0
    ) -> Any:
        """
        PRE-009 (L1): BT_K = K2 / ln(K1 / L_lambda + 1)
        Planck inversion for Landsat Level-1 thermal radiance.
        """
        if k1 <= 0.0 or k2 <= 0.0:
            raise RadiometryError("Invalid Planck calibration constants K1 / K2.")

        if HAS_NUMPY and isinstance(l_lambda, np.ndarray):
            out = np.full(l_lambda.shape, nodata_out, dtype=np.float32)
            valid = (l_lambda != nodata_out) & np.isfinite(l_lambda) & (l_lambda > 0.0)
            ratio = (k1 / l_lambda.astype(np.float64)) + 1.0
            log_term = np.log(np.maximum(ratio, 1e-12))
            np.divide(k2, log_term, out=out, where=valid)
            return out
        else:
            val = float(l_lambda)
            if val <= 0.0 or val == nodata_out or not math.isfinite(val):
                return nodata_out
            return k2 / math.log((k1 / val) + 1.0)

    @staticmethod
    def landsat_c2_l2_surface_temperature(
        dn: Any,
        scale: float = 0.00341802,
        offset: float = 149.0,
        to_celsius: bool = True,
        nodata_dn: int = 0,
        nodata_out: float = -9999.0
    ) -> Any:
        """
        PRE-009 (L2 ST):
        ST_K = DN * 0.00341802 + 149.0
        ST_C = ST_K - 273.15
        """
        if HAS_NUMPY and isinstance(dn, np.ndarray):
            out = np.full(dn.shape, nodata_out, dtype=np.float32)
            valid = (dn != nodata_dn) & np.isfinite(dn) & (dn > 0)
            st_k = dn.astype(np.float64) * scale + offset
            res = (st_k - 273.15) if to_celsius else st_k
            out[valid] = res[valid].astype(np.float32)
            return out
        else:
            dn_val = float(dn)
            if dn_val == nodata_dn or not math.isfinite(dn_val) or dn_val <= 0:
                return nodata_out
            st_k = dn_val * scale + offset
            return (st_k - 273.15) if to_celsius else st_k

    # -------------------------------------------------------------------------
    # PRE-010 & PRE-011: QA Pixel & Scene Classification Decoding
    # -------------------------------------------------------------------------
    @staticmethod
    def decode_landsat_qa_pixel(
        qa_array: Any,
        exclude_cloud: bool = True,
        exclude_shadow: bool = True,
        exclude_dilated_cloud: bool = True,
        exclude_cirrus: bool = True,
        exclude_snow: bool = False
    ) -> Any:
        """
        PRE-010: Landsat Collection 2 QA_PIXEL bit interpretation:
        Bit 0: Fill (1 = fill)
        Bit 1: Dilated Cloud (1 = yes)
        Bit 2: Cirrus (1 = high confidence)
        Bit 3: Cloud (1 = yes)
        Bit 4: Cloud Shadow (1 = yes)
        Bit 5: Snow (1 = yes)
        Returns boolean mask where True = VALID pixel to KEEP.
        """
        if not HAS_NUMPY or not isinstance(qa_array, np.ndarray):
            return True

        qa = qa_array.astype(np.uint16)
        valid_mask = (qa & (1 << 0)) == 0  # Not Fill

        if exclude_dilated_cloud:
            valid_mask &= (qa & (1 << 1)) == 0
        if exclude_cirrus:
            valid_mask &= (qa & (1 << 2)) == 0
        if exclude_cloud:
            valid_mask &= (qa & (1 << 3)) == 0
        if exclude_shadow:
            valid_mask &= (qa & (1 << 4)) == 0
        if exclude_snow:
            valid_mask &= (qa & (1 << 5)) == 0

        return valid_mask

    @staticmethod
    def decode_sentinel2_scl(
        scl_array: Any,
        exclude_cloud_shadow: bool = True,
        exclude_cloud_medium: bool = True,
        exclude_cloud_high: bool = True,
        exclude_thin_cirrus: bool = True,
        exclude_snow: bool = False
    ) -> Any:
        """
        PRE-011: Sentinel-2 Scene Classification Layer (SCL) values:
        0: No Data
        1: Saturated or defective
        2: Dark area pixels
        3: Cloud shadows
        4: Vegetation
        5: Not-vegetated (bare soil/urban)
        6: Water
        7: Unclassified
        8: Cloud medium probability
        9: Cloud high probability
        10: Thin cirrus
        11: Snow or ice
        Returns boolean mask where True = VALID pixel to KEEP.
        """
        if not HAS_NUMPY or not isinstance(scl_array, np.ndarray):
            return True

        scl = scl_array.astype(np.uint8)
        valid_mask = (scl != 0) & (scl != 1)

        excluded_classes = set()
        if exclude_cloud_shadow:
            excluded_classes.add(3)
        if exclude_cloud_medium:
            excluded_classes.add(8)
        if exclude_cloud_high:
            excluded_classes.add(9)
        if exclude_thin_cirrus:
            excluded_classes.add(10)
        if exclude_snow:
            excluded_classes.add(11)

        for c in excluded_classes:
            valid_mask &= (scl != c)

        return valid_mask

    # -------------------------------------------------------------------------
    # PRE-017: Surface Reflectance Consistency Audit
    # -------------------------------------------------------------------------
    @staticmethod
    def audit_surface_reflectance_quality(
        band_arrays: Dict[str, Any],
        nodata: float = -9999.0
    ) -> Dict[str, Any]:
        """
        PRE-017: Inspects finite values, quantiles, out-of-range flags [0, 1].
        Flags anomalies without automatically clamping or destroying raw data.
        """
        if not HAS_NUMPY:
            return {"status": "skipped", "message": "NumPy required for statistical audit"}

        audit_results = {}
        for band_name, arr in band_arrays.items():
            if not isinstance(arr, np.ndarray):
                continue
            valid = (arr != nodata) & np.isfinite(arr)
            valid_count = int(np.count_nonzero(valid))
            total_count = int(arr.size)
            if valid_count == 0:
                audit_results[band_name] = {
                    "valid_count": 0, "valid_fraction": 0.0, "status": "ALL_NODATA"
                }
                continue

            vals = arr[valid]
            min_v = float(np.min(vals))
            max_v = float(np.max(vals))
            mean_v = float(np.mean(vals))
            p01 = float(np.percentile(vals, 1))
            p99 = float(np.percentile(vals, 99))
            neg_count = int(np.count_nonzero(vals < 0.0))
            excess_count = int(np.count_nonzero(vals > 1.0))

            warnings = []
            if min_v < -0.05:
                warnings.append(f"Noticeable negative reflectance: min={min_v:.4f}")
            if max_v > 1.2:
                warnings.append(f"Reflectance exceeds 1.0: max={max_v:.4f}")

            audit_results[band_name] = {
                "total_pixels": total_count,
                "valid_pixels": valid_count,
                "valid_fraction": valid_count / total_count,
                "min": min_v,
                "max": max_v,
                "mean": mean_v,
                "p01": p01,
                "p99": p99,
                "negative_count": neg_count,
                "excess_count": excess_count,
                "warnings": warnings,
                "status": "WARNING" if warnings else "PASS"
            }

        return audit_results

    # Convenience aliases matching AL-ATM-BOOK-2.0
    landsat_c2_l2_dn_to_surface_reflectance = landsat_c2_l2_sr_decode
    sentinel2_l1c_dn_to_toa_reflectance = sentinel2_l1c_dn_to_toa
    sentinel2_l2a_dn_to_surface_reflectance = sentinel2_l2a_sr_decode

