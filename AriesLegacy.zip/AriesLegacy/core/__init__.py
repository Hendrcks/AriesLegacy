"""
AriesLegacy Core Engine Package.
Scientific Satellite Spectral Analysis, Radiometric Calibration, and Atmospheric Correction.
"""

from .index_library import IndexLibrary, IndexDefinition
from .sensor_profiles import SensorProfileManager, SensorProfile
from .band_detector import BandDetector, BandDetectionResult
from .index_calculator import IndexCalculator, IndexCalculationResult
from .raster_preprocessor import RasterPreprocessor
from .radiometry import RadiometryEngine, RadiometryError
from .radiometric_state import RadiometricState, CorrectionStatus, ProductInspector
from .quality_masks import QualityMaskGenerator, QualityMaskPolicy
from .atmospheric_engine import AtmosphericEngine
from .formula_parser import SafeFormulaParser, FormulaSecurityError
from .classifier import Classifier, ClassificationScheme, ThresholdClass
from .change_detection import ChangeDetector, ChangeDetectionMode, ChangeDetectionResult
from .timeseries_engine import TimeSeriesEngine
from .area_statistics import AreaStatisticsCalculator, AreaStatisticsResult
from .style_manager import StyleManager
from .report_generator import ReportGenerator, ReportMetadata
from .provenance import AuditManifest
from .workflow_history import WorkflowHistory, WorkflowRecord

__all__ = [
    "IndexLibrary",
    "IndexDefinition",
    "SensorProfileManager",
    "SensorProfile",
    "BandDetector",
    "BandDetectionResult",
    "IndexCalculator",
    "IndexCalculationResult",
    "RasterPreprocessor",
    "RadiometryEngine",
    "RadiometryError",
    "RadiometricState",
    "CorrectionStatus",
    "ProductInspector",
    "QualityMaskGenerator",
    "QualityMaskPolicy",
    "AtmosphericEngine",
    "SafeFormulaParser",
    "FormulaSecurityError",
    "Classifier",
    "ClassificationScheme",
    "ThresholdClass",
    "ChangeDetector",
    "ChangeDetectionMode",
    "ChangeDetectionResult",
    "TimeSeriesEngine",
    "AreaStatisticsCalculator",
    "AreaStatisticsResult",
    "StyleManager",
    "ReportGenerator",
    "ReportMetadata",
    "AuditManifest",
    "WorkflowHistory",
    "WorkflowRecord",
]
