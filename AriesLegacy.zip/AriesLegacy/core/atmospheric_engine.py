"""
AriesLegacy - Atmospheric Correction Engine: Automatic & Advanced Modes.
Implements Mode A (AUT-001) and Mode B (ADV-001 - ADV-006) according to AL-ATM-BOOK-2.0.
Coordinates radiometric state enforcement, physically based radiative transfer,
quality masking, sensitivity analysis, and scientific provenance.
"""

import os
import math
import hashlib
from typing import Dict, Any, List, Optional, Tuple, Union

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None

from .radiometric_state import RadiometricState, CorrectionStatus, ProductInspector
from .radiometry import RadiometryEngine, RadiometryError
from .quality_masks import QualityMaskGenerator, QualityMaskPolicy

try:
    from ..backends.base import AtmosphericBackendAdapter
    from ..backends.sen2cor import Sen2CorAdapter
    from ..backends.landsat_sr import LandsatSRAdapter
    from ..backends.sixs import SixSAdapter, AerosolModel
except (ImportError, ValueError):
    from backends.base import AtmosphericBackendAdapter
    from backends.sen2cor import Sen2CorAdapter
    from backends.landsat_sr import LandsatSRAdapter
    from backends.sixs import SixSAdapter, AerosolModel


class AtmosphericEngine:
    """
    Unified scientific engine for satellite TOA-to-BOA atmospheric correction.
    Enforces the core scientific invariant: Radiometric calibration is not atmospheric correction,
    and genuine Level-2 BOA products must never receive atmospheric correction a second time.
    """

    def __init__(self):
        self.backends: Dict[str, AtmosphericBackendAdapter] = {
            "sen2cor_external": Sen2CorAdapter(),
            "landsat_l2_import": LandsatSRAdapter(),
            "sixs_rt": SixSAdapter()
        }

    # -------------------------------------------------------------------------
    # Mode A: Automatic Atmospheric Correction (AUT-001)
    # -------------------------------------------------------------------------
    def run_automatic(
        self,
        product_path: str,
        requested_product: str = "BOA_IF_POSSIBLE",
        output_directory: Optional[str] = None,
        quality_policy: str = QualityMaskPolicy.STANDARD,
        feedback: Any = None
    ) -> Dict[str, Any]:
        """
        Mode A — Automatic: Inspects product metadata, detects Level-1/Level-2 state,
        decodes existing Level-2 without re-running correction, or executes compatible
        verified atmospheric backends with safe fallback to TOA-only.
        """
        # 1. Inspect product state
        scene_info = ProductInspector.inspect_path(product_path)
        state = scene_info.get("state", RadiometricState.UNKNOWN)
        out_dir = output_directory or (product_path if os.path.isdir(product_path) else os.path.dirname(product_path))

        manifest = {
            "mode": "automatic",
            "input_product": product_path,
            "detected_sensor": scene_info.get("sensor"),
            "detected_level": scene_info.get("level"),
            "initial_state": state.value,
            "requested_product": requested_product,
            "quality_policy": quality_policy,
            "provenance_notes": []
        }

        # 2. Case: Product is already Level-2 BOA Surface Reflectance
        if state == RadiometricState.BOA_SCALED:
            # Decode stored scaling factors, strictly bypass atmospheric correction rerun
            manifest["final_state"] = RadiometricState.BOA_REFLECTANCE.value
            manifest["status"] = CorrectionStatus.EXISTING_BOA_DECODED.value
            manifest["provenance_notes"].append(
                "Authentic Level-2 BOA product detected. Decoded scale factors/offsets. "
                "Atmospheric correction rerun bypassed to preserve physical integrity."
            )
            return {
                "status": CorrectionStatus.EXISTING_BOA_DECODED,
                "scene_info": scene_info,
                "manifest": manifest,
                "output_directory": out_dir,
                "action": "DECODE_L2_SCALE_ONLY"
            }

        elif state == RadiometricState.BOA_REFLECTANCE:
            manifest["final_state"] = RadiometricState.BOA_REFLECTANCE.value
            manifest["status"] = CorrectionStatus.EXISTING_BOA_ACCEPTED.value
            manifest["provenance_notes"].append("Pre-existing physical BOA reflectance accepted directly.")
            return {
                "status": CorrectionStatus.EXISTING_BOA_ACCEPTED,
                "scene_info": scene_info,
                "manifest": manifest,
                "output_directory": out_dir,
                "action": "ACCEPT_UNMODIFIED_BOA"
            }

        # 3. Case: Product is Level-1 (RAW_DN or TOA_REFLECTANCE)
        elif state in (RadiometricState.RAW_DN, RadiometricState.TOA_REFLECTANCE):
            if requested_product == "TOA_ONLY":
                manifest["final_state"] = RadiometricState.TOA_REFLECTANCE.value
                manifest["status"] = CorrectionStatus.TOA_ONLY.value
                manifest["provenance_notes"].append("User explicitly requested TOA-only output.")
                return {
                    "status": CorrectionStatus.TOA_ONLY,
                    "scene_info": scene_info,
                    "manifest": manifest,
                    "output_directory": out_dir,
                    "action": "CALIBRATE_TOA_ONLY"
                }

            # Attempt automated Level-1 to Level-2 BOA atmospheric correction
            sensor = scene_info.get("sensor", "")
            if "sentinel_2" in sensor:
                s2_adapter = self.backends["sen2cor_external"]
                avail, msg = s2_adapter.check_dependencies()
                if avail:
                    res = s2_adapter.execute(scene_info, {"output_directory": out_dir}, feedback=feedback)
                    manifest["backend"] = s2_adapter.backend_id()
                    manifest["status"] = res["status"].value
                    manifest["provenance_notes"].append("Atmospheric correction executed via ESA Sen2Cor.")
                    return {
                        "status": res["status"],
                        "scene_info": scene_info,
                        "manifest": manifest,
                        "output_directory": out_dir,
                        "action": "EXECUTE_SEN2COR",
                        "details": res
                    }
                else:
                    # Safe fallback to TOA-only
                    manifest["final_state"] = RadiometricState.TOA_REFLECTANCE.value
                    manifest["status"] = CorrectionStatus.BOA_UNAVAILABLE_TOA_ONLY.value
                    manifest["provenance_notes"].append(
                        f"BOA unavailable: {msg}. Exporting calibrated TOA reflectance with explicit warning."
                    )
                    return {
                        "status": CorrectionStatus.BOA_UNAVAILABLE_TOA_ONLY,
                        "scene_info": scene_info,
                        "manifest": manifest,
                        "output_directory": out_dir,
                        "action": "FALLBACK_TOA_ONLY",
                        "warning": msg
                    }

            elif "landsat" in sensor:
                # For Landsat Level-1 in Automatic mode, official USGS L2 is preferred
                manifest["final_state"] = RadiometricState.TOA_REFLECTANCE.value
                manifest["status"] = CorrectionStatus.BOA_UNAVAILABLE_TOA_ONLY.value
                warning_msg = (
                    "Landsat Level-1 detected. Operational LaSRC atmospheric processor requires authentic USGS Level-2 "
                    "or custom 6S setup in Advanced Mode. Exported calibrated TOA reflectance."
                )
                manifest["provenance_notes"].append(warning_msg)
                return {
                    "status": CorrectionStatus.BOA_UNAVAILABLE_TOA_ONLY,
                    "scene_info": scene_info,
                    "manifest": manifest,
                    "output_directory": out_dir,
                    "action": "FALLBACK_TOA_ONLY",
                    "warning": warning_msg
                }

        # 4. Unknown or unverified product
        manifest["final_state"] = RadiometricState.UNKNOWN.value
        manifest["status"] = CorrectionStatus.INSUFFICIENT_METADATA.value
        return {
            "status": CorrectionStatus.INSUFFICIENT_METADATA,
            "scene_info": scene_info,
            "manifest": manifest,
            "output_directory": out_dir,
            "action": "STOP_INSUFFICIENT_METADATA",
            "error": "Product radiometric state and sensor level could not be verified from metadata."
        }

    # -------------------------------------------------------------------------
    # Mode B: Advanced Atmospheric Correction (ADV-001 - ADV-006)
    # -------------------------------------------------------------------------
    def run_advanced(
        self,
        product_path: str,
        settings: Dict[str, Any],
        output_directory: Optional[str] = None,
        feedback: Any = None
    ) -> Dict[str, Any]:
        """
        Mode B — Advanced: Full researcher configuration of physical radiative transfer model,
        geometry, atmospheric gases, aerosols, elevation/pressure, and sensitivity testing.
        """
        scene_info = ProductInspector.inspect_path(product_path)
        state = scene_info.get("state", RadiometricState.UNKNOWN)

        # Invariant: Reject already corrected Level-2 products
        if state in (RadiometricState.BOA_SCALED, RadiometricState.BOA_REFLECTANCE):
            raise ValueError(
                "Input scene is already Level-2 BOA Surface Reflectance. "
                "Atmospheric correction cannot be re-applied to an already corrected product."
            )

        backend_id = settings.get("backend", "sixs_rt")
        adapter = self.backends.get(backend_id)
        if not adapter:
            raise ValueError(f"Unsupported atmospheric correction backend '{backend_id}'.")

        ready, r_msg = adapter.check_dependencies()
        if not ready:
            raise RuntimeError(f"Backend '{backend_id}' dependency check failed: {r_msg}")

        valid, v_msg = adapter.validate_scene_and_inputs(scene_info, settings)
        if not valid:
            raise ValueError(f"Atmospheric parameter validation failed: {v_msg}")

        # Execute backend to derive band coefficients and correction manifest
        exec_res = adapter.execute(scene_info, settings, feedback=feedback)

        manifest = {
            "mode": "advanced",
            "backend": backend_id,
            "input_product": product_path,
            "scene_info": scene_info,
            "settings": settings,
            "backend_manifest": exec_res.get("manifest", {}),
            "status": CorrectionStatus.BOA_CORRECTED_VERIFIED.value
        }

        return {
            "status": CorrectionStatus.BOA_CORRECTED_VERIFIED,
            "scene_info": scene_info,
            "manifest": manifest,
            "coefficients": exec_res.get("manifest", {}).get("coefficients", {}),
            "logs": exec_res.get("logs", "")
        }

    # -------------------------------------------------------------------------
    # Exploratory Dark Object Subtraction (ATM-005)
    # -------------------------------------------------------------------------
    @staticmethod
    def calculate_dos_approximation(
        band_array: Any,
        dark_percentile: float = 0.01,
        nodata: float = -9999.0,
        eps: float = 1e-6
    ) -> Dict[str, Any]:
        """
        ATM-005: Optional exploratory Dark Object Subtraction (DOS).
        Estimates path radiance/reflectance from the 1st percentile of dark pixels
        and subtracts it. The output is strictly labeled 'DOS_APPROXIMATION'.
        """
        if not HAS_NUMPY or not isinstance(band_array, np.ndarray):
            val = float(band_array)
            return {"corrected": max(0.0, val - 0.01) if val != nodata else nodata, "path_estimate": 0.01}

        valid = (band_array != nodata) & np.isfinite(band_array) & (band_array > 0.0)
        if not np.any(valid):
            return {
                "corrected": np.full(band_array.shape, nodata, dtype=np.float32),
                "path_estimate": 0.0,
                "status": CorrectionStatus.DOS_APPROXIMATION
            }

        valid_vals = band_array[valid]
        path_est = float(np.percentile(valid_vals, dark_percentile * 100.0))

        corrected = np.full(band_array.shape, nodata, dtype=np.float32)
        np.subtract(band_array, path_est, out=corrected, where=valid)
        # Ensure non-negative reflectance after DOS
        corrected[valid & (corrected < 0.0)] = 0.0

        return {
            "corrected": corrected,
            "path_estimate": round(path_est, 6),
            "status": CorrectionStatus.DOS_APPROXIMATION
        }

    # -------------------------------------------------------------------------
    # Sensitivity & Uncertainty Analysis (ADV-005)
    # -------------------------------------------------------------------------
    @staticmethod
    def calculate_sensitivity_scenarios(
        rho_toa: Any,
        wavelength_um: float,
        solar_zenith_deg: float,
        base_aot: float = 0.15,
        aot_range: Tuple[float, float] = (0.05, 0.35),
        base_wv: float = 1.5,
        wv_range: Tuple[float, float] = (0.5, 3.0),
        nodata: float = -9999.0
    ) -> Dict[str, Any]:
        """
        ADV-005: Parameter sensitivity testing. Computes reflectance outcomes
        under bounding low and high atmospheric scenarios to quantify retrieval uncertainty.
        Spread: Delta_rho = rho_high - rho_low.
        """
        # Low scenario (clearer atmosphere)
        low_coeffs = SixSAdapter.calculate_band_coefficients(
            wavelength_um=wavelength_um,
            solar_zenith_deg=solar_zenith_deg,
            aot550=aot_range[0],
            water_vapour_g_cm2=wv_range[0]
        )
        rho_low = SixSAdapter.invert_lambertian_toa_to_boa(
            rho_toa=rho_toa,
            rho_path=low_coeffs["rho_path"],
            t_eff=low_coeffs["T_eff"],
            s_albedo=low_coeffs["S"],
            nodata=nodata
        )

        # High scenario (hazier atmosphere)
        high_coeffs = SixSAdapter.calculate_band_coefficients(
            wavelength_um=wavelength_um,
            solar_zenith_deg=solar_zenith_deg,
            aot550=aot_range[1],
            water_vapour_g_cm2=wv_range[1]
        )
        rho_high = SixSAdapter.invert_lambertian_toa_to_boa(
            rho_toa=rho_toa,
            rho_path=high_coeffs["rho_path"],
            t_eff=high_coeffs["T_eff"],
            s_albedo=high_coeffs["S"],
            nodata=nodata
        )

        if HAS_NUMPY and isinstance(rho_toa, np.ndarray):
            valid = (rho_low != nodata) & (rho_high != nodata)
            spread = np.full(rho_toa.shape, nodata, dtype=np.float32)
            np.subtract(rho_high, rho_low, out=spread, where=valid)
            mean_spread = float(np.mean(np.abs(spread[valid]))) if np.any(valid) else 0.0
        else:
            if rho_low != nodata and rho_high != nodata:
                spread = rho_high - rho_low
                mean_spread = abs(spread)
            else:
                spread = nodata
                mean_spread = 0.0

        return {
            "rho_low": rho_low,
            "rho_high": rho_high,
            "spread": spread,
            "mean_uncertainty_spread": round(mean_spread, 5),
            "low_aot": aot_range[0],
            "high_aot": aot_range[1]
        }

    # -------------------------------------------------------------------------
    # Scientific Comparator (ADV-006 & Section 12.2)
    # -------------------------------------------------------------------------
    @staticmethod
    def compare_with_reference(
        retrieved_boa: Any,
        reference_boa: Any,
        nodata: float = -9999.0
    ) -> Dict[str, Any]:
        """
        ADV-006: Compares retrieved surface reflectance with an authoritative reference
        (e.g. USGS L2 or Sentinel-2 L2A).
        Computes Bias, Mean Absolute Error (MAE), Root Mean Square Error (RMSE),
        and Pearson correlation coefficient (r).
        """
        if not HAS_NUMPY or not isinstance(retrieved_boa, np.ndarray) or not isinstance(reference_boa, np.ndarray):
            p = float(retrieved_boa)
            r = float(reference_boa)
            if p == nodata or r == nodata or not math.isfinite(p) or not math.isfinite(r):
                return {"valid_samples": 0, "bias": 0.0, "mae": 0.0, "rmse": 0.0, "r": 0.0}
            diff = p - r
            return {"valid_samples": 1, "bias": diff, "mae": abs(diff), "rmse": abs(diff), "r": 1.0}

        valid = (
            (retrieved_boa != nodata) & np.isfinite(retrieved_boa) &
            (reference_boa != nodata) & np.isfinite(reference_boa)
        )
        n = int(np.sum(valid))
        if n == 0:
            return {"valid_samples": 0, "bias": 0.0, "mae": 0.0, "rmse": 0.0, "r": 0.0}

        p = retrieved_boa[valid].astype(np.float64)
        r = reference_boa[valid].astype(np.float64)

        diff = p - r
        bias = float(np.mean(diff))
        mae = float(np.mean(np.abs(diff)))
        rmse = float(np.sqrt(np.mean(diff ** 2)))

        std_p = float(np.std(p))
        std_r = float(np.std(r))
        if std_p > 1e-7 and std_r > 1e-7:
            corr = float(np.corrcoef(p, r)[0, 1])
        else:
            corr = 1.0 if np.allclose(p, r) else 0.0

        return {
            "valid_samples": n,
            "bias": round(bias, 5),
            "mae": round(mae, 5),
            "rmse": round(rmse, 5),
            "r": round(corr, 4)
        }
