"""
AriesLegacy - Quality Mask and Screening Engine.
Implements QA-001 quality mask generation and spatial validity filtering
for Landsat Collection 2 QA_PIXEL and Sentinel-2 Scene Classification Layer (SCL)
according to AL-ATM-BOOK-2.0 Section 8.1.
"""

from typing import Dict, Any, List, Optional, Union
import math

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None


class QualityMaskPolicy:
    """Masking strictness presets."""
    CONSERVATIVE = "conservative"
    STANDARD = "standard"
    RELAXED = "relaxed"


class QualityMaskGenerator:
    """
    Generates binary and categorical validity masks from Landsat QA_PIXEL and Sentinel-2 SCL.
    1 = Valid observation, 0 = Masked (cloud, shadow, saturation, fill).
    """

    @staticmethod
    def mask_landsat_qa_pixel(
        qa_array: Any,
        policy: str = QualityMaskPolicy.STANDARD
    ) -> Any:
        """
        Decodes Landsat Collection 2 QA_PIXEL bitmask.
        Returns uint8 array where 1 = Valid, 0 = Masked.
        """
        if not HAS_NUMPY or not isinstance(qa_array, np.ndarray):
            qa_val = int(qa_array) if qa_array is not None else 1
            if qa_val & 1:  # Fill
                return 0
            if (qa_val & (1 << 3)) or (qa_val & (1 << 4)):  # Cloud or shadow
                return 0
            if policy in (QualityMaskPolicy.STANDARD, QualityMaskPolicy.CONSERVATIVE) and (qa_val & (1 << 2)):  # Cirrus
                return 0
            if policy == QualityMaskPolicy.CONSERVATIVE and ((qa_val & (1 << 1)) or (qa_val & (1 << 5))):  # Dilated or snow
                return 0
            return 1

        valid_mask = np.ones(qa_array.shape, dtype=np.uint8)

        # Bit 0: Fill (always mask)
        valid_mask[np.bitwise_and(qa_array, 1) != 0] = 0

        # Bit 3: Cloud (always mask)
        valid_mask[np.bitwise_and(qa_array, 1 << 3) != 0] = 0

        # Bit 4: Cloud Shadow (always mask)
        valid_mask[np.bitwise_and(qa_array, 1 << 4) != 0] = 0

        if policy in (QualityMaskPolicy.STANDARD, QualityMaskPolicy.CONSERVATIVE):
            # Bit 2: High confidence cirrus
            valid_mask[np.bitwise_and(qa_array, 1 << 2) != 0] = 0

        if policy == QualityMaskPolicy.CONSERVATIVE:
            # Bit 1: Dilated Cloud
            valid_mask[np.bitwise_and(qa_array, 1 << 1) != 0] = 0
            # Bit 5: Snow/Ice
            valid_mask[np.bitwise_and(qa_array, 1 << 5) != 0] = 0

        return valid_mask

    @staticmethod
    def mask_sentinel2_scl(
        scl_array: Any,
        policy: str = QualityMaskPolicy.STANDARD
    ) -> Any:
        """
        Decodes Sentinel-2 Scene Classification Layer (SCL).
        Returns uint8 array where 1 = Valid, 0 = Masked.
        """
        if policy == QualityMaskPolicy.CONSERVATIVE:
            # Mask NoData(0), Saturated(1), Shadow(3), CloudMed(8), CloudHigh(9), Cirrus(10), Snow(11)
            masked_classes = {0, 1, 3, 8, 9, 10, 11}
        elif policy == QualityMaskPolicy.RELAXED:
            # Mask NoData(0), Shadow(3), CloudHigh(9)
            masked_classes = {0, 3, 9}
        else:
            # Standard: Mask NoData(0), Saturated(1), Shadow(3), CloudMed(8), CloudHigh(9)
            masked_classes = {0, 1, 3, 8, 9}

        if not HAS_NUMPY or not isinstance(scl_array, np.ndarray):
            scl_val = int(scl_array) if scl_array is not None else 0
            return 0 if scl_val in masked_classes else 1

        valid_mask = np.ones(scl_array.shape, dtype=np.uint8)
        for cls_id in masked_classes:
            valid_mask[scl_array == cls_id] = 0

        return valid_mask

    @staticmethod
    def compute_mask_statistics(valid_mask: Any) -> Dict[str, Any]:
        """Calculates valid pixel count, total pixels, and clear sky percentage."""
        if not HAS_NUMPY or not isinstance(valid_mask, np.ndarray):
            v = int(valid_mask) == 1
            return {"total_pixels": 1, "valid_pixels": 1 if v else 0, "valid_fraction": 1.0 if v else 0.0}

        total = int(valid_mask.size)
        valid = int(np.sum(valid_mask == 1))
        masked = total - valid
        pct = (valid / total * 100.0) if total > 0 else 0.0

        return {
            "total_pixels": total,
            "valid_pixels": valid,
            "masked_pixels": masked,
            "valid_percent": round(pct, 2),
            "valid_fraction": round(valid / total, 4) if total > 0 else 0.0
        }
