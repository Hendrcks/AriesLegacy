"""
AriesLegacy - Classifier and Statistical Discretization Engine.
Implements CLS-001 through CLS-007 from the AriesLegacy v2 specification.
Provides User Thresholds, Equal Intervals, Quantiles, Jenks Natural Breaks,
Standard Deviation intervals, and Otsu Binary Thresholding.
"""

import math
from typing import Dict, List, Optional, Tuple, Any

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None


class ThresholdClass:
    """Represents a single threshold interval and its thematic label/color."""

    def __init__(self, class_id: int, min_val: float, max_val: float, label: str, color: str = "#808080"):
        self.class_id: int = class_id
        self.min_val: float = float(min_val)
        self.max_val: float = float(max_val)
        self.label: str = label
        self.color: str = color

    def to_dict(self) -> Dict[str, Any]:
        return {
            "class_id": self.class_id,
            "min_val": self.min_val,
            "max_val": self.max_val,
            "label": self.label,
            "color": self.color,
        }


class ClassificationScheme:
    """A collection of ordered threshold classes for an index."""

    def __init__(self, name: str, classes: Optional[List[ThresholdClass]] = None):
        self.name: str = name
        self.classes: List[ThresholdClass] = classes or []

    @classmethod
    def from_default_dict_list(cls, name: str, class_dicts: List[Dict[str, Any]]) -> "ClassificationScheme":
        scheme = cls(name)
        for idx, cd in enumerate(class_dicts, start=1):
            tc = ThresholdClass(
                class_id=idx,
                min_val=cd.get("min", -999.0),
                max_val=cd.get("max", 999.0),
                label=cd.get("label", f"Class {idx}"),
                color=cd.get("color", "#808080")
            )
            scheme.classes.append(tc)
        return scheme

    def get_qgis_reclass_table(self) -> List[float]:
        """Returns flat list [min1, max1, id1, min2, max2, id2, ...] for QGIS reclassify tool."""
        table = []
        for tc in self.classes:
            table.extend([tc.min_val, tc.max_val, float(tc.class_id)])
        return table


class Classifier:
    """Applies classification schemes to continuous raster arrays or layers."""

    @staticmethod
    def classify_numpy_array(
        array: Any,
        scheme: ClassificationScheme,
        nodata_in: float = -9999.0,
        nodata_out: int = 0
    ) -> Any:
        """
        Reclassifies a 2D float array or nested list into categorical values based on threshold bounds.
        """
        if HAS_NUMPY and isinstance(array, np.ndarray):
            out = np.full(array.shape, nodata_out, dtype=np.int32)
            valid_mask = (array != nodata_in) & np.isfinite(array)

            num_classes = len(scheme.classes)
            for idx, tc in enumerate(scheme.classes):
                if idx == num_classes - 1:
                    mask = valid_mask & (array >= tc.min_val) & (array <= tc.max_val)
                else:
                    mask = valid_mask & (array >= tc.min_val) & (array < tc.max_val)
                out[mask] = tc.class_id

            return out
        else:
            def classify_val(v):
                if v == nodata_in or not math.isfinite(v):
                    return nodata_out
                num_classes = len(scheme.classes)
                for idx, tc in enumerate(scheme.classes):
                    if idx == num_classes - 1:
                        if tc.min_val <= v <= tc.max_val:
                            return tc.class_id
                    else:
                        if tc.min_val <= v < tc.max_val:
                            return tc.class_id
                return nodata_out

            if isinstance(array, list):
                if len(array) > 0 and isinstance(array[0], list):
                    return [[classify_val(v) for v in row] for row in array]
                return [classify_val(v) for v in array]
            return classify_val(float(array))

    # -------------------------------------------------------------------------
    # CLS-002: Equal Intervals
    # -------------------------------------------------------------------------
    @staticmethod
    def compute_equal_intervals(values: Any, num_classes: int = 5, nodata: float = -9999.0) -> List[float]:
        """CLS-002: Computes breaks dividing range evenly: (max - min) / K."""
        if HAS_NUMPY and isinstance(values, np.ndarray):
            valid = (values != nodata) & np.isfinite(values)
            if not np.any(valid):
                return []
            min_v, max_v = float(np.min(values[valid])), float(np.max(values[valid]))
        else:
            valid_vals = [float(v) for v in values if v != nodata and math.isfinite(v)]
            if not valid_vals:
                return []
            min_v, max_v = min(valid_vals), max(valid_vals)

        if min_v == max_v:
            return [min_v, max_v]

        step = (max_v - min_v) / num_classes
        breaks = [min_v + i * step for i in range(num_classes + 1)]
        breaks[-1] = max_v
        return breaks

    # -------------------------------------------------------------------------
    # CLS-003: Quantiles
    # -------------------------------------------------------------------------
    @staticmethod
    def compute_quantiles(values: Any, num_classes: int = 5, nodata: float = -9999.0) -> List[float]:
        """CLS-003: Computes empirical K-quantile breaks."""
        if HAS_NUMPY and isinstance(values, np.ndarray):
            valid = (values != nodata) & np.isfinite(values)
            v = values[valid]
            if v.size == 0:
                return []
            probs = np.linspace(0, 100, num_classes + 1)
            return [float(x) for x in np.percentile(v, probs)]
        else:
            valid_vals = sorted([float(v) for v in values if v != nodata and math.isfinite(v)])
            n = len(valid_vals)
            if n == 0:
                return []
            breaks = []
            for i in range(num_classes + 1):
                idx = min(int(round((i / num_classes) * (n - 1))), n - 1)
                breaks.append(valid_vals[idx])
            return breaks

    # -------------------------------------------------------------------------
    # CLS-004: Jenks Natural Breaks (Fisher-Jenks)
    # -------------------------------------------------------------------------
    @staticmethod
    def compute_jenks_breaks(values: Any, num_classes: int = 5, max_samples: int = 3000, nodata: float = -9999.0) -> List[float]:
        """
        CLS-004: Natural Breaks (Jenks) algorithm minimizing within-class variance.
        Subsamples large arrays for high computational performance.
        """
        if HAS_NUMPY and isinstance(values, np.ndarray):
            valid = (values != nodata) & np.isfinite(values)
            flat = values[valid]
            if flat.size == 0:
                return []
            if flat.size > max_samples:
                flat = np.random.choice(flat, max_samples, replace=False)
            data_list = sorted([float(x) for x in flat])
        else:
            valid_vals = sorted([float(v) for v in values if v != nodata and math.isfinite(v)])
            if not valid_vals:
                return []
            data_list = valid_vals[:max_samples]

        n = len(data_list)
        if n <= num_classes:
            return sorted(list(set(data_list)))

        # Dynamic programming Fisher-Jenks
        k = num_classes
        mat1 = [[0] * (k + 1) for _ in range(n + 1)]
        mat2 = [[float("inf")] * (k + 1) for _ in range(n + 1)]

        for i in range(1, k + 1):
            mat1[1][i] = 1
            mat2[1][i] = 0.0

        for i in range(2, n + 1):
            s1 = 0.0
            s2 = 0.0
            for m in range(1, i + 1):
                val = data_list[i - m]
                s2 += val * val
                s1 += val
                w = m
                v = s2 - (s1 * s1) / w
                i4 = i - m
                if i4 != 0:
                    for j in range(2, k + 1):
                        if mat2[i][j] >= (v + mat2[i4][j - 1]):
                            mat1[i][j] = i4
                            mat2[i][j] = v + mat2[i4][j - 1]
            mat1[i][1] = 1
            mat2[i][1] = v

        k_class = []
        k_class.append(data_list[n - 1])
        count_num = k
        k_curr = n
        while count_num >= 2:
            id_idx = int(mat1[k_curr][count_num]) - 1
            k_class.append(data_list[id_idx])
            k_curr = int(mat1[k_curr][count_num])
            count_num -= 1
        k_class.append(data_list[0])
        k_class.reverse()
        return k_class

    # -------------------------------------------------------------------------
    # CLS-005: Standard Deviation Classes
    # -------------------------------------------------------------------------
    @staticmethod
    def compute_std_deviation_classes(values: Any, nodata: float = -9999.0) -> List[float]:
        """
        CLS-005: Breaks around empirical mean:
        [< mean-2sd, mean-2sd..mean-sd, mean-sd..mean, mean..mean+sd, mean+sd..mean+2sd, > mean+2sd]
        """
        if HAS_NUMPY and isinstance(values, np.ndarray):
            valid = (values != nodata) & np.isfinite(values)
            v = values[valid]
            if v.size < 2:
                return []
            mean_v, std_v = float(np.mean(v)), float(np.std(v))
            min_v, max_v = float(np.min(v)), float(np.max(v))
        else:
            valid_vals = [float(v) for v in values if v != nodata and math.isfinite(v)]
            if len(valid_vals) < 2:
                return []
            mean_v = sum(valid_vals) / len(valid_vals)
            std_v = math.sqrt(sum((x - mean_v) ** 2 for x in valid_vals) / (len(valid_vals) - 1))
            min_v, max_v = min(valid_vals), max(valid_vals)

        breaks = [
            min_v,
            mean_v - 2.0 * std_v,
            mean_v - 1.0 * std_v,
            mean_v,
            mean_v + 1.0 * std_v,
            mean_v + 2.0 * std_v,
            max_v
        ]
        return sorted(list(set(breaks)))

    # -------------------------------------------------------------------------
    # CLS-006: Otsu Binary Threshold
    # -------------------------------------------------------------------------
    @staticmethod
    def compute_otsu_threshold(values: Any, num_bins: int = 256, nodata: float = -9999.0) -> float:
        """
        CLS-006: Otsu threshold maximizing between-class variance sigma_B^2(t).
        Handles plateau/valley ties by taking the midpoint of optimal thresholds.
        """
        if HAS_NUMPY and isinstance(values, np.ndarray):
            valid = (values != nodata) & np.isfinite(values)
            flat = values[valid]
            if flat.size == 0:
                return 0.0
            hist, bin_edges = np.histogram(flat, bins=num_bins)
            bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2.0
        else:
            valid_vals = [float(v) for v in values if v != nodata and math.isfinite(v)]
            if not valid_vals:
                return 0.0
            min_v, max_v = min(valid_vals), max(valid_vals)
            if min_v == max_v:
                return min_v
            step = (max_v - min_v) / num_bins
            bin_centers = [min_v + (i + 0.5) * step for i in range(num_bins)]
            hist = [0] * num_bins
            for v in valid_vals:
                idx = min(int((v - min_v) / step), num_bins - 1)
                hist[idx] += 1

        total = sum(hist)
        if total == 0:
            return 0.0

        sum_total = sum(bin_centers[i] * hist[i] for i in range(len(hist)))
        weight_b = 0
        sum_b = 0.0
        max_var = -1.0
        best_indices = []

        for t in range(len(hist)):
            weight_b += hist[t]
            if weight_b == 0:
                continue
            weight_f = total - weight_b
            if weight_f == 0:
                break

            sum_b += bin_centers[t] * hist[t]
            mean_b = sum_b / weight_b
            mean_f = (sum_total - sum_b) / weight_f

            # Normalized between-class variance
            var_between = (weight_b / total) * (weight_f / total) * ((mean_b - mean_f) ** 2)
            if var_between > max_var + 1e-12:
                max_var = var_between
                best_indices = [t]
            elif abs(var_between - max_var) <= 1e-12:
                best_indices.append(t)

        if not best_indices:
            return float(bin_centers[0])
        mid_idx = int(round(sum(best_indices) / len(best_indices)))
        return float(bin_centers[mid_idx])
