"""
AriesLegacy - Index Calculator.
Executes spatial index calculations using GDAL/NumPy block processing with QGIS fallback.
Complies strictly with the AriesLegacy v2 Scientific Formula & Algorithm Specification.
Supports all 42 published indices and custom AST expressions.
"""

import os
import math
from typing import Dict, List, Optional, Tuple, Any

from .index_library import IndexDefinition
from .sensor_profiles import SensorProfile
from .raster_preprocessor import RasterPreprocessor
from .formula_parser import SafeFormulaParser, FormulaSecurityError


def safe_divide_scalar(numerator: float, denominator: float, nodata: float = -9999.0, eps: float = 1e-8) -> float:
    """Safely divides two scalar floats."""
    if not math.isfinite(numerator) or not math.isfinite(denominator) or abs(denominator) <= eps:
        return nodata
    return numerator / denominator


def safe_divide_numpy(numerator: Any, denominator: Any, nodata: float = -9999.0, eps: float = 1e-8) -> Any:
    """Safely divides two NumPy arrays returning nodata where denominator is zero or non-finite."""
    import numpy as np
    num_arr = np.asarray(numerator, dtype=np.float64)
    den_arr = np.asarray(denominator, dtype=np.float64)
    valid = np.isfinite(num_arr) & np.isfinite(den_arr) & (np.abs(den_arr) > eps)
    out = np.full(num_arr.shape, fill_value=nodata, dtype=np.float32)
    np.divide(num_arr, den_arr, out=out, where=valid)
    return out


class IndexCalculationResult:
    """Stores results and metadata of an index calculation."""

    def __init__(self, index_def: IndexDefinition, output_path: str, success: bool = True, message: str = ""):
        self.index_def: IndexDefinition = index_def
        self.output_path: str = output_path
        self.success: bool = success
        self.message: str = message
        self.applied_formula: str = ""
        self.statistics: Dict[str, float] = {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index_id": self.index_def.id,
            "short_name": self.index_def.short_name,
            "output_path": self.output_path,
            "success": self.success,
            "message": self.message,
            "applied_formula": self.applied_formula,
            "statistics": self.statistics,
        }


class IndexCalculator:
    """Calculates spatial indices for single rasters, band collections, and raster layers."""

    @staticmethod
    def calculate_pure_numpy(
        index_def: IndexDefinition,
        band_arrays: Dict[str, Any],  # Canonical band -> 2D numpy array or scalar
        sensor_profile: SensorProfile,
        apply_scaling: bool = True,
        nodata_val: float = -9999.0
    ) -> Any:
        """
        Pure NumPy / Python calculation engine (used for direct array processing and test suite).
        Always executes in floating-point precision (Float32 / Float64).
        Supports all 42 published indices and custom expressions.
        """
        try:
            import numpy as np
            has_np = True
        except ImportError:
            has_np = False
            np = None

        # Standardize canonical band keys (e.g. SWIR1 -> SWIR1 / SWIR_1, RE1 -> RE1 / RED_EDGE_1)
        normalized_bands = {}
        for k, v in band_arrays.items():
            k_upper = k.upper().strip()
            normalized_bands[k_upper] = v
            # Add common variations
            if k_upper in ("SWIR1", "SWIR_1"):
                normalized_bands["SWIR1"] = v
                normalized_bands["SWIR_1"] = v
            elif k_upper in ("SWIR2", "SWIR_2"):
                normalized_bands["SWIR2"] = v
                normalized_bands["SWIR_2"] = v
            elif k_upper in ("RE1", "RED_EDGE_1"):
                normalized_bands["RE1"] = v
                normalized_bands["RED_EDGE_1"] = v
            elif k_upper in ("RE2", "RED_EDGE_2"):
                normalized_bands["RE2"] = v
                normalized_bands["RED_EDGE_2"] = v
            elif k_upper in ("RE3", "RED_EDGE_3"):
                normalized_bands["RE3"] = v
                normalized_bands["RED_EDGE_3"] = v
            elif k_upper in ("NIR_NARROW", "NN", "B8A"):
                normalized_bands["NIR_NARROW"] = v
                normalized_bands["NN"] = v

        # Scale bands according to sensor profile
        scaled_bands = {}
        for canonical, arr in normalized_bands.items():
            if has_np and isinstance(arr, np.ndarray):
                arr_float = arr.astype(np.float64)
            elif isinstance(arr, (int, float)):
                arr_float = float(arr)
            else:
                arr_float = float(arr)

            # Thermal band scaling (Landsat ST_B10: LST_K = DN * 0.00341802 + 149.0)
            if canonical == "THERMAL" and sensor_profile.thermal_scale_factor is not None:
                if apply_scaling:
                    sf = sensor_profile.thermal_scale_factor
                    off = sensor_profile.thermal_offset or 0.0
                    scaled_bands[canonical] = arr_float * sf + off
                else:
                    scaled_bands[canonical] = arr_float
            else:
                # Optical surface reflectance scaling
                if apply_scaling and (sensor_profile.scale_factor != 1.0 or sensor_profile.offset != 0.0):
                    sf = sensor_profile.scale_factor
                    off = sensor_profile.offset
                    scaled_bands[canonical] = arr_float * sf + off
                else:
                    scaled_bands[canonical] = arr_float

        # Helper divide
        def _divide(num, den):
            if has_np and (isinstance(num, np.ndarray) or isinstance(den, np.ndarray)):
                return safe_divide_numpy(num, den, nodata=nodata_val)
            return safe_divide_scalar(num, den, nodata=nodata_val)

        # Helper sqrt
        def _sqrt(val):
            if has_np and isinstance(val, np.ndarray):
                return np.sqrt(np.maximum(val, 0.0))
            return math.sqrt(max(float(val), 0.0))

        iid = index_def.id.lower()
        res = None

        # ---------------------------------------------------------------------
        # 1. Vegetation, canopy and crop indices
        # ---------------------------------------------------------------------
        if iid == "ndvi":
            nir, red = scaled_bands["NIR"], scaled_bands["RED"]
            res = _divide(nir - red, nir + red)

        elif iid == "gndvi":
            nir, green = scaled_bands["NIR"], scaled_bands["GREEN"]
            res = _divide(nir - green, nir + green)

        elif iid == "evi":
            nir, red, blue = scaled_bands["NIR"], scaled_bands["RED"], scaled_bands["BLUE"]
            denom = nir + 6.0 * red - 7.5 * blue + 1.0
            res = 2.5 * _divide(nir - red, denom)

        elif iid == "evi2":
            nir, red = scaled_bands["NIR"], scaled_bands["RED"]
            denom = nir + 2.4 * red + 1.0
            res = 2.5 * _divide(nir - red, denom)

        elif iid == "savi":
            nir, red = scaled_bands["NIR"], scaled_bands["RED"]
            res = 1.5 * _divide(nir - red, nir + red + 0.5)

        elif iid == "osavi":
            nir, red = scaled_bands["NIR"], scaled_bands["RED"]
            res = 1.16 * _divide(nir - red, nir + red + 0.16)

        elif iid in ("msavi", "msavi2"):
            nir, red = scaled_bands["NIR"], scaled_bands["RED"]
            term = (2.0 * nir + 1.0) ** 2 - 8.0 * (nir - red)
            sqrt_term = _sqrt(term)
            res = (2.0 * nir + 1.0 - sqrt_term) / 2.0

        elif iid == "sr":
            nir, red = scaled_bands["NIR"], scaled_bands["RED"]
            res = _divide(nir, red)

        elif iid == "dvi":
            nir, red = scaled_bands["NIR"], scaled_bands["RED"]
            res = nir - red

        elif iid == "rdvi":
            nir, red = scaled_bands["NIR"], scaled_bands["RED"]
            sqrt_denom = _sqrt(nir + red)
            res = _divide(nir - red, sqrt_denom)

        elif iid == "arvi":
            nir, red, blue = scaled_bands["NIR"], scaled_bands["RED"], scaled_bands["BLUE"]
            rb = 2.0 * red - blue
            res = _divide(nir - rb, nir + rb)

        elif iid == "vari":
            green, red, blue = scaled_bands["GREEN"], scaled_bands["RED"], scaled_bands["BLUE"]
            denom = green + red - blue
            res = _divide(green - red, denom)

        elif iid == "sipi":
            nir, blue, red = scaled_bands["NIR"], scaled_bands["BLUE"], scaled_bands["RED"]
            res = _divide(nir - blue, nir - red)

        elif iid == "ndre1":
            nir, re1 = scaled_bands["NIR"], scaled_bands["RE1"]
            res = _divide(nir - re1, nir + re1)

        elif iid == "ndre2":
            nn, re2 = scaled_bands["NIR_NARROW"], scaled_bands["RE2"]
            res = _divide(nn - re2, nn + re2)

        elif iid == "ci_re":
            nn, re1 = scaled_bands["NIR_NARROW"], scaled_bands["RE1"]
            ratio = _divide(nn, re1)
            res = ratio - 1.0

        elif iid in ("ci_green", "gci"):
            nir, green = scaled_bands["NIR"], scaled_bands["GREEN"]
            ratio = _divide(nir, green)
            res = ratio - 1.0

        elif iid == "mtci":
            re2, re1, red = scaled_bands["RE2"], scaled_bands["RE1"], scaled_bands["RED"]
            res = _divide(re2 - re1, re1 - red)

        elif iid == "mcari":
            re1, red, green = scaled_bands["RE1"], scaled_bands["RED"], scaled_bands["GREEN"]
            ratio = _divide(re1, red)
            res = (re1 - red) - 0.2 * (re1 - green) * ratio

        elif iid == "tcari":
            re1, red, green = scaled_bands["RE1"], scaled_bands["RED"], scaled_bands["GREEN"]
            ratio = _divide(re1, red)
            res = 3.0 * ((re1 - red) - 0.2 * (re1 - green) * ratio)

        # ---------------------------------------------------------------------
        # 2. Moisture, wetlands and surface-water indices
        # ---------------------------------------------------------------------
        elif iid in ("ndmi", "ndwi_gao", "lswi"):
            nir, swir1 = scaled_bands["NIR"], scaled_bands["SWIR1"]
            res = _divide(nir - swir1, nir + swir1)

        elif iid == "msi":
            swir1, nir = scaled_bands["SWIR1"], scaled_bands["NIR"]
            res = _divide(swir1, nir)

        elif iid == "gvmi":
            nir, swir1 = scaled_bands["NIR"], scaled_bands["SWIR1"]
            num = (nir + 0.1) - (swir1 + 0.02)
            den = (nir + 0.1) + (swir1 + 0.02)
            res = _divide(num, den)

        elif iid in ("ndwi", "ndwi_water"):
            green, nir = scaled_bands["GREEN"], scaled_bands["NIR"]
            res = _divide(green - nir, green + nir)

        elif iid == "mndwi":
            green, swir1 = scaled_bands["GREEN"], scaled_bands["SWIR1"]
            res = _divide(green - swir1, green + swir1)

        elif iid == "awei_nsh":
            green, nir, swir1, swir2 = scaled_bands["GREEN"], scaled_bands["NIR"], scaled_bands["SWIR1"], scaled_bands["SWIR2"]
            res = 4.0 * (green - swir1) - (0.25 * nir + 2.75 * swir2)

        elif iid == "awei_sh":
            blue, green, nir, swir1, swir2 = scaled_bands["BLUE"], scaled_bands["GREEN"], scaled_bands["NIR"], scaled_bands["SWIR1"], scaled_bands["SWIR2"]
            res = blue + 2.5 * green - 1.5 * (nir + swir1) - 0.25 * swir2

        elif iid == "wri":
            green, red, nir, swir1 = scaled_bands["GREEN"], scaled_bands["RED"], scaled_bands["NIR"], scaled_bands["SWIR1"]
            res = _divide(green + red, nir + swir1)

        elif iid == "ndci":
            re1, red = scaled_bands["RE1"], scaled_bands["RED"]
            res = _divide(re1 - red, re1 + red)

        # ---------------------------------------------------------------------
        # 3. Urban, soil, geology and burned area indices
        # ---------------------------------------------------------------------
        elif iid == "ndbi":
            swir1, nir = scaled_bands["SWIR1"], scaled_bands["NIR"]
            res = _divide(swir1 - nir, swir1 + nir)

        elif iid == "ui":
            swir2, nir = scaled_bands["SWIR2"], scaled_bands["NIR"]
            res = _divide(swir2 - nir, swir2 + nir)

        elif iid == "bsi":
            swir1, red, nir, blue = scaled_bands["SWIR1"], scaled_bands["RED"], scaled_bands["NIR"], scaled_bands["BLUE"]
            res = _divide((swir1 + red) - (nir + blue), (swir1 + red) + (nir + blue))

        elif iid == "bui":
            swir1, nir, red = scaled_bands["SWIR1"], scaled_bands["NIR"], scaled_bands["RED"]
            ndbi = _divide(swir1 - nir, swir1 + nir)
            ndvi = _divide(nir - red, nir + red)
            res = ndbi - ndvi

        elif iid == "ibi":
            swir1, nir, red, green = scaled_bands["SWIR1"], scaled_bands["NIR"], scaled_bands["RED"], scaled_bands["GREEN"]
            term_a = 2.0 * _divide(swir1, swir1 + nir)
            term_b = _divide(nir, nir + red) + _divide(green, green + swir1)
            res = _divide(term_a - term_b, term_a + term_b)

        elif iid == "nbr":
            nir, swir2 = scaled_bands["NIR"], scaled_bands["SWIR2"]
            res = _divide(nir - swir2, nir + swir2)

        elif iid in ("nbr2", "ndti_swir"):
            swir1, swir2 = scaled_bands["SWIR1"], scaled_bands["SWIR2"]
            res = _divide(swir1 - swir2, swir1 + swir2)

        elif iid == "bai":
            red, nir = scaled_bands["RED"], scaled_bands["NIR"]
            denom = ((0.1 - red) ** 2) + ((0.06 - nir) ** 2)
            res = _divide(1.0, denom)

        elif iid == "mirbi":
            swir2, swir1 = scaled_bands["SWIR2"], scaled_bands["SWIR1"]
            res = 10.0 * swir2 - 9.8 * swir1 + 2.0

        elif iid == "ndsi_snow":
            green, swir1 = scaled_bands["GREEN"], scaled_bands["SWIR1"]
            res = _divide(green - swir1, green + swir1)

        elif iid in ("clay_ratio", "clay_index"):
            swir1, swir2 = scaled_bands["SWIR1"], scaled_bands["SWIR2"]
            res = _divide(swir1, swir2)

        elif iid in ("iron_oxide_ratio", "iron_oxide"):
            red, blue = scaled_bands["RED"], scaled_bands["BLUE"]
            res = _divide(red, blue)

        # ---------------------------------------------------------------------
        # 4. Thermal Surface Temperature & Change
        # ---------------------------------------------------------------------
        elif iid in ("lst", "lst_c"):
            thermal = scaled_bands["THERMAL"]
            res = thermal - 273.15

        elif iid == "dnbr":
            nbr_pre = scaled_bands["NBR_PRE"]
            nbr_post = scaled_bands["NBR_POST"]
            res = nbr_pre - nbr_post

        # ---------------------------------------------------------------------
        # 5. Custom / Fallback AST Expression Evaluation
        # ---------------------------------------------------------------------
        else:
            formula_to_run = index_def.safe_formula or index_def.formula
            res = SafeFormulaParser.evaluate(formula_to_run, scaled_bands, nodata_val=nodata_val)


        # Physical range sanitization for normalized difference indices [-1.0, 1.0]
        if has_np and isinstance(res, np.ndarray):
            if index_def.value_range and index_def.value_range == [-1.0, 1.0]:
                invalid_range = (res < -1.0) | (res > 1.0)
                res[invalid_range] = nodata_val

        return res

    @staticmethod
    def calculate_raster_layers(
        index_def: IndexDefinition,
        mapped_bands: Dict[str, Tuple[Any, int]],  # canonical -> (QgsRasterLayer, band_number)
        sensor_profile: SensorProfile,
        output_path: str,
        apply_scaling: bool = True,
        nodata_val: float = -9999.0,
        feedback: Any = None
    ) -> bool:
        """
        Executes accurate Float32 raster index calculation with full NoData masking and physical validation.
        Uses GDAL block-by-block processing when file paths are accessible, falling back to QgsRasterCalculator.
        """
        try:
            from osgeo import gdal
            import numpy as np
            has_gdal = True
        except ImportError:
            try:
                import gdal
                import numpy as np
                has_gdal = True
            except ImportError:
                has_gdal = False
                gdal = None
                np = None

        first_req = index_def.required_bands[0]
        # Match canonical key
        match_key = None
        for k in mapped_bands.keys():
            if k.upper().replace("_", "") == first_req.upper().replace("_", ""):
                match_key = k
                break
        if not match_key:
            match_key = list(mapped_bands.keys())[0]

        ref_layer = mapped_bands[match_key][0]

        # 1. Try GDAL chunk-based processing
        if has_gdal and hasattr(ref_layer, "source") and os.path.exists(ref_layer.source()):
            try:
                datasets = {}
                band_objs = {}
                nodata_values = {}

                for canonical, (layer, band_idx) in mapped_bands.items():
                    ds = gdal.Open(layer.source(), gdal.GA_ReadOnly)
                    if not ds:
                        raise RuntimeError(f"Could not open GDAL source: {layer.source()}")
                    datasets[canonical] = ds
                    b_obj = ds.GetRasterBand(band_idx)
                    band_objs[canonical] = b_obj
                    nd = b_obj.GetNoDataValue()
                    nodata_values[canonical] = nd if nd is not None else -9999.0

                ref_ds = list(datasets.values())[0]
                cols = ref_ds.RasterXSize
                rows = ref_ds.RasterYSize
                geotransform = ref_ds.GetGeoTransform()
                projection = ref_ds.GetProjection()

                driver = gdal.GetDriverByName("GTiff")
                out_ds = driver.Create(
                    output_path, cols, rows, 1, gdal.GDT_Float32,
                    options=["TILED=YES", "COMPRESS=DEFLATE", "PREDICTOR=2", "BIGTIFF=IF_SAFER"]
                )
                out_ds.SetGeoTransform(geotransform)
                out_ds.SetProjection(projection)
                out_band = out_ds.GetRasterBand(1)
                out_band.SetNoDataValue(nodata_val)

                block_x, block_y = out_band.GetBlockSize()
                total_blocks = math.ceil(cols / block_x) * math.ceil(rows / block_y)
                block_count = 0

                for y in range(0, rows, block_y):
                    if feedback and feedback.isCanceled():
                        break
                    win_y = min(block_y, rows - y)

                    for x in range(0, cols, block_x):
                        if feedback and feedback.isCanceled():
                            break
                        win_x = min(block_x, cols - x)

                        # Read blocks
                        block_bands = {}
                        valid_combined = np.ones((win_y, win_x), dtype=bool)

                        for canonical, b_obj in band_objs.items():
                            data_block = b_obj.ReadAsArray(x, y, win_x, win_y).astype(np.float64)
                            nd = nodata_values[canonical]
                            valid = (data_block != nd) & np.isfinite(data_block)
                            if sensor_profile.nodata_value is not None:
                                valid &= (data_block != sensor_profile.nodata_value)
                            valid_combined &= valid
                            block_bands[canonical] = data_block

                        # Calculate index on chunk
                        calc_result = IndexCalculator.calculate_pure_numpy(
                            index_def, block_bands, sensor_profile,
                            apply_scaling=apply_scaling, nodata_val=nodata_val
                        )

                        chunk_out = np.full((win_y, win_x), fill_value=nodata_val, dtype=np.float32)
                        valid_final = valid_combined & np.isfinite(calc_result) & (calc_result != nodata_val)
                        chunk_out[valid_final] = calc_result[valid_final].astype(np.float32)

                        out_band.WriteArray(chunk_out, x, y)
                        block_count += 1
                        if feedback:
                            feedback.setProgress(int((block_count / total_blocks) * 100))

                out_band.FlushCache()
                out_ds = None
                for ds in datasets.values():
                    ds = None

                return os.path.exists(output_path) and os.path.getsize(output_path) > 0
            except Exception as e:
                print(f"[AriesLegacy] GDAL block execution failed, falling back to QGIS: {e}")

        # 2. QGIS Raster Calculator Fallback
        try:
            from qgis.analysis import QgsRasterCalculator, QgsRasterCalculatorEntry
            from qgis.core import QgsCoordinateReferenceSystem
        except ImportError:
            return False

        entries = []
        band_ref_names = {}

        for canonical, (layer, band_idx) in mapped_bands.items():
            entry = QgsRasterCalculatorEntry()
            ref_name = f"{canonical.lower()}@{band_idx}"
            entry.ref = ref_name
            entry.raster = layer
            entry.bandNumber = band_idx
            entries.append(entry)
            band_ref_names[canonical] = ref_name

        expr = RasterPreprocessor.build_full_index_expression(
            index_def.safe_formula, band_ref_names, sensor_profile, apply_scaling=apply_scaling
        )

        calc = QgsRasterCalculator(
            expr, output_path, "GTiff",
            ref_layer.extent(), ref_layer.width(), ref_layer.height(), entries
        )
        res_code = calc.processCalculation(feedback)
        return res_code == 0
