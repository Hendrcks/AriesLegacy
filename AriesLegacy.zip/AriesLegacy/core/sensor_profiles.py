"""
AriesLegacy - Sensor Profiles Manager.
Handles sensor metadata, band definitions, scaling factors, offsets, and detection rules.
Supports Sentinel-2 (L1C/L2A), Landsat 4-9 (C2 L1/L2), NASA HLS, and generic optical rasters.
"""

import json
import os
import re
from typing import Dict, List, Optional, Any


class SensorProfile:
    """Represents a single sensor configuration profile."""

    def __init__(self, data: Dict[str, Any]):
        self.id: str = data.get("id", "")
        self.name: str = data.get("name", "")
        self.agency: str = data.get("agency", "")
        self.level: str = data.get("level", "")
        self.processing_level: str = data.get("processing_level", "")
        self.description: str = data.get("description", "")
        self.scale_factor: float = float(data.get("scale_factor", 1.0))
        self.offset: float = float(data.get("offset", 0.0))
        self.quantification_value: float = float(data.get("quantification_value", 10000.0))
        self.boa_add_offset_default: float = float(data.get("boa_add_offset_default", 0.0))
        self.thermal_scale_factor: Optional[float] = data.get("thermal_scale_factor")
        self.thermal_offset: Optional[float] = data.get("thermal_offset")
        self.nodata_value: Any = data.get("nodata_value", 0)
        self.bands: Dict[str, Dict[str, Any]] = data.get("bands", {})
        self.detection_patterns: List[str] = data.get("detection_patterns", [])

    def get_band_info(self, canonical_name: str) -> Optional[Dict[str, Any]]:
        """Get band details for canonical band name like NIR, RED, BLUE, etc."""
        # Support aliases like SWIR_1 -> SWIR1
        c_clean = canonical_name.upper().replace("_", "")
        for k, v in self.bands.items():
            if k.upper().replace("_", "") == c_clean:
                return v
        return self.bands.get(canonical_name.upper())

    def get_canonical_name_for_alias(self, alias_or_name: str) -> Optional[str]:
        """Resolve a specific band name or alias back to canonical name (e.g., B08 -> NIR)."""
        clean_alias = alias_or_name.strip().upper()
        for canonical, info in self.bands.items():
            if info.get("name", "").upper() == clean_alias:
                return canonical
            aliases = [a.upper() for a in info.get("aliases", [])]
            if clean_alias in aliases:
                return canonical
        return None

    def list_canonical_bands(self) -> List[str]:
        """List all canonical band names in this profile."""
        return list(self.bands.keys())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "agency": self.agency,
            "level": self.level,
            "processing_level": self.processing_level,
            "description": self.description,
            "scale_factor": self.scale_factor,
            "offset": self.offset,
            "quantification_value": self.quantification_value,
            "thermal_scale_factor": self.thermal_scale_factor,
            "thermal_offset": self.thermal_offset,
            "nodata_value": self.nodata_value,
            "bands": self.bands,
            "detection_patterns": self.detection_patterns,
        }


class SensorProfileManager:
    """Manages loading, retrieving, and registering sensor profiles."""

    _instance: Optional["SensorProfileManager"] = None

    def __init__(self, json_path: Optional[str] = None):
        self.profiles: Dict[str, SensorProfile] = {}
        if json_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            json_path = os.path.join(base_dir, "data", "sensor_profiles.json")
        self.json_path = json_path
        self.load_profiles()

    @classmethod
    def get_instance(cls, json_path: Optional[str] = None) -> "SensorProfileManager":
        if cls._instance is None:
            cls._instance = SensorProfileManager(json_path)
        return cls._instance

    def load_profiles(self) -> None:
        """Loads profiles from JSON file."""
        if os.path.exists(self.json_path):
            try:
                with open(self.json_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    sensors = data.get("sensors", {})
                    for sid, sdata in sensors.items():
                        self.profiles[sid] = SensorProfile(sdata)
            except Exception as e:
                print(f"[AriesLegacy] Error loading sensor profiles: {e}")

        # Ensure default generic profile exists
        if "generic" not in self.profiles:
            self.profiles["generic"] = SensorProfile({
                "id": "generic",
                "name": "Generic Optical Multispectral",
                "scale_factor": 1.0,
                "offset": 0.0,
                "bands": {
                    "BLUE": {"name": "Blue", "aliases": ["b2", "blue"]},
                    "GREEN": {"name": "Green", "aliases": ["b3", "green"]},
                    "RED": {"name": "Red", "aliases": ["b4", "red"]},
                    "NIR": {"name": "NIR", "aliases": ["b8", "b5", "nir"]},
                    "SWIR1": {"name": "SWIR1", "aliases": ["b11", "b6", "swir1", "swir_1"]},
                    "SWIR2": {"name": "SWIR2", "aliases": ["b12", "b7", "swir2", "swir_2"]},
                }
            })

    def get_profile(self, profile_id: str) -> Optional[SensorProfile]:
        """Fetch profile by ID."""
        return self.profiles.get(profile_id)

    def list_profiles(self) -> List[SensorProfile]:
        """Returns all loaded sensor profiles."""
        return list(self.profiles.values())

    def match_sensor_by_name_or_metadata(self, text_or_path: str) -> Optional[SensorProfile]:
        """Matches a raster layer name or filepath to a sensor profile via regex patterns."""
        clean_text = os.path.basename(text_or_path).upper()
        for profile in self.profiles.values():
            for pattern in profile.detection_patterns:
                if re.search(pattern, clean_text, re.IGNORECASE):
                    return profile
        return None
