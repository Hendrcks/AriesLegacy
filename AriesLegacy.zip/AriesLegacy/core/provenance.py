"""
AriesLegacy - Provenance and Audit Manifest Engine.
Generates reproducible JSON audit manifests (QA-008) tracking input scenes,
file checksums, exact formula revision, calibration constants, masks, and runtime environment.
"""

import hashlib
import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Any


class AuditManifest:
    """Creates deterministic scientific run manifests for reproducibility."""

    @staticmethod
    def calculate_file_hash(file_path: str, algorithm: str = "sha256", max_bytes: int = 10 * 1024 * 1024) -> str:
        """Computes cryptographic hash of file header/content up to max_bytes."""
        if not os.path.exists(file_path):
            return ""
        hasher = hashlib.new(algorithm)
        try:
            with open(file_path, "rb") as f:
                bytes_read = 0
                while bytes_read < max_bytes:
                    chunk = f.read(65536)
                    if not chunk:
                        break
                    hasher.update(chunk)
                    bytes_read += len(chunk)
            return hasher.hexdigest()
        except Exception:
            return ""

    @staticmethod
    def create_run_manifest(
        operation_id: str,
        operation_name: str,
        input_files: Dict[str, str],
        parameters: Dict[str, Any],
        output_files: Dict[str, str],
        statistics: Optional[Dict[str, Any]] = None,
        notes: str = ""
    ) -> Dict[str, Any]:
        """Constructs full scientific provenance dictionary."""
        input_checksums = {}
        for role, fpath in input_files.items():
            input_checksums[role] = {
                "path": fpath,
                "sha256_head": AuditManifest.calculate_file_hash(fpath) if os.path.exists(fpath) else "NOT_FOUND"
            }

        output_manifest = {}
        for role, fpath in output_files.items():
            output_manifest[role] = {
                "path": fpath,
                "sha256_head": AuditManifest.calculate_file_hash(fpath) if os.path.exists(fpath) else "NOT_YET_CREATED"
            }

        manifest = {
            "schema_version": "2.0",
            "plugin": "AriesLegacy",
            "plugin_version": "2.0.0",
            "timestamp_utc": datetime.utcnow().isoformat() + "Z",
            "operation": {
                "id": operation_id,
                "name": operation_name,
                "parameters": parameters,
            },
            "inputs": input_checksums,
            "outputs": output_manifest,
            "statistics": statistics or {},
            "provenance_notes": notes
        }
        return manifest

    @staticmethod
    def save_manifest_json(manifest: Dict[str, Any], output_path: str) -> None:
        """Writes manifest to JSON file."""
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

