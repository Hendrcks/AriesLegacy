"""
AriesLegacy - Index Library Manager.
Loads, manages, and filters geospatial indices database.
Integrates safe AST parsing and scientific formula specifications.
"""

import json
import os
from typing import Dict, List, Optional, Any

from .formula_parser import SafeFormulaParser, FormulaSecurityError


class IndexDefinition:
    """Represents a single geospatial index calculation definition."""

    def __init__(self, data: Dict[str, Any]):
        self.id: str = data.get("id", "")
        self.standard_id: str = data.get("standard_id", "")
        self.aliases: List[str] = data.get("aliases", [])
        self.short_name: str = data.get("short_name", "")
        self.name: str = data.get("name", "")
        self.group: str = data.get("group", "General")
        self.formula: str = data.get("formula", "")
        self.safe_formula: str = data.get("safe_formula", self.formula)
        self.required_bands: List[str] = data.get("required_bands", [])
        self.requires_reflectance_scaling: bool = data.get("requires_reflectance_scaling", data.get("requires_reflectance", True))
        self.value_range: List[float] = data.get("value_range", [-1.0, 1.0])
        self.recommended_style: str = data.get("recommended_style", "RdYlGn")
        self.default_classes: List[Dict[str, Any]] = data.get("default_classes", [])
        self.description: str = data.get("description", "")
        self.reference: str = data.get("reference", "")
        self.is_two_date: bool = data.get("is_two_date", False)
        self.supported_sensors: Optional[List[str]] = data.get("supported_sensors", data.get("sensors", None))

    def is_compatible_with_sensor(self, sensor_id: str, available_canonical_bands: Optional[List[str]] = None) -> bool:
        """Check if this index can be computed with the given sensor and available bands."""
        if self.supported_sensors is not None and sensor_id not in self.supported_sensors:
            return False
        if available_canonical_bands is not None:
            # Normalize available bands
            avail_clean = {b.upper().replace("_", "") for b in available_canonical_bands}
            for b in self.required_bands:
                b_clean = b.upper().replace("_", "")
                if b_clean not in avail_clean:
                    return False
        return True

    def format_formula_with_band_names(self, band_name_map: Dict[str, str]) -> str:
        """
        Replaces canonical band symbols (e.g. NIR, RED) with actual layer/band expressions.
        """
        expr = self.safe_formula
        # Replace longer identifiers first to avoid partial overlap
        sorted_keys = sorted(band_name_map.keys(), key=len, reverse=True)
        for canonical in sorted_keys:
            actual_band_expr = band_name_map[canonical]
            # Replace identifier with exact match boundary
            expr = expr.replace(canonical, f"({actual_band_expr})")
        return expr

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "standard_id": self.standard_id,
            "aliases": self.aliases,
            "short_name": self.short_name,
            "name": self.name,
            "group": self.group,
            "formula": self.formula,
            "safe_formula": self.safe_formula,
            "required_bands": self.required_bands,
            "requires_reflectance_scaling": self.requires_reflectance_scaling,
            "value_range": self.value_range,
            "recommended_style": self.recommended_style,
            "default_classes": self.default_classes,
            "description": self.description,
            "reference": self.reference,
            "is_two_date": self.is_two_date,
            "supported_sensors": self.supported_sensors,
        }


class IndexLibrary:
    """Manages the catalogue of spatial indices."""

    _instance: Optional["IndexLibrary"] = None

    def __init__(self, json_path: Optional[str] = None):
        self.indices: Dict[str, IndexDefinition] = {}
        self.alias_map: Dict[str, str] = {}
        if json_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            json_path = os.path.join(base_dir, "data", "index_library.json")
        self.json_path = json_path
        self.load_library()

    @classmethod
    def get_instance(cls, json_path: Optional[str] = None) -> "IndexLibrary":
        if cls._instance is None:
            cls._instance = IndexLibrary(json_path)
        return cls._instance

    def load_library(self) -> None:
        """Loads index catalogue from JSON file."""
        self.indices.clear()
        self.alias_map.clear()
        if os.path.exists(self.json_path):
            try:
                with open(self.json_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    indices_list = data.get("indices", [])
                    for idata in indices_list:
                        idx_def = IndexDefinition(idata)
                        self.indices[idx_def.id.lower()] = idx_def
                        # Register standard ID (e.g. IDX-001)
                        if idx_def.standard_id:
                            self.alias_map[idx_def.standard_id.lower()] = idx_def.id.lower()
                        # Register aliases
                        for alias in idx_def.aliases:
                            self.alias_map[alias.lower()] = idx_def.id.lower()
            except Exception as e:
                print(f"[AriesLegacy] Error loading index library: {e}")

    def get_index(self, index_id_or_alias: str) -> Optional[IndexDefinition]:
        """Fetch index by ID, standard ID (e.g. IDX-001), or alias."""
        key = index_id_or_alias.strip().lower()
        if key in self.indices:
            return self.indices[key]
        resolved_id = self.alias_map.get(key)
        if resolved_id and resolved_id in self.indices:
            return self.indices[resolved_id]
        return None

    def list_all(self) -> List[IndexDefinition]:
        """Returns all loaded indices."""
        return list(self.indices.values())

    def list_by_group(self, group: str) -> List[IndexDefinition]:
        """Filter indices by thematic group (Vegetation, Water, Urban, etc.)."""
        return [idx for idx in self.indices.values() if idx.group.lower() == group.lower()]

    def filter_by_group(self, group: str) -> List[IndexDefinition]:
        """Compatibility alias for list_by_group."""
        return self.list_by_group(group)

    def search(self, query: str) -> List[IndexDefinition]:
        """Searches indices by keyword across id, short name, name, group, and description."""
        q = query.strip().lower()
        results = []
        for idx in self.indices.values():
            if (q in idx.id.lower() or
                q in idx.short_name.lower() or
                q in idx.name.lower() or
                q in idx.group.lower() or
                q in idx.description.lower() or
                any(q in a.lower() for a in idx.aliases)):
                results.append(idx)
        return results

    def list_compatible(self, sensor_id: str, available_canonical_bands: Optional[List[str]] = None) -> List[IndexDefinition]:
        """Returns list of indices compatible with sensor and available bands."""
        return [idx for idx in self.indices.values() if idx.is_compatible_with_sensor(sensor_id, available_canonical_bands)]

    def create_custom_index(
        self,
        custom_id: str,
        name: str,
        formula: str,
        group: str = "Custom"
    ) -> IndexDefinition:
        """Creates and validates a custom index using AST expression analysis."""
        SafeFormulaParser.validate_expression(formula)
        required_vars = SafeFormulaParser.extract_variables(formula)
        data = {
            "id": custom_id.lower(),
            "standard_id": "CUSTOM",
            "short_name": custom_id.upper(),
            "name": name,
            "group": group,
            "formula": formula,
            "safe_formula": formula,
            "required_bands": required_vars,
            "requires_reflectance_scaling": True,
            "value_range": [-10.0, 10.0],
            "recommended_style": "Spectral",
            "default_classes": [],
            "description": f"Custom user formula: {formula}",
            "reference": "User defined"
        }
        idx_def = IndexDefinition(data)
        self.indices[idx_def.id.lower()] = idx_def
        return idx_def
