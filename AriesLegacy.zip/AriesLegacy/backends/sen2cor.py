"""
AriesLegacy - Sen2Cor External Processor Adapter.
Implements Sentinel-2 L1C to L2A conversion via verified external Sen2Cor executable
according to AL-ATM-BOOK-2.0 Section 7.3.
"""

import os
import shutil
import subprocess  # nosec B404
from typing import Dict, Any, List, Optional, Tuple

try:
    from .base import AtmosphericBackendAdapter
    from ..core.radiometric_state import CorrectionStatus, RadiometricState
except (ImportError, ValueError):
    from backends.base import AtmosphericBackendAdapter
    from core.radiometric_state import CorrectionStatus, RadiometricState


class Sen2CorAdapter(AtmosphericBackendAdapter):
    """External process adapter for ESA Sen2Cor (L2A_Process)."""

    def __init__(self, custom_executable_path: Optional[str] = None):
        self.custom_path = custom_executable_path

    def backend_id(self) -> str:
        return "sen2cor_external"

    def name(self) -> str:
        return "ESA Sen2Cor Atmospheric Processor"

    def version(self) -> str:
        exe = self._resolve_executable()
        if not exe:
            return "Not Installed"
        try:
            res = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=5)  # nosec B603
            output = res.stdout.strip() or res.stderr.strip()
            return output if output else "Installed (Version unknown)"
        except (subprocess.SubprocessError, OSError):
            return "Installed"

    def supported_sensors_and_levels(self) -> List[str]:
        return ["sentinel_2_l1c", "Level-1C"]

    def _resolve_executable(self) -> Optional[str]:
        """Resolves path to L2A_Process or L2A_Process.bat."""
        if self.custom_path and os.path.exists(self.custom_path) and os.path.isfile(self.custom_path):
            return self.custom_path

        found = shutil.which("L2A_Process")
        if found:
            return found
        if os.name == "nt":
            found_bat = shutil.which("L2A_Process.bat")
            if found_bat:
                return found_bat
        return None

    def check_dependencies(self) -> Tuple[bool, str]:
        exe = self._resolve_executable()
        if not exe:
            return False, "Sen2Cor executable 'L2A_Process' not found in PATH or configured path. Install Sen2Cor from ESA STEP."
        return True, f"Found Sen2Cor executable: {exe}"

    def validate_scene_and_inputs(self, scene_info: Dict[str, Any], config: Dict[str, Any]) -> Tuple[bool, str]:
        path = scene_info.get("product_path", "")
        if not path or not os.path.exists(path):
            return False, f"Input path does not exist: {path}"

        if not os.path.isdir(path):
            return False, "Sen2Cor requires an uncompressed Sentinel-2 .SAFE directory containing MTD_MSIL1C.xml."

        xml_path = scene_info.get("metadata_file")
        if not xml_path or not os.path.exists(xml_path):
            # Check directory for MTD_MSIL1C.xml
            for root, _, files in os.walk(path):
                for f in files:
                    if f.upper().startswith("MTD_MSIL1C") and f.upper().endswith(".XML"):
                        xml_path = os.path.join(root, f)
                        break
                if xml_path:
                    break

        if not xml_path or not os.path.exists(xml_path):
            return False, "Missing required Sentinel-2 L1C metadata file 'MTD_MSIL1C.xml'."

        return True, "Sentinel-2 L1C SAFE container validated."

    def execute(self, scene_info: Dict[str, Any], config: Dict[str, Any], feedback: Any = None) -> Dict[str, Any]:
        ready, msg = self.check_dependencies()
        if not ready:
            return {
                "status": CorrectionStatus.BOA_UNAVAILABLE_TOA_ONLY,
                "output_files": {},
                "manifest": {},
                "logs": f"Dependency check failed: {msg}"
            }

        valid, vmsg = self.validate_scene_and_inputs(scene_info, config)
        if not valid:
            return {
                "status": CorrectionStatus.INSUFFICIENT_METADATA,
                "output_files": {},
                "manifest": {},
                "logs": f"Scene validation failed: {vmsg}"
            }

        exe = self._resolve_executable()
        safe_path = scene_info["product_path"]
        output_dir = config.get("output_directory", os.path.dirname(safe_path))
        resolution = config.get("resolution", 10)

        # Construct argument list safely (no shell=True)
        cmd = [exe, safe_path, f"--resolution={resolution}"]
        if output_dir and os.path.exists(output_dir):
            cmd.append(f"--output_dir={output_dir}")

        log_lines = [f"Executing Sen2Cor: {' '.join(cmd)}"]
        if feedback:
            feedback.setProgressText(f"Running Sen2Cor on {os.path.basename(safe_path)}...")

        try:
            proc = subprocess.Popen(  # nosec B603
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                shell=False
            )

            # Monitor progress
            while proc.poll() is None:
                if feedback and feedback.isCanceled():
                    proc.terminate()
                    proc.wait(timeout=5)
                    return {
                        "status": CorrectionStatus.BACKEND_FAILED,
                        "output_files": {},
                        "manifest": {},
                        "logs": "Sen2Cor run was canceled by the user."
                    }
                line = proc.stdout.readline() if proc.stdout else ""
                if line:
                    log_lines.append(line.strip())
                    if feedback:
                        feedback.setProgressText(line.strip())

            return_code = proc.returncode
            if return_code != 0:
                return {
                    "status": CorrectionStatus.BACKEND_FAILED,
                    "output_files": {},
                    "manifest": {},
                    "logs": f"Sen2Cor exited with error code {return_code}.\n" + "\n".join(log_lines[-20:])
                }

            # Find generated L2A SAFE container in output directory
            l2a_product = None
            for item in os.listdir(output_dir):
                if item.startswith("S2") and "_MSIL2A_" in item and item.endswith(".SAFE"):
                    l2a_product = os.path.join(output_dir, item)
                    break

            return {
                "status": CorrectionStatus.BOA_CORRECTED_VERIFIED,
                "output_files": {"l2a_safe": l2a_product or output_dir},
                "manifest": {
                    "backend": self.backend_id(),
                    "version": self.version(),
                    "input_product": safe_path,
                    "resolution": resolution
                },
                "logs": "\n".join(log_lines)
            }

        except Exception as e:
            return {
                "status": CorrectionStatus.BACKEND_FAILED,
                "output_files": {},
                "manifest": {},
                "logs": f"Sen2Cor execution exception: {str(e)}"
            }
