"""
AriesLegacy - Atmospheric Correction Processor Adapters.
"""

from .base import AtmosphericBackendAdapter
from .sen2cor import Sen2CorAdapter
from .landsat_sr import LandsatSRAdapter
from .sixs import SixSAdapter, AerosolModel

__all__ = [
    "AtmosphericBackendAdapter",
    "Sen2CorAdapter",
    "LandsatSRAdapter",
    "SixSAdapter",
    "AerosolModel",
]
