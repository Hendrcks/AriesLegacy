"""
AriesLegacy - Atmospheric Correction Backend Base Contract.
Implements the backend adapter interface specified in AL-ATM-BOOK-2.0 Section 7.1.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, Tuple


class AtmosphericBackendAdapter(ABC):
    """Abstract interface for atmospheric correction processors and model adapters."""

    @abstractmethod
    def backend_id(self) -> str:
        """Unique machine identifier for the backend (e.g. 'sen2cor_external', 'sixs_rt')."""
        pass

    @abstractmethod
    def name(self) -> str:
        """Human-readable display name."""
        pass

    @abstractmethod
    def version(self) -> str:
        """Version string of the installed or embedded processor."""
        pass

    @abstractmethod
    def supported_sensors_and_levels(self) -> List[str]:
        """List of supported sensor profile IDs or product types."""
        pass

    @abstractmethod
    def check_dependencies(self) -> Tuple[bool, str]:
        """Checks if external executables, environments, or libraries are available."""
        pass

    @abstractmethod
    def validate_scene_and_inputs(self, scene_info: Dict[str, Any], config: Dict[str, Any]) -> Tuple[bool, str]:
        """Validates that the input product has complete required metadata and parameters."""
        pass

    @abstractmethod
    def execute(self, scene_info: Dict[str, Any], config: Dict[str, Any], feedback: Any = None) -> Dict[str, Any]:
        """
        Executes correction pipeline and returns output metadata:
        {
            "status": CorrectionStatus,
            "output_files": {"boa": path, "qa": path, ...},
            "manifest": dict,
            "logs": str
        }
        """
        pass
