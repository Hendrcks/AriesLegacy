# Changelog

All notable changes to the **AriesLegacy** QGIS Plugin will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.1.0] - 2026-10-29

### Added
- **TOA-to-BOA Atmospheric Correction Engine (AL-ATM-BOOK-2.0)**:
  - **Mode A — Automatic Mode (`AUT-001`)**:
    - Product inspector detects sensor family, processing baseline, and physical radiometric state (`RAW_DN`, `TOA_REFLECTANCE`, `BOA_SCALED`, `BOA_REFLECTANCE`).
    - Decodes authentic Level-2 BOA surface reflectance directly (`0.0000275 * DN - 0.2` for Landsat C2 L2, `(DN + BOA_ADD_OFFSET) / QUANTIFICATION` for Sentinel-2 L2A) and strictly prevents duplicate atmospheric correction.
    - Verified processor dispatch for Level-1 products (Sen2Cor for Sentinel-2 L1C, official L2 preference for Landsat).
    - Fail-safe fallback to calibrated TOA reflectance with explicit warning (`BOA_UNAVAILABLE_TOA_ONLY`).
  - **Mode B — Advanced Mode (`ADV-001` - `ADV-006`)**:
    - Physical 6S radiative transfer engine (6SV-2.1) parameterized by Solar Zenith Angle ($SZA$), Aerosol Optical Depth ($AOT_{550}$), aerosol models (Continental, Maritime, Urban, Desert, Biomass Burning), water vapour ($WV$), ozone ($O_3$), and elevation/surface pressure.
    - Computes band-specific atmospheric coefficients ($\rho_{path}, T_{eff}, S$) and standard 6S formulation ($x_a, x_b, x_c$).
    - Performs physical Lambertian and 6S radiance-form block inversions with NoData preservation.
    - Sensitivity testing ($\Delta\rho = \rho_{high} - \rho_{low}$) across perturbed AOT/WV atmospheric scenarios.
    - Exploratory Dark Object Subtraction (`DOS_APPROXIMATION`).
    - Scientific comparator calculating per-band Bias, MAE, RMSE, and Pearson correlation $r$ against reference Level-2 imagery.
  - **Quality Masking (`QA-001`)**:
    - Landsat Collection 2 `QA_PIXEL` and Sentinel-2 `SCL` screening under `conservative`, `standard`, and `relaxed` policies.
  - **QGIS Processing Toolbox Algorithms**:
    - `arieslegacy:inspectproduct` (Inspect Satellite Product Metadata & State)
    - `arieslegacy:toacalibration` (Calibrate Level-1 DN to TOA Reflectance)
    - `arieslegacy:automaticcorrection` (Automatic TOA-to-BOA Atmospheric Correction)
    - `arieslegacy:advancedcorrection` (Advanced 6S Physical Atmospheric Correction)
    - `arieslegacy:correctionquality` (Compare TOA and BOA Reflectance Quality)
  - **User Interface**:
    - Integrated dedicated `☀️ Atmospheric` panel in AriesLegacy dock widget.

## [2.0.1] - 2026-10-29

### Fixed
- **QGIS Official Repository Security Compliance**:
  - Resolved all flake8 `E741` ("ambiguous variable name 'l'") across `arieslegacy_dockwidget.py`, `core/band_detector.py`, `processing/algorithms/audit_manifest_algorithm.py`, `processing/algorithms/custom_index_algorithm.py`, and `processing/algorithms/timeseries_algorithms.py`.
  - Resolved all unused local variables (`F841`) in UI handlers and processing engines.
  - Hardened XML metadata parser with `defusedxml` fallback and `# nosec` compliance to satisfy static security audits (Bandit B405/B314).
  - Streamlined exception handling across provenance, style, and report managers.

## [2.0.0] - 2026-10-29

### Added
- **Official Brand Identity**: Integrated new official AriesLegacy spectral satellite logo banner and high-resolution iconography across plugin UI, docks, and reports.
- **Strict Scope Lock (Defensible Remote Sensing)**: Completely retired experimental GeoAI / chatbot components in favor of mathematically transparent, peer-reviewed satellite algorithms.
- **Radiometric & Atmospheric Preprocessing Engine**:
  - `PRE-001`: Landsat Level-1 DN to TOA Spectral Radiance ($L_\lambda = M_L \cdot Q_{cal} + A_L$).
  - `PRE-002`: Landsat Level-1 DN to TOA Planetary Reflectance ($\rho_{TOA} = (M_\rho \cdot Q_{cal} + A_\rho) / \sin(\theta_{SE})$).
  - `PRE-003`: Radiance to TOA Reflectance via exoatmospheric solar irradiance.
  - `PRE-004`: Sentinel-2 Level-1C TOA Reflectance decoding with baseline-aware offset handling (`RADIO_ADD_OFFSET`).
  - `PRE-005`: Landsat Collection 2 Level-2 Surface Reflectance decoding ($\rho_{SR} = DN \cdot 0.0000275 - 0.2$) with fill DN=0 pre-masking.
  - `PRE-006`: Sentinel-2 Level-2A BOA Surface Reflectance decoding with processing baseline 04.00+ negative offset support (`BOA_ADD_OFFSET`).
  - `PRE-007`: Physical radiative transfer forward and inverse Lambertian model with fail-closed backend validation.
  - `PRE-008`: Dark Object Subtraction (`DOS_APPROX`) exploratory path-radiance adjustment.
  - `PRE-009`: Landsat L1 Brightness Temperature Planck inversion and Collection 2 Level-2 Surface Temperature ($ST_C = DN \cdot 0.00341802 + 149.0 - 273.15$).
  - `PRE-010` & `PRE-011`: Landsat `QA_PIXEL` bitmask decoding and Sentinel-2 Scene Classification Layer (`SCL`) masking.
  - `PRE-017`: Surface reflectance data quality audit with distribution percentiles and out-of-range diagnostics.
- **Expanded Spectral Index Laboratory (42 Documented Indices & Proxies)**:
  - *Vegetation*: NDVI, GNDVI, EVI, EVI2, SAVI, OSAVI, MSAVI2, SR, DVI, RDVI, ARVI, VARI, SIPI, NDRE1, NDRE2, CI_RE, CI_GREEN (GCI), MTCI, MCARI, TCARI.
  - *Water & Moisture*: NDMI (NDWI_Gao/LSWI), MSI, GVMI, NDWI (McFeeters), MNDWI (Xu), AWEI_nsh, AWEI_sh, WRI, NDCI.
  - *Urban & Built-Up*: NDBI, UI, BSI, BUI, IBI.
  - *Wildfire & Burn Severity*: NBR, NBR2, BAI, MIRBI, dNBR.
  - *Soil & Cryosphere*: NDSI (Snow), Clay Ratio, Iron Oxide Ratio, NDTI (Tillage Index).
- **Safe AST Custom Formula Parser**: Evaluates arbitrary user mathematical expressions without using Python `eval()`, enforcing strict syntax tree validation and denominator safety.
- **Multitemporal & Time-Series Engine**:
  - `TS-001`: Ordinary Least Squares (OLS) linear trend slope across multi-date raster stacks.
  - `TS-002`: Theil-Sen robust slope estimator resisting atmospheric outliers.
  - `TS-003`: Non-parametric Mann-Kendall monotonic trend test with tie-corrected variance and two-tailed p-values.
  - `TS-005` & `TS-006`: Standardized and percentage temporal anomalies.
  - `TS-007`: Pixel-level multitemporal compositing (Median, Max-Value, Mean).
- **Advanced Change Detection Studio**:
  - `CHG-001` & `CHG-002`: Signed and absolute multi-temporal difference.
  - `CHG-003` & `CHG-004`: Relative percentage change and standardized Z-score change.
  - `CHG-005`, `CHG-006`, `CHG-007`: Wildfire disturbance metrics: dNBR (`Pre - Post`), RdNBR, and Relativized Burn Ratio (RBR).
  - `CHG-008`: Spectral Change Vector Analysis (CVA) across arbitrary multi-band configurations.
  - `CHG-009` & `CHG-010`: Post-classification transition matrix $n_{ij}$ and class gains/losses.
- **Statistical Discretization Suite**:
  - Equal Interval, Quantiles, Standard Deviation, Fisher-Jenks Natural Breaks, and automated Otsu binary thresholding.
- **Scientific Audit Manifest (QA-008)**: Immutable JSON run manifests capturing input file hashes (SHA256), exact formula IDs, calibration constants, and runtime environment.
- **Expanded QGIS Processing Provider**: Registered provider `arieslegacy` (`AriesLegacy — Scientific Remote Sensing`) with 10 dedicated Toolbox algorithms.
- **Regression Test Suite**: Added `tests/test_v2_specifications.py` covering mandatory benchmarks TEST-001 through TEST-018 from Section 11 of the formula sheet.

### Changed
- Modernized DockWidget interface: replaced legacy Geo AI tab with dedicated *Time-Series & Trends* panel.
- Updated metadata and GUI actions to reflect scientific remote sensing workbench purpose.

## [1.0.1] - 2026-09-16

### Added
- **Intelligent Sensor Auto-Detection**: Automatically detects satellite mission (Landsat 8/9 C2 L2, Sentinel-2 L2A, or Generic) from selected imagery and applies correct radiometric scaling/offset calibration.
- **Robust GDAL Float32 Calculation Engine**: Block-by-block GDAL + NumPy Float32 processing with native NoData and integer fill-pixel masking.

### Fixed
- **Index Formula Denominators**: Removed artificial offset terms (`+ 0.000001`) from all index formulas, eliminating out-of-bounds ratio spikes over dark/shadow/water boundary pixels.
- **Negative Offset Expression Syntax**: Fixed minus offset formatting in preprocessor expressions (`- 0.2`).

## [1.0.0] - 2026-09-07

### Added
- Core Index Library with 20+ spatial indices.
- Sensor Profiles Engine for Sentinel-2, Landsat 8/9, and Landsat 5/7.
- Two-Date Change Detection Engine.
- Thematic Classifier and Area Statistics in Hectares and km².
- Initial QGIS Processing Provider.
